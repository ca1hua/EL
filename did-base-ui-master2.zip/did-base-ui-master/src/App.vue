<template>
  <router-view />
</template>

<script>
import { mapState, mapMutations } from 'vuex';
export default {
  data() {
    return {};
  },
  watch: {
    // $route(to) {
    //   if (to.name == 'login') {
    //     this.mttSignin({ username: '', token: '', tenantId: '' });
    //   }
    // },
  },
  computed: {
    ...mapState(['token', 'username']),
  },
  mounted() {},
  methods: {
    ...mapMutations(['mttSignin']),
  },
};
</script>

<style lang="less">
@import url('./style/default.less');
</style>
