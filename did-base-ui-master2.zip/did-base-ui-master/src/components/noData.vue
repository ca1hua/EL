<template>
  <div class="no-data">
      <img src="../assets/img/login/nodata.svg" alt="">
      <span>暂无数据</span>
  </div>
</template>

<script>
// import { mapMutations, mapState } from 'vuex';
export default {
};
</script>
<style lang="less" scoped>
.no-data{
  width:130px ;
  margin: 0 auto;
  text-align: center;
  span{
    margin-top: 20px;
  }
}
</style>