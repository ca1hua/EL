import { dateFormat } from './date.js';
export default {
  dateFormat,
};
