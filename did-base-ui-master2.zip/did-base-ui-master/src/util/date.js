import dayjs from 'dayjs';

const dateFormat = (value, format) => {
  if (!value) return '';
  return dayjs(value).format(format);
};

export { dateFormat };
