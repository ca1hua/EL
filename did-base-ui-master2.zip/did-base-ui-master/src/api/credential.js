export default {
  credential: {
    issuingCredential: '/credential/createCredentialPojo', //创建
    creationSelectiveCredential: '/credential/createSelectiveCredential', //创建选择性披露
    queryingCredential: '/credential/queryCredential', //查询
    queryClaim: '/credential/queryClaim', //查询CPT
    verifyCredential: '/credential/verifyCredential', //验证
  },
};
