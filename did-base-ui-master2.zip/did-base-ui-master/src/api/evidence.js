export default {
  evidence: {
    issuingEvidence: '/evidence/createEvidence', //签发凭证存证
    queryingEvidence: '/evidence/queryEvidence', //查询凭证存证
    verificationEvidence: '/evidence/verifyEvidence', //验证凭证存证
    additionLog: '/evidence/addLog', //增加日志
  },
};
