export default {
  did: {
    registrationDid: '/did/create', //自动创建DID
    genKeys: '/tools/genKeys', //小工具
    registrationDidByKeys: '/did/createByKeys', //通过公私钥创建DID
    registrationDIdByDelegate: '/did/delegateCreateDId', //通过代理创建DID
    queryingDid: '/did/queryDid', //查询DID
    additionPublicKey: '/did/addPublicKey', //为指定的DID添加公钥
    settingService: '/did/setService', //根据DID添加Service信息
    settingAuthentication: '/did/setAuthentication', //指定DID添加Authentication信息
    verificationDid: '/did/isDIDExist', //验证DID是否在链上
  },
};