export default {
  cpt: {
    publicationCpt: '/cpt/register', //注册CPT
    queryingCpt: '/cpt/query', //查询CPT
  },
};
