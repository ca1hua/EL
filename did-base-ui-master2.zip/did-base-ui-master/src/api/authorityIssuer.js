export default {
  authorityIssuer: {
    registrationAuthorityIssuer: '/authorityIssuer/register', //注册新的权威机构
    recognitionAuthorityIssuer: '/authorityIssuer/recognize', //提名权威机构
    derecognitionAuthorityIssuer: '/authorityIssuer/derecognize', //注销权威机构
    queryingAuthorityIssuer: '/authorityIssuer/query', //查询权威机构
    verificationAuthorityIssuer: '/authorityIssuer/is', //判断是否为权威机构
  },
};