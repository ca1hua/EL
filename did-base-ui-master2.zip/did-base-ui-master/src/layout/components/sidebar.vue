<template>
  <el-aside :width="collapsed ? '64px' : '206px'" class="app-aside">
    <el-scrollbar class="aside-scrollbar">
      <div class="bcim-img">
        <img src="../../assets/img/login/logo.png" alt="" />
      </div>
      <el-menu :collapse="collapsed" :default-active="activeMenu" router :unique-opened="false" :collapse-transition="false" active-text-color="#EFC377" text-color="#fff" background-color="#30427A">
        <el-submenu :index="index + ''" v-for="(item, index) in menus" :key="index">
          <template #title  >
            <div class="menu-img">
               <img :src="item.icon" alt="">
               <span class="ml1">{{ item.name }}</span>
            </div>
          </template>
          <el-menu-item v-for="(node, key) in item.children" :index="node.to" :key="index + '-' + key" >{{ node.name }}</el-menu-item>
        </el-submenu>
      </el-menu>
    </el-scrollbar>
  </el-aside>
</template>

<script>
import { mapState } from 'vuex';
export default {
  data() {
    return {
      activeMenu: '0',
      menus: [
        {
          icon: require('assets/img/login/did.svg'),
          name: 'DID管理',
          children: [
            { name: '注册DID', to: 'registrationDid' },
            { name: '查询DID', to: 'queryingDid' },
            { name: 'DID添加公钥', to: 'additionPublicKey' },
            { name: '添加服务端点', to: 'settingService' },
            { name: '添加身份验证', to: 'settingAuthentication' },
            { name: '验证DID', to: 'verificationDid' },
          ],
        },
        {
          icon: require('assets/img/login/authorityIssuer.svg'),
          name: '权威机构管理',
          children: [
            { name: '注册权威机构', to: 'registrationAuthorityIssuer' },
            { name: '提名权威机构', to: 'recognitionAuthorityIssuer' },
            { name: '撤销权威机构', to: 'derecognitionAuthorityIssuer' },
            { name: '查询权威机构', to: 'queryingAuthorityIssuer' },
            { name: '判断权威机构', to: 'verificationAuthorityIssuer' },
          ],
        },
        {
          icon: require('assets/img/login/cpt.svg'),
          name: '凭证模板CPT管理',
          children: [
            { name: '发布凭证模板CPT', to: 'publicationCpt' },
            { name: '查询凭证模板CPT', to: 'queryingCpt' },
          ],
        },
        {
          icon: require('assets/img/login/credential.svg'),
          name: '凭证管理',
          children: [
            { name: '发行凭证', to: 'issuingCredential' },
            // { name: '选择性披露', to: 'creationSelectiveCredential' },
            { name: '查询凭证', to: 'queryingCredential' },
            { name: '验证凭证', to: 'verificationCredential' },
          ],
        },
        {
          icon: require('assets/img/login/evidence.svg'),
          name: '凭证存证管理',
          children: [
            { name: '签发凭证存证', to: 'issuingEvidence' },
            { name: '查询凭证存证', to: 'queryingEvidence' },
            { name: '验证凭证存证', to: 'verificationEvidence' },
            { name: '添加凭证存证日志', to: 'additionLog' },
          ],
        },
      ],
    };
  },
  computed: {
    ...mapState(['collapsed']),
  },
  watch:{
     $route() {
     this.setCurrentRoute();
   },
  },
  mounted() {
    this.setCurrentRoute();
  },
  methods: {
     setCurrentRoute() {
      this.activeMenu = this.$route.name;
    },
  },
};
</script>

<style lang="less" scoped>
.bcim-img {
  padding: 10px;
}
.menu-img{
  display:flex;
}
</style>
