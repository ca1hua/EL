<template>
  <div class="header-menu">
    <div class="menu-left">
      <!-- <el-button type="text" @click="collapseHandler">
        <i :class="['collapse', collapsed ? 'el-icon-s-fold' : 'el-icon-s-unfold']"></i>
      </el-button> -->
      <!-- {{currentRoute}} -->
      <el-breadcrumb class="breadcrumb" separator="/">
        <!-- <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item> -->
        <el-breadcrumb-item>{{ currentRoute.meta.title }}</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
  
    <div class="menu-right">
      <!-- <el-button type="text" @click="$router.push({ name: 'home' })" icon="el-icon-menu">首页</el-button> -->
      <div class="fdiv">
           <div class="fdiv">
              <img src="../../assets/img/login/news.svg" alt="">
              <span class="menu-span">您好，欢迎使用BCIM区块链身份管理系统</span>
           </div>
           <el-button type="text" @click="getFullCreeen" icon="el-icon-rank">全屏</el-button>
      </div>
      <!-- <el-button type="text" @click="getFullCreeen" icon="el-icon-rank">全屏</el-button> -->
       
      <!-- <el-button type="text" icon="el-icon-user-solid" @click="$router.push({ name: 'personal' })">{{ username }}</el-button>
      <el-button type="text" @click="signout" icon="el-icon-switch-button">退出</el-button> -->
    </div>
   
  </div>
</template>

<script>
import screenfull from 'screenfull';
// import { mapMutations, mapState } from 'vuex';
export default {
  data() {
    return {
      currentRoute: {},
    };
  },
  watch: {
    $route(to) {
      this.currentRoute = to;
    },
  },
  computed: {
    // ...mapState(['collapsed', 'username']),
  },
  created() {
    // console.log(this.$route);
    
    // this.signout();
    this.currentRoute = this.$route;
  },
  methods: {
    // ...mapMutations(['mttSide', 'mttSignout']),
    // collapseHandler() {
    //   this.mttSide(!this.collapsed);
    // },
    getFullCreeen() {
      if (screenfull.isEnabled) {
        screenfull.toggle();
      }
    },
    signout() {
      // this.mttSignout();
      // this.$router.push({ name: 'did' });
    },
  },
};
</script>
