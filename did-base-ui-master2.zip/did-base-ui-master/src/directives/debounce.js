///防抖函数
const debounce = {
  inserted: function (el, binding) {
    let timer;
    el.addEventListener('click', (event) => {
      if (timer) {
        clearTimeout(timer);
      } else {
        binding.value(); //第一次执行
      }
      timer = setTimeout(() => {
        clearTimeout(timer);
        timer = null;
      }, 500);
    });
  },
};

export default {
  debounce,
};
///v-debounce='function'
