export default [
  {
    path: '/did',
    component: () => import('@/layout/index.vue'),
    children: [
      {
        path: '/registrationDid',
        name: 'registrationDid',
        meta:{ title:'DID管理/注册DID' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/did/registrationDid/registrationDid.vue'),
      },
      {
        path: '/queryingDid',
        name: 'queryingDid',
        meta:{ title:'DID管理/查询DID' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/did/queryingDid/queryingDid.vue'),
      },
      {
        path: '/additionPublicKey',
        name: 'additionPublicKey',
        meta:{ title:'DID管理/DID添加公钥' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/did/additionPublicKey/additionPublicKey.vue'),
      },
      {
        path: '/settingService',
        name: 'settingService',
        meta:{ title:'DID管理/添加服务' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/did/settingService/settingService.vue'),
      },
      {
        path: '/settingAuthentication',
        name: 'settingAuthentication',
        meta:{ title:'DID管理/添加身份验证' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/did/settingAuthentication/settingAuthentication.vue'),
      },
      {
        path: '/verificationDid',
        name: 'verificationDid',
        meta:{ title:'DID管理/验证DID' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/did/verificationDid/verificationDid.vue'),
      },
    ],
  },
];
