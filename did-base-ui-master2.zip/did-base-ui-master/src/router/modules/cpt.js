export default [
  {
    path: '/cpt',
    component: () => import('@/layout/index.vue'),
    children: [
      {
        path: '/publicationCpt',
        name: 'publicationCpt',
        meta:{ title:'凭证模板CPT管理/发布凭证模板CPT' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/cpt/publicationCpt/publicationCpt.vue'),
      },
      {
        path: '/queryingCpt',
        name: 'queryingCpt',
        meta:{ title:'凭证模板CPT管理/查询凭证模板CPT' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/cpt/queryingCpt/queryingCpt.vue'),
      },
     
    ],
  },
];
