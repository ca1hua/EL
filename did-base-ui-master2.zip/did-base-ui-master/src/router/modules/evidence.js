export default [
  {
    path: '/evidence',
    component: () => import('@/layout/index.vue'),
    children: [
      {
        path: '/issuingEvidence',
        name: 'issuingEvidence',
        meta:{ title:'凭证存证管理/签发凭证存证' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/evidence/issuingEvidence/issuingEvidence.vue'),
      },
      {
        path: '/queryingEvidence',
        name: 'queryingEvidence',
        meta:{ title:'凭证存证管理/查询凭证存证' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/evidence/queryingEvidence/queryingEvidence.vue'),
      },
      {
        path: '/verificationEvidence',
        name: 'verificationEvidence',
        meta:{ title:'凭证存证管理/验证凭证存证' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/evidence/verificationEvidence/verificationEvidence.vue'),
      },
      {
        path: '/additionLog',
        name: 'additionLog',
        meta:{ title:'凭证存证管理/添加凭证存证日志' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/evidence/additionLog/additionLog.vue'),
      },
    ],
  },
];
