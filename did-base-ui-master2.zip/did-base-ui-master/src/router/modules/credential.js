export default [
  {
    path: '/credential',
    component: () => import('@/layout/index.vue'),
    children: [
      {
        path: '/issuingCredential',
        name: 'issuingCredential',
        meta:{ title:'凭证管理/发行凭证' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/credential/issuingCredential/issuingCredential.vue'),
      },
      {
        path: '/creationSelectiveCredential',
        name: 'creationSelectiveCredential',
        meta:{ title:'凭证管理/选择性披露' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/credential/creationSelectiveCredential/creationSelectiveCredential.vue'),
      },
      {
        path: '/queryingCredential',
        name: 'queryingCredential',
        meta:{ title:'凭证管理/查询凭证' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/credential/queryingCredential/queryingCredential.vue'),
      },
      {
        path: '/verificationCredential',
        name: 'verificationCredential',
        meta:{ title:'凭证管理/验证凭证' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/credential/verificationCredential/verificationCredential.vue'),
      },
    ],
  },
];
