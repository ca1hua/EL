export default [
  {
    path: '/authorityIssuer',
    component: () => import('@/layout/index.vue'),
    children: [
      {
        path: '/registrationAuthorityIssuer',
        name: 'registrationAuthorityIssuer',
        meta:{ title:'权威机构管理/注册权威机构' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/authorityIssuer/registrationAuthorityIssuer/registrationAuthorityIssuer.vue'),
      },
      {
        path: '/derecognitionAuthorityIssuer',
        name: 'derecognitionAuthorityIssuer',
        meta:{ title:'权威机构管理/撤销权威机构' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/authorityIssuer/derecognitionAuthorityIssuer/derecognitionAuthorityIssuer.vue'),
      },
      {
        path: '/recognitionAuthorityIssuer',
        name: 'recognitionAuthorityIssuer',
        meta:{ title:'权威机构管理/提名权威机构' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/authorityIssuer/recognitionAuthorityIssuer/recognitionAuthorityIssuer.vue'),
      },
    
      {
        path: '/queryingAuthorityIssuer',
        name: 'queryingAuthorityIssuer',
        meta:{ title:'权威机构管理/查询权威机构' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/authorityIssuer/queryingAuthorityIssuer/queryingAuthorityIssuer.vue'),
      },
      {
        path: '/verificationAuthorityIssuer',
        name: 'verificationAuthorityIssuer',
        meta:{ title:'权威机构管理/判断权威机构' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/authorityIssuer/verificationAuthorityIssuer/verificationAuthorityIssuer.vue'),
      },

    ],
  },
];
