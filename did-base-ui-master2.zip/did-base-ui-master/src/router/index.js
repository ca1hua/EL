import Vue from 'vue';
import VueRouter from 'vue-router';
const originalPush = VueRouter.prototype.push;
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch((err) => err);
};

Vue.use(VueRouter);

const modulesFiles = require.context('./modules', true, /\.js$/);
var routeMap = [];
modulesFiles.keys().forEach((key) => {
  routeMap = routeMap.concat(modulesFiles(key).default);
});

const routes = [
  {
    path: '/',
    name: 'login',
    component: () => import(/* webpackChunkName: "login" */ '@/views/login/login.vue'),
  },
  // {
  //   path: '/forgot',
  //   name: 'forgot',
  //   component: () => import(/* webpackChunkName: "forgot" */ '@/views/login/forgot.vue'),
  // },
  {
    path: '',
    component: () => import('@/layout/index.vue'),
    children: [
      {
        path: '/did',
        name: 'did',
        meta:{ title:'DID管理/注册DID' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/did/registrationDid/registrationDid.vue'),
      },
    ],
  },
  ...routeMap,
];

const router = new VueRouter({
  routes,
});

export default router;
