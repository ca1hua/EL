import Vue from 'vue';
import App from './App.vue';
import router from './router';
import store from './store';

//Element-UI
import ElementUI from 'element-ui';
import './style/theme/index.css';
import 'element-ui/lib/theme-chalk/display.css';
Vue.use(ElementUI, { size: 'small' }); //mini

//网络请求
import axios from './util/axios';
import VueAxios from 'vue-axios';
Vue.use(VueAxios, axios);

//自定义组建
import components from '@/components/index.js';
Object.keys(components).forEach((key) => {
  Vue.component(key, components[key]);
});

//扩展方法
import utils from '@/util/index.js';
Vue.prototype.$util = utils;

//自定义过滤器
const filters = require.context('./filters', true, /\.js$/);
filters.keys().forEach((key) => {
  var module = filters(key).default;
  var name = /function\s*(\w*)/i.exec(module.toString())[1];
  Vue.filter(name, module);
});

//自定义指令
const directives = require.context('./directives', true, /\.js$/);
directives.keys().forEach((key) => {
  var module = directives(key).default;
  Object.keys(module).forEach((attr) => {
    Vue.directive(attr, module[attr]);
  });
});

//所有接口地址
const apiModules = require.context('./api', true, /\.js$/);
var apiMap = {};
apiModules.keys().forEach((key) => {
  var module = apiModules(key).default;
  Object.assign(apiMap, module);
});
Vue.prototype.$api = apiMap;

///统一输出
console.log('全部请求   api:', apiMap);
console.log('公共方法 $util:', utils);

Vue.config.productionTip = false;

new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount('#app');
