export default {
  mttSide(state, value) {
    state.collapsed = value;
  },
  mttActiveMenu(state, value) {
    localStorage.activeMenu = value;
    state.activeMenu = value;
  },
  mttSignout(state) {
    localStorage.username = '';
    localStorage.token = '';
    state.username = '';
    state.token = '';
  },
  mttSignin(state, { username, token, tenantId }) {
    localStorage.username = username;
    localStorage.token = token;
    localStorage.tenantId = tenantId;
    state.username = username;
    state.token = token;
    state.tenantId = tenantId;
  },
};
