import Vue from 'vue';
import Vuex from 'vuex';

import mutations from './mutations';
import actions from './actions';

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    collapsed: false,
    username: localStorage.username ? localStorage.username : 'chaintimer',
    token: localStorage.token ? localStorage.token : '',
    tenantId: localStorage.tenantId ? localStorage.tenantId : '',
    activeMenu: localStorage.activeMenu ? localStorage.activeMenu : '',
  },
  mutations: mutations,
  actions: actions,
  modules: {},
});
