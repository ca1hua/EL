<template>
  <div class="did-h">
    <div class="black black-h">
      <div>发布凭证模板CPT。</div>
      <el-row :gutter="20" class="mt3">
        <el-col :span="10" :offset="6">
          <el-form label-position="right" :rules="rules" ref="ruleForm" label-width="140px" :model="form">
            <el-form-item label="发布者DID" prop="publisher">
              <el-input v-model="form.publisher" placeholder="请输入发布者的DID"></el-input>
            </el-form-item>
            <el-form-item label="发布者私钥" prop="privateKey">
              <el-input v-model="form.privateKey" placeholder="请输入发布者的私钥"></el-input>
            </el-form-item>
            <el-form-item label="凭证模板CPT标题" prop="title">
              <el-input v-model="form.title" placeholder="请输入凭证模板CPT的标题"></el-input>
            </el-form-item>
            <el-form-item label="凭证模板CPT描述" prop="description">
              <el-input v-model="form.description" placeholder="请输入凭证模板CPT的描述"></el-input>
            </el-form-item>
            <el-form-item label="凭证模板CPT ID">
              <el-input v-model="form.cptId" placeholder="请输入自定义的凭证模板CPT的ID（可选）"></el-input>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
      <el-table :data="tableData" style="width: 100%">
        <el-table-column type="index" label="序号" align="center"> </el-table-column>
        <el-table-column prop="name" label="字段名" align="center">
          <template slot-scope="scope">
            <el-input v-model="scope.row.name" placeholder="请输入字段名"></el-input>
          </template>
        </el-table-column>
        <el-table-column label="字段描述" align="center">
          <template slot-scope="scope">
            <el-input v-model="scope.row.age" placeholder="请输入字段的描述"></el-input>
          </template>
        </el-table-column>
        <el-table-column align="center" width="50">
          <template slot-scope="scope">
            <i v-if="tableData.length > 1" class="el-icon-remove-outline cursor" @click="delClick(scope.$index)"></i>
          </template>
        </el-table-column>
      </el-table>
      <div class="add-button" @click="addClick">添加</div>
      <div class="did-button">
        <el-button size="medium" type="primary" @click="publication">发布凭证模板CPT</el-button>
      </div>
    </div>
    <div class="black mt1 black-height">
          <ul>
            <li class="publicKey">
              <span class="span">凭证模板CPT ID：</span>
              <span class="span-key">{{ data.cptId }}</span>
            </li>
            <li class="publicKey">
              <span class="span">发布者DID：</span>
              <span class="span-key">{{ data.publisher }}</span>
            </li>
            <li class="publicKey">
              <span class="span">CPT声明数据</span>
            </li>
            <li>
              <span class="span-key">
                <el-table :data="claim" style="width: 100%">
                     <el-table-column prop="name" label="字段名"></el-table-column>
                     <el-table-column prop="value" label="描述" ></el-table-column>
                </el-table>
              </span>
            </li>
            <li class="publicKey">
              <span class="span">交易哈希：</span>
              <span class="span-key">{{ data.txHash }}</span>
            </li>
            <li class="publicKey">
              <span class="span">区块高度：</span>
              <span class="span-key">{{ data.blockHeight }}</span>
            </li>
          </ul>
      <!-- <NoData class="nodata" /> -->
    </div>
  </div>
</template>
<script>
import NoData from '../../../components/noData.vue';
export default {
  components: {
    NoData,
  },
  data() {
    return {
      activeName: 'first',
      form: {
        publisher: '',
        privateKey: '',
        claim: {},
        title: '',
        description: '',
        cptId: '',
      },
      tableData: [{ name: '', age: '' }],
      rules: {
        description: [{ required: true, message: '请输入凭证模板CPT的描述', trigger: 'blur' }],
        title: [{ required: true, message: '请输入凭证模板CPT的标题', trigger: 'blur' }],
        privateKey: [{ required: true, message: '请输入发布者的私钥', trigger: 'blur' }],
        publisher: [{ required: true, message: '请输入发布者的DID', trigger: 'blur' }],
      },
      options: [
        {
          value: 'String',
          label: 'String',
        },
        {
          value: 'integer',
          label: 'integer',
        },
      ],
      data: {
        cptId: '',
        publisher: '',
        claim: '',
        txHash: '',
        blockHeight: '',
      },
      claim:[]
    };
  },
  mounted() {},
  methods: {
    publication() {
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          this.publicationCpt();
        } else {
          return false;
        }
      });
    },
    addClick() {
      let arr = { name: '', age: '' };
      this.tableData.push(arr);
    },
    delClick(index) {
      this.tableData.splice(index, 1);
    },
    async publicationCpt() {
      this.form.claim = {};
      this.tableData.forEach(item =>{
        this.form.claim[item.name] = item.age;
      })

      let res = await this.$http.post(this.$api.cpt.publicationCpt, this.form);
      if (res.code == 200) {
        let att = [];
        this.data = res.data;
        let arr = JSON.parse(res.data.claim)
        for (const resKey in arr) {
          att.push({
            name:resKey,
            value:arr[resKey]
          })
        }
        console.log(att)
        this.claim = att;
      }
    },
  },
};
</script>
<style lang="less" scoped>
.did-content {
  margin-top: 10%;
  h1 {
    color: #666666;
    width: 320px;
    margin: 0 auto;
  }
}
.did-button {
  width: 100px;
  margin: 0 auto;
  margin-top: 20px;
}
.m-a0 {
  margin: 0 auto;
}
.black-h {
  height: 50%;
  overflow-y: auto;
}
.black-height {
  height: calc(50% - 90px);
  overflow-y: auto;
}
.black-height ul{
  width: 90%;
  margin: 0 auto;
}
.nodata {
  margin-top: 10%;
}
.did-width {
  width: 500px;
  margin: 0 auto;
}
.text-c {
  text-align: center;
}
.add-button {
  width: 100%;
  padding: 8px 0;
  background: #fca400;
  color: white;
  border: 1px dashed #ccc;
  text-align: center;
  border-radius: 3px;
  margin-top: 10px;
  cursor: pointer;
}
.cursor {
  cursor: pointer;
}
.publicKey {
  display: flex;
  line-height: 30px;
  .span {
    width: 120px;
  }
  .span-key {
    width: calc(100% - 120px);
    word-break: break-word;
    white-space: pre-line;
  }
}
</style>
