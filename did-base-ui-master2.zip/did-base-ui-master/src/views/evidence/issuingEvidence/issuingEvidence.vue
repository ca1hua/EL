<template>
  <div class="did-h">
    <div class="black black-h">
      <div>通过凭证ID将凭证上链形成存证，可设关键字、日志。</div>
      <el-tabs v-model="activeName" @tab-click="handleClick">
        <el-tab-pane label="凭证ID" name="first">
          <el-row :gutter="20" class="mt3">
            <el-col :span="10" :offset="6">
              <el-form label-position="right" label-width="130px" :model="form">
                <el-form-item label="凭证ID">
                  <el-input v-model="form.credentialId" placeholder="请输入凭证ID"></el-input>
                </el-form-item>
                <el-form-item label="签发者私钥">
                  <el-input v-model="form.privateKey" placeholder="请输入签发者的私钥"></el-input>
                </el-form-item>
              </el-form>
            </el-col>
          </el-row>
          <div class="did-button">
            <el-button size="medium" type="primary" @click="issuingEvidence">签发凭证存证</el-button>
          </div>
        </el-tab-pane>
        <el-tab-pane label="关键字、日志" name="second">
          <el-row :gutter="20" class="mt3">
            <el-col :span="10" :offset="6">
              <el-form label-position="right" label-width="130px" :model="form">
                <el-form-item label="凭证ID">
                  <el-input v-model="form.credentialId" placeholder="请输入凭证ID"></el-input>
                </el-form-item>
                <el-form-item label="签发者私钥">
                  <el-input v-model="form.privateKey" placeholder="请输入签发者的私钥"></el-input>
                </el-form-item>
                <el-form-item label="日志">
                  <el-input v-model="form.log" placeholder="请输入需要添加的日志"></el-input>
                </el-form-item>
                <el-form-item label="关键字">
                  <el-input v-model="form.customKey" placeholder="请输入自定义的关键字"></el-input>
                </el-form-item>
              </el-form>
            </el-col>
          </el-row>
          <div class="did-button">
            <el-button size="medium" type="primary" @click="issuingEvidence">签发凭证存证</el-button>
          </div>
        </el-tab-pane>
        <el-tab-pane label="日志" name="third">
          <el-row :gutter="20" class="mt3">
            <el-col :span="10" :offset="6">
              <el-form label-position="right" label-width="130px" :model="form">
                <el-form-item label="凭证ID">
                  <el-input v-model="form.credentialId" placeholder="请输入凭证ID"></el-input>
                </el-form-item>
                <el-form-item label="签发者DID">
                  <el-input v-model="form.signer" placeholder="请输入签发者的DID"></el-input>
                </el-form-item>
                <el-form-item label="签发者私钥">
                  <el-input v-model="form.privateKey" placeholder="请输入签发者的私钥"></el-input>
                </el-form-item>
                <el-form-item label="日志">
                  <el-input v-model="form.log" placeholder="请输入需要添加的日志"></el-input>
                </el-form-item>
              </el-form>
            </el-col>
          </el-row>
          <div class="did-button">
            <el-button size="medium" type="primary" @click="issuingEvidence">签发凭证存证</el-button>
          </div>
        </el-tab-pane>
      </el-tabs>

    </div>
    <div class="black mt1 black-height">
      <el-row :gutter="20" class="mt3">
        <el-col :span="10" :offset="6">
          <ul>
            <li v-if="data" class="publicKey">
              <span class="span">凭证哈希：</span>
              <span class="span-key">{{ data }}</span>
            </li>
          </ul>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
import NoData from '../../../components/noData.vue';
export default {
  components: {
    NoData,
  },
  data() {
    return {
      activeName: 'first',
      form: {
        credentialId: '',
        privateKey: '',
        signer: '',
        customKey: '',
        log: '',
      },
      data: '',
    };
  },
  mounted() {},
  methods: {
    async issuingEvidence() {
      let res = await this.$http.post(this.$api.evidence.issuingEvidence, this.form);
      if (res.code == 200) {
        this.data = res.data;
      }
    },
    handleClick(){
      this.form = {
        credentialId: '',
            privateKey: '',
            signer: '',
            customKey: '',
            log: '',
      }
    }
  },
};
</script>
<style lang="less" scoped>
.did-content {
  margin-top: 10%;
  h1 {
    color: #666666;
    width: 320px;
    margin: 0 auto;
  }
}
.did-button {
  width: 100px;
  margin: 0 auto;
  margin-top: 20px;
}
.m-a0 {
  margin: 0 auto;
}
.black-h {
  height: 50%;
}
.black-height {
  height: calc(50% - 90px);
}
.nodata {
  margin-top: 10%;
}
.did-width {
  width: 500px;
  margin: 0 auto;
}
.publicKey {
  display: flex;
  line-height: 30px;
  .span {
    width: 180px;
    text-align: right;
  }
  .span-key {
    width: calc(100% - 50px);
    word-break: break-word;
    white-space: pre-line;
  }
}
</style>
