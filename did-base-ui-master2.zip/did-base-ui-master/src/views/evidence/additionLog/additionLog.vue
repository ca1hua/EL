<template>
  <div class="did-h">
    <div class="black black-h">
      <div>通过凭证哈希或关键字为存证添加日志。</div>
      <el-row :gutter="20" class="mt3">
        <el-col :span="10" :offset="6">
          <el-form label-position="right" label-width="90px" :model="form">
            <el-form-item label="凭证哈希">
              <el-input v-model="form.evidenceHash" placeholder="请输入凭证哈希"></el-input>
            </el-form-item>
             <el-form-item label="关键字">
              <el-input v-model="form.customKey" placeholder="请输入自定义的关键字"></el-input>
            </el-form-item>
             <el-form-item label="日志">
              <el-input v-model="form.log" placeholder="请输入需要添加的日志"></el-input>
            </el-form-item>
             <el-form-item label="签名者私钥">
              <el-input v-model="form.privateKey" placeholder="请输入签名者的私钥"></el-input>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
      <div class="did-button">
        <el-button size="medium" type="primary" @click="additionLog">添加日志</el-button>
      </div>
    </div>
     <div class="black mt1 black-height text-c" >
       {{data?'添加日志成功':''}}
    </div>
  </div>
</template>
<script>
import NoData from '../../../components/noData.vue';
export default {
  components: {
    NoData,
  },
  data() {
    return {
      activeName: 'first',
      form: {
        evidenceHash: '',
        customKey: '',
        privateKey: '',
        log: '',
      },
       data: '',
    };
  },
  mounted() {},
  methods: {
    
    async additionLog() {
      this.data = ''
      let res = await this.$http.post(this.$api.evidence.additionLog, this.form);
      if (res.code == 200) {
        this.data = res.data;
      }
    },
  },
};
</script>
<style lang="less" scoped>
.did-content {
  margin-top: 10%;
  h1 {
    color: #666666;
    width: 320px;
    margin: 0 auto;
  }
}
.did-button {
  width: 100px;
  margin: 0 auto;
  margin-top: 20px;
}
.m-a0 {
  margin: 0 auto;
}
.black-h {
  height: 50%;
}
.black-height {
  height: calc(50% - 90px);
}
.nodata {
  margin-top: 10%;
}
.did-width {
  width: 500px;
  margin: 0 auto;
}
.publicKey {
  display: flex;
  line-height: 30px;
  .span {
    width: 180px;
    text-align: right;
  }
  .span-key {
    width: calc(100% - 50px);
    word-break: break-word;
    white-space: pre-line;
  }
}
.text-c{
  text-align: center;
  font-size: 20px;
  font-weight: 600;
}
</style>
