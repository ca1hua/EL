<template>
  <div class="did-h">
    <div class="black black-h">
      <div>通过凭证哈希或关键字查询凭证存证。</div>
            <el-row :gutter="20" class="mt3">
            <el-col :span="10" :offset="6">
              <el-form label-position="right" label-width="80px" :model="form">
                <el-form-item label="凭证哈希">
                  <el-input v-model="form.evidenceHash" placeholder="请输入凭证哈希"></el-input>
                </el-form-item>
                 <el-form-item label="关键字">
                  <el-input v-model="form.customKey" placeholder="请输入自定义的关键字"></el-input>
                </el-form-item>
              </el-form>
            </el-col>
          </el-row>
          <div class="did-button">
            <el-button size="medium" type="primary" @click="queryingEvidence">查询凭证存证</el-button>
          </div>
  
    </div>
    <div class="black mt1 black-height">

          <ul>          
            <li class="publicKey">
              <span class="span">数字签名信息</span>
            </li>
            <li>
              <span class="span-key">
                <el-table :data="data" style="width: 100%">
                     <el-table-column prop="did" label="签名者DID"></el-table-column>
                     <el-table-column prop="logs" label="日志" >
                       <template slot-scope="scope">
                          {{scope.row.logs.join('；')}}
                        </template>
                     </el-table-column>
                     <el-table-column prop="signature" label="签名" ></el-table-column>
                </el-table>
              </span>
            </li>
          </ul>

    </div>
  </div>
</template>
<script>
import NoData from '../../../components/noData.vue';
export default {
  components: {
    NoData,
  },
  data() {
    return {
      activeName: 'first',
      form: {
        evidenceHash: '',
        customKey: '',
      },
      formDID:{

      },
      data:[],
      tableData:[],
    };
  },
  mounted() {},
  methods: {
    async queryingEvidence() {
      let params = this.form;
      let res = await this.$http.post(this.$api.evidence.queryingEvidence, params);
      if (res.code == 200) {
        let arr = []
        for (const resKey in res.data.signInfo) {
          console.log(resKey)
          arr.push({
            did:resKey,
            ...res.data.signInfo[resKey]
          })
        }
        this.data = arr;
      }
    },
    
  },
};
</script>
<style lang="less" scoped>
.did-content {
  margin-top: 10%;
  h1 {
    color: #666666;
    width: 320px;
    margin: 0 auto;
  }
}
.did-button {
  width: 100px;
  margin: 0 auto;
  margin-top: 20px;
}
.m-a0 {
  margin: 0 auto;
}
.black-h {
  height: 50%;
}
.black-height {
  height: calc(50% - 90px);
  overflow-y: auto;
  ul{
    width: 90%;
    margin: 0 auto;
  }
}
.nodata {
  margin-top: 10%;
}
.did-width {
  width: 500px;
  margin: 0 auto;
}
.publicKey {
  display: flex;
  line-height: 30px;
  .span {
    width: 180px;
  }
  .span-key {
    width: calc(100% - 180px);
    word-break: break-word;
    white-space: pre-line;
  }
}
</style>
