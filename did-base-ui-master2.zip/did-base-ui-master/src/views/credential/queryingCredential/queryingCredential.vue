<template>
  <div class="did-h">
    <div class="black black-h">
      <div>通过凭证ID查询凭证。</div>
      <el-row :gutter="20" class="mt3">
        <el-col :span="10" :offset="6">
          <el-form label-position="right" label-width="180px" :model="form">
            <el-form-item label="凭证ID" >
              <el-input v-model="form.credentialId" placeholder="请输入凭证ID"></el-input>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
      <div class="did-button">
        <el-button size="medium" type="primary" @click="querying">查询凭证</el-button>
      </div>
    </div>
    <div class="black mt1 black-height">

          <ul>
            <li class="publicKey">
              <span class="span">凭证ID：</span>
              <span class="span-key">{{ data.id }}</span>
            </li>
            <li class="publicKey">
              <span class="span">凭证模板CPT ID：</span>
              <span class="span-key">{{ data.cptId }}</span>
            </li>
            <li class="publicKey">
              <span class="span">发行者DID：</span>
              <span class="span-key">{{ data.issuer }}</span>
            </li>
            <li class="publicKey">
              <span class="span">凭证声明数据</span>
            </li>
            <li>
              <span class="span-key">
                <el-table :data="list.claim" style="width: 100%">
                     <el-table-column prop="name" label="字段名"></el-table-column>
                     <el-table-column prop="value" label="内容" ></el-table-column>
                </el-table>
              </span>
            </li>
            <li class="publicKey">
              <span class="span">上下文格式：</span>
              <span class="span-key">{{ list.context }}</span>
            </li>
            <li class="publicKey">
              <span class="span">凭证类型：</span>
              <span class="span-key">{{ list.type.join('；') }}</span>
            </li>
            <li class="publicKey">
              <span class="span">签名数据</span>
            </li>
            <li>
              <span class="span-key">
                <el-table :data="proof" style="width: 100%">
                     <el-table-column prop="creator" label="发行者"></el-table-column>
                     <el-table-column prop="signatureValue" label="签名" ></el-table-column>
                     <el-table-column prop="type" label="类型" width="100px">
                     </el-table-column>
                </el-table>
              </span>
            </li>
             <li class="publicKey">
              <span class="span">是否有效：</span>
               <span class="span-key">{{ data.isValid!=null?data.isValid?'是':'否':'' }}</span>
            </li>
          </ul>
      <!-- <NoData class="nodata" /> -->
    </div>
  </div>
</template>
<script>
import NoData from '../../../components/noData.vue';
export default {
  components: {
    NoData,
  },
  data() {
    return {
      activeName: 'first',
      form: {
        credentialId:''
      },
      rules: {
        cptTitle: [{ required: true, message: '请输入凭证ID', trigger: 'blur' }],
      },
      tableData: [{ name: '', type: '', describe: '' }],
      data: {
        id: '',
        issuer: '',
        cptId: '',
        credential: '',
        isValid: '',
      },
      proof:[],
      list:{
        context:'',
        claim:[],
        proofType:'',
        type:[]
      }
    };
  },
  mounted() {},
  methods: {
    querying() {
       this.verificationEvidence();
    },
    addClick(){
      let arr = [{ name: '', type: '', describe: '' }]
      this.tableData.push(arr);
    },
    delClick(index){
      this.tableData.splice(index,1)
    },
    async verificationEvidence(){
        this.proof = [];
        let arr = []
        let res = await this.$http.post(this.$api.credential.queryingCredential, this.form);
        if (res.code == 200) {
          this.data = res.data;
          let att = JSON.parse(res.data.credential)
          this.list = att;
          this.proof.push(att.proof);
          for (const attKey in att.claim) {
            arr.push({
              name:attKey,
              value:att.claim[attKey]
            })
          }
          this.list.claim = arr;
        }
    }
  },
};
</script>
<style lang="less" scoped>
.did-content {
  margin-top: 10%;
  h1 {
    color: #666666;
    width: 320px;
    margin: 0 auto;
  }
}
.did-button {
  width: 100px;
  margin: 0 auto;
  margin-top: 20px;
}
.m-a0 {
  margin: 0 auto;
}
.black-h {
  height: 50%;
  overflow-y: auto;
}
.black-height {
  height: calc(50% - 90px);
  overflow-y: auto;
}
.black-height ul{
  width: 90%;
  margin: 0 auto;
}
.nodata {
  margin-top: 10%;
}
.did-width {
  width: 500px;
  margin: 0 auto;
}
.text-c {
  text-align: center;
}
.add-button{
  width: 100%;
  padding:8px 0 ;
  background: #FCA400;
  color: white;
  border: 1px dashed #ccc;
  text-align: center;
  border-radius: 3px;
  margin-top: 10px;
  cursor: pointer;
}
.cursor{
  cursor: pointer;
}
.publicKey {
  display: flex;
  line-height: 30px;
  .span {
    width: 200px;
  }
  .span-key {
    width: calc(100% - 200px);
    word-break: break-word;
    white-space: pre-line;
  }
}
</style>
