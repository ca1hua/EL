<template>
  <div class="did-h">
    <div class="black black-h">
      <div>根据凭证模板发行凭证</div>
      <el-row :gutter="20" class="mt3">
        <el-col :span="10" :offset="6">
          <el-form label-position="right" label-width="180px" :model="form">
            <el-form-item label="凭证ID" >
              <el-input v-model="form.credentialId" placeholder="请输入凭证ID"></el-input>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>

       <el-table :data="tableData" style="width: 100%">
        <el-table-column type="index" label="序号" align="center"> </el-table-column>
        <el-table-column prop="name" label="字段名" align="center">
          <template slot-scope="scope">
            <el-input v-model="scope.row.name" placeholder="请输入字段名"></el-input>
          </template>
        </el-table-column>
        <el-table-column label="字段值" align="center">
            <template slot-scope="scope">
            <el-input v-model="scope.row.describe" placeholder="请输入披露策略"></el-input>
          </template>
        </el-table-column>
        <el-table-column align="center" width="50"> 
          <template slot-scope="scope">
            <i  v-if="scope.$index!==0" class="el-icon-remove-outline cursor" @click="delClick(scope.$index)"></i>
          </template>
          
        </el-table-column>
      </el-table>
      <div class="add-button" @click="addClick">
           添加
      </div>
      <div class="did-button">
        <el-button size="medium" type="primary" @click="creation">创建选择性披露</el-button>
      </div>
    </div>
    <div class="black mt1 black-height">
      <el-row :gutter="20" class="mt3">
        <el-col :span="18" :offset="4">
          <ul>
            <li class="publicKey">
              <span class="span">凭证ID：</span>
              <span class="span-key">{{ data.id }}</span>
            </li>
            <li class="publicKey">
              <span class="span">发布者DID：</span>
              <span class="span-key">{{ data.issuer }}</span>
            </li>
            <li class="publicKey">
              <span class="span">凭证模板CPT ID：</span>
              <span class="span-key">{{ data.cptId }}</span>
            </li>
            <li class="publicKey">
              <span class="span">凭证声明数据：</span>
              <span class="span-key">{{ data.claim }}</span>
            </li>
            <li class="publicKey">
              <span class="span">创建日期：</span>
              <span class="span-key">{{ data.issuanceDate }}</span>
            </li>
             <li class="publicKey">
              <span class="span">到期日期：</span>
              <span class="span-key">{{ data.expirationDate }}</span>
            </li>
            <li class="publicKey">
              <span class="span">凭证信息：</span>
              <span class="span-key">{{ data.raw }}</span>
            </li>
          </ul>
        </el-col>
      </el-row>
      <!-- <NoData class="nodata" /> -->
    </div>
  </div>
</template>
<script>
import NoData from '../../../components/noData.vue';
export default {
  components: {
    NoData,
  },
  data() {
    return {
      activeName: 'first',
      form: {
         fieldsToBeDisclosed:{dass:0},
         credentialId:''
      },
      tableData: [{ name: '',  describe: '' }],
      rules: {
        evidenceHash: [{ required: true, message: '请输入凭证哈希', trigger: 'blur' }],
      },
      data: {
        id:'',
        cptId: '',
        issuer: '',
        claim: '',
        issuanceDate: '',
        expirationDate: '',
        raw: '',
      },
    };
  },
  mounted() {},
  methods: {
    creation() {
       this.creationSelectiveCredential();
    },
    addClick(){
      let arr = [{ name: '', type: '', describe: '' }]
      this.tableData.push(arr);
    },
    delClick(index){
      this.tableData.splice(index,1)
    },
    async creationSelectiveCredential(){
        //  this.tableData.forEach(item =>{
        //    this.form.fieldsToBeDisclosed[item.name] = item.describe
        // });
        let res = await this.$http.post(this.$api.credential.creationSelectiveCredential, this.form);
        if (res.code == 200) {
          this.data = res.data;
        }
    }
  },
};
</script>
<style lang="less" scoped>
.did-content {
  margin-top: 10%;
  h1 {
    color: #666666;
    width: 320px;
    margin: 0 auto;
  }
}
.did-button {
  width: 100px;
  margin: 0 auto;
  margin-top: 20px;
}
.m-a0 {
  margin: 0 auto;
}
.black-h {
  height: 50%;
  overflow-y: auto;
}
.black-height {
  height: calc(50% - 90px);
  overflow-y: auto;
}
.nodata {
  margin-top: 10%;
}
.did-width {
  width: 500px;
  margin: 0 auto;
}
.text-c {
  text-align: center;
}
.add-button{
  width: 100%;
  padding:8px 0 ;
  background: #FCA400;
  color: white;
  border: 1px dashed #ccc;
  text-align: center;
  border-radius: 3px;
  margin-top: 10px;
  cursor: pointer;
}
.cursor{
  cursor: pointer;
}
.publicKey {
  display: flex;
  line-height: 30px;
  .span {
    width: 470px;
    text-align: right;
  }
  .span-key {
    width: calc(100% - 50px);
    word-break: break-word;
    white-space: pre-line;
  }
}
</style>
