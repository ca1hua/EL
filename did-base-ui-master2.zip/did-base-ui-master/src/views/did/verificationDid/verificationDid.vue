<template>
  <div class="did-h">
    <div class="black black-h">
      <div>验证DID是否存在。</div>
      <el-row :gutter="20" class="mt3">
        <el-col :span="10" :offset="6">
          <el-form label-position="right" label-width="80px" :model="form">
            <el-form-item label="DID">
              <el-input v-model="form.did" placeholder="请输入您想验证的DID"></el-input>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
      <div class="did-button">
        <el-button size="medium" type="primary" @click="verificationDid">验证DID</el-button>
      </div>
    </div>
    <div class="black mt1 black-height text-c" >
          {{data.msg=='Success'?data.data==true?'该DID存在':'该DID非法':''}}
    </div>
  </div>
</template>
<script>
import NoData from '../../../components/noData.vue';
export default {
  components: {
    NoData,
  },
  data() {
    return {
      activeName: 'first',
      form: {
        did: '',
      },
      data:''
    };
  },
  mounted() {},
  methods: {
   async verificationDid(){
     this.data = ''
     let params = this.form;
       let res = await this.$http.post(this.$api.did.verificationDid,params);
       if (res.code == 200) {
          this.data = res;
      }
   }
  },
};
</script>
<style lang="less" scoped>
.did-content {
  margin-top: 10%;
  h1 {
    color: #666666;
    width: 320px;
    margin: 0 auto;
  }
}
.did-button {
  width: 100px;
  margin: 0 auto;
  margin-top: 20px;
}
.m-a0 {
  margin: 0 auto;
}
.black-h {
  height: 50%;
}
.black-height {
  height: calc(50% - 90px);
}
.nodata {
  margin-top: 10%;
}
.did-width {
  width: 500px;
  margin: 0 auto;
}
.text-c{
  text-align: center;
  font-size: 20px;
  font-weight: 600;
}
</style>
