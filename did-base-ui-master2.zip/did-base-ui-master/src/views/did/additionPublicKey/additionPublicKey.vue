<template>
  <div class="did-h">
    <div class="black black-h">
      <div>为DID添加公钥，公钥ID随添加顺序自增长且不可改变。</div>
      <el-tabs v-model="activeName" @tab-click="handleClick">
        <el-tab-pane label="自动添加" name="first">
          <el-row :gutter="20" class="mt3">
            <el-col :span="10" :offset="6">
              <el-form label-position="right" label-width="130px" :model="form">
                <el-form-item label="DID">
                  <el-input v-model="form.did" placeholder="请输入已注册的DID"></el-input>
                </el-form-item>
                <el-form-item label="私钥">
                  <el-input v-model="form.privateKey" placeholder="请输入该DID的私钥"></el-input>
                </el-form-item>
                <el-form-item label="新公钥">
                  <el-input v-model="form.addPublicKey" placeholder="请输入未添加的新公钥"></el-input>
                </el-form-item>
              </el-form>
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="10" :offset="13">没有公钥？点击 <el-button type="text" @click="genKeys">此处</el-button></el-col>
          </el-row>
          <div class="did-button">
            <el-button size="medium" type="primary" @click="additionPublicKey">添加公钥</el-button>
          </div>
        </el-tab-pane>
        <!-- <el-tab-pane label="代理方添加" name="second">
          <el-row :gutter="20" class="mt3">
            <el-col :span="10" :offset="6">
              <el-form label-position="right" label-width="130px" :model="form">
                <el-form-item label="DID">
                  <el-input v-model="form.name" placeholder="请输入你的DID"></el-input>
                </el-form-item>
                <el-form-item label="公钥">
                  <el-input v-model="form.region" placeholder="请输入你的公钥"></el-input>
                </el-form-item>
                <el-form-item label="代理私钥">
                  <el-input v-model="form.region" placeholder="请输入代理私钥"></el-input>
                </el-form-item>
              </el-form>
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="10" :offset="13">没有公私钥？点击此处 <el-button type="text">自动生成</el-button></el-col>
          </el-row>
          <div class="did-button">
            <el-button size="medium" type="primary">代理添加公钥</el-button>
          </div>
        </el-tab-pane> -->
      </el-tabs>
    </div>
    <div class="black mt1 black-height">
    <el-row :gutter="30" class="mt3">
        <el-col :span="10" :offset="6">
          <ul>
            <li class="publicKey">
              <span class="span">DID：</span>
              <span class="span-key">{{ form.did }}</span>
            </li>
            <li class="publicKey">
              <span class="span">公钥：</span>
              <span class="span-key">{{ data.addPublicKey }}</span>
            </li>
            <li class="publicKey">
              <span class="span">私钥：</span>
              <span class="span-key">{{ data.addPrivateKey }}</span>
            </li>
            <li class="publicKey">
              <span class="span">公钥ID：</span>
              <span class="span-key">{{ data.publicKeyID }}</span>
            </li>
          </ul>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
import NoData from '../../../components/noData.vue';
export default {
  components: {
    NoData,
  },
  data() {
    return {
      activeName: 'first',
      form: {
        weid: '',
        addPublicKey:'',
        privateKey: '',
      },
      data:{
        addPublicKey:'',
        addPrivateKey:'',
        publicKeyID:'',
      }
    };
  },
  mounted() {},
  methods: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
    async additionPublicKey(){
      let params = this.form;
       let res = await this.$http.post(this.$api.did.additionPublicKey,params);
       if (res.code == 200) {
         this.data.publicKeyID = res.data;
      }
    },
    async genKeys() {
      let params = {
        isGM:true
      }
      let res = await this.$http.post(this.$api.did.genKeys,params);
      if (res.code == 200) {
        // this.data = res.data;
        this.form.addPublicKey = res.data.publicKey;
        this.data.addPrivateKey = res.data.privateKey;
        this.data.addPublicKey = res.data.publicKey;
      }
    },
  },
};
</script>
<style lang="less" scoped>
.did-content {
  margin-top: 10%;
  h1 {
    color: #666666;
    width: 320px;
    margin: 0 auto;
  }
}
.did-button {
  width: 100px;
  margin: 0 auto;
  margin-top: 20px;
}
.m-a0 {
  margin: 0 auto;
}
.black-h {
  height: 50%;
}
.black-height {
  height: calc(50% - 90px);
  overflow-y: auto;
}
.nodata {
  margin-top: 10%;
}
.did-width {
  width: 500px;
  margin: 0 auto;
}
.publicKey {
  display: flex;
  line-height: 30px;
  .span {
    width:100px;
    text-align: right;
  }
  .span-key {
    width: calc(100% - 50px);
    word-break: break-word;
    white-space: pre-line;
  }
}
</style>
