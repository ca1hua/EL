<template>
  <div class="did-h">
    <div class="black black-h">
      <div>通过DID添加服务。</div>
      <el-tabs v-model="activeName" @tab-click="handleClick">
        <el-tab-pane label="自动添加" name="first">
          <el-row :gutter="20" class="mt3">
            <el-col :span="10" :offset="6">
              <el-form label-position="right" label-width="130px" :model="form">
                <el-form-item label="DID">
                  <el-input v-model="form.did" placeholder="请输入已注册的DID"></el-input>
                </el-form-item>
                <el-form-item label="私钥">
                  <el-input v-model="form.privateKey" placeholder="请输入该DID的私钥"></el-input>
                </el-form-item>
                <el-form-item label="服务类型">
                  <el-input v-model="form.serviceType" placeholder="请输入需要添加的服务类型"></el-input>
                </el-form-item>
                <el-form-item label="服务端点">
                  <el-input v-model="form.serviceEndpoint" placeholder="请输入需要添加的服务端点"></el-input>
                </el-form-item>
              </el-form>
            </el-col>
          </el-row>
          <div class="did-button">
            <el-button size="medium" type="primary" @click="settingService">添加服务端点</el-button>
          </div>
        </el-tab-pane>
        <!-- <el-tab-pane label="代理添加" name="second">
          <el-row :gutter="20" class="mt3">
            <el-col :span="10" :offset="6">
              <el-form label-position="right" label-width="130px" :model="form">
                <el-form-item label="DID">
                  <el-input v-model="form.name" placeholder="请输入你的DID"></el-input>
                </el-form-item>
                <el-form-item label="私钥">
                  <el-input v-model="form.region" placeholder="请输入你的私钥"></el-input>
                </el-form-item>
                <el-form-item label="服务类型">
                  <el-input v-model="form.region" placeholder="请输入服务类型"></el-input>
                </el-form-item>
                <el-form-item label="服务端点">
                  <el-input v-model="form.region" placeholder="请输入服务你的端点"></el-input>
                </el-form-item>
              </el-form>
            </el-col>
          </el-row>
          <div class="did-button">
            <el-button size="medium" type="primary">添加service信息</el-button>
          </div>
        </el-tab-pane> -->
      </el-tabs>
    </div>
    <div class="black mt1 black-height text-c" >
          {{data?'成功':''}}
    </div>
  </div>
</template>
<script>
import NoData from '../../../components/noData.vue';
export default {
  components: {
    NoData,
  },
  data() {
    return {
      activeName: 'first',
      form: {
        did: '',
        privateKey: '',
        serviceEndpoint: '',
        serviceType: '',
      },
      data:''
    };
  },
  mounted() {},
  methods: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
   async  settingService(){
     let params = this.form;
      let res = await this.$http.post(this.$api.did.settingService,params);
      if (res.code == 200) {
        this.data = res.data;
      }
    }
  },
};
</script>
<style lang="less" scoped>
.did-content {
  margin-top: 10%;
  h1 {
    color: #666666;
    width: 320px;
    margin: 0 auto;
  }
}
.did-button {
  width: 100px;
  margin: 0 auto;
  margin-top: 20px;
}
.m-a0 {
  margin: 0 auto;
}
.black-h {
  height: 50%;
}
.black-height {
  height: calc(50% - 90px);
}
.nodata {
  margin-top: 10%;
}
.did-width {
  width: 500px;
  margin: 0 auto;
}
.text-c{
  text-align: center;
  font-size: 20px;
  font-weight: 600;
}
</style>
