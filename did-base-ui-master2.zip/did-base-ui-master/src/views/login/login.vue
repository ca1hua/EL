<template>
  <div class="cover">
    <img src="../../assets/img/login/cover.gif" alt="" @click="routerClick" />
  </div>
</template>

<script>
export default {
  methods: {
    routerClick() {
      this.$router.push({ name: 'did' });
    },
  },
};
</script>

<style lang="less" scoped>
.cover {
  width: 100%;
  height: 100%;
  position: absolute;
  img {
    width: 100%;
    height: 100%;
    cursor: pointer;
  }
}
</style>
