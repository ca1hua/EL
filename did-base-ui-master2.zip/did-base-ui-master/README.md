### 
更新时间 2021年11月9日18时59分

# did-base-ui

## 预先条件
1. 安装node.js
2. 安装Vue.js

## Project setup
1. [vue.config.js](vue.config.js)文件的module.exports下devServer.proxy.target设置为FISCO BCOS所在IP地址，
   端口号为后端项目[src/main/resources/application.yml](src/main/resources/application.yml)文件的server.port
2.
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
