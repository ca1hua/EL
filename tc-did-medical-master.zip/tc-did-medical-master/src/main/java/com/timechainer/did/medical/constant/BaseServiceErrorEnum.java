package com.timechainer.atl.atlsaasbaseservice.constant;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

/**
 * @author lqjiang
 * @version 0.0.1
 * @email lqjiang@timechainer.com
 * @date 2021/9/8-4:20 下午
 * Desc:
 */
@NoArgsConstructor
@AllArgsConstructor
public enum BaseServiceErrorEnum {

    CODE_TO_LONG_ERROR(60001, "编号最长为30位"),
    CODE_DESCRIPTION_TO_LONG_ERROR(60002,"编码描述过长"),
    CODE_VALUE_TO_LONG_ERROR(60003,"常量数值过长"),
    CODE_LENGTH_ERROR(60004,"长度过长"),
    CODE_START_ERROR(60005,"起始值大于流水号长度"),
    CODE_STEP_ERROR(60006,"步长错误"),
    PARAM_ERROR(10001,"参数错误"),
    CODE_NOT_EXISTS(60007,"规则不存在"),
    CODE_FIRST_NOT_EXISTS(60008,"规则一段不存在"),
    CODE_TWO_NOT_EXISTS(60009,"规则二段不存在"),
    CODE_THIRD_NOT_EXISTS(60010,"规则三段不存在"),
    CODE_IS_INIT(60011,"编码已被初始化，不可重复初始化"),
    CODE_IS_OVERFLOW(60012,"编码过大，重新设置"),

;

    private int code;
    private String desc;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
