package com.timechainer.did.medical.shiro;

import org.apache.shiro.cache.Cache;
import org.apache.shiro.cache.CacheException;
import org.apache.shiro.cache.CacheManager;

/**
 * @author lpan
 * @version 0.0.1
 * @email lpan@timechainer.com
 * @date 2020/10/20 5:04 下午
 * Desc:
 */
public class CustomCacheManager implements CacheManager {
    @Override
    public <K, V> Cache<K, V> getCache(String s) throws CacheException {
        return new CustomCache<>();
    }
}
