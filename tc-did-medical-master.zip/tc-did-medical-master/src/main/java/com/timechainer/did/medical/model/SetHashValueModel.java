package com.timechainer.did.medical.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

/**
 * 为空存证地址设置hash值接口模板.
 * @author darwindu
 * @date 2020/1/6
 **/
@Data
@ToString
@ApiModel(description = "为空存证地址设置hash值接口模板")
public class SetHashValueModel {

    @ApiModelProperty(name = "hashValue", value = "实现了Hashable接口的任意Object", required = true,
        example = "0xfbd1d8eed20af617cd5c48972e990adfeca7b694e77bd25e02ae1c23eea3fbec")
    private String hashValue;

    @ApiModelProperty(name = "evidenceAddress", value = "存证地址", required = true,
        example = "0x788bfde9ad99376673ed46847294e9b858728045")
    private String evidenceAddress;

    @ApiModelProperty(name = "weid", value = "加签私钥的weid", required = true,
        example = "did:weid:1:0x19607cf2bc4538b49847b43688acf3befc487a41")
    private String weid;
}
