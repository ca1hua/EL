package com.timechainer.did.medical.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.timechainer.did.medical.entity.WebCpt;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date  2021/9/15 11:46 AM
 * @Description //TODO $end$
 **/
@Mapper
public interface WebCptMapper extends BaseMapper<WebCpt> {
}