//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.timechainer.did.medical.component;

import com.timechainer.did.medical.entity.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
public class CacheUtil {
    private static final Logger log = LoggerFactory.getLogger(CacheUtil.class);
    public static String USER_PREFIX = "user:";
    public static String ADMIN_PREFIX = "admin:";
    public static final String CACHE_CAPTCHA = "captcha:";
    public static final long CAPTCHA_TIME = 300L;
    public static final long CAPTCHA_BAND_TIME = 60L;
    public static final String CACHE_LAST_CAPTCHA = "captcha:last:";

    public CacheUtil() {
    }

    public static void deleteUser(String uid) {
        RedisUtil.del(new String[]{USER_PREFIX + uid});
        RedisUtil.del(new String[]{"shiro:refresh_token:" + uid + "*"});
    }

    public static boolean putAdmin(User admin) {
        return admin != null && admin.getDid() != null ? RedisUtil.set(ADMIN_PREFIX + admin.getDid(), admin) : false;
    }

    public static void deleteAdmin(Integer adminId) {
        RedisUtil.del(new String[]{ADMIN_PREFIX + adminId});
        RedisUtil.del(new String[]{"shiro:refresh_token:admin:" + adminId});
    }

    public static User getAdminById(String id) {
        Object obj = RedisUtil.get(ADMIN_PREFIX + String.valueOf(id));
        return obj == null ? null : (User) obj;
    }

    public static boolean putCaptcha(String phone, String code, String bizType) {
        if (!StringUtils.isEmpty(code) && !StringUtils.isEmpty(phone) && !StringUtils.isEmpty(bizType)) {
            if (RedisUtil.get("captcha:last:" + phone) == null) {
                boolean success = RedisUtil.set("captcha:" + phone + ":" + bizType, code, 300L);
                if (success) {
                    RedisUtil.set("captcha:last:" + phone, phone, 60L);
                }

                return success;
            } else {
                return false;
            }
        } else {
            log.error("参数错误, phone={}, code={}, bizType={}", new Object[]{phone, code, bizType});
            return false;
        }
    }

    public static String getCaptcha(String phone, String bizType) {
        return (String) RedisUtil.get("captcha:" + phone + ":" + bizType);
    }
}
