/*
 *       Copyright© (2019) WeBank Co., Ltd.
 *
 *       This file is part of weidentity-sample.
 *
 *       weidentity-sample is free software: you can redistribute it and/or modify
 *       it under the terms of the GNU Lesser General Public License as published by
 *       the Free Software Foundation, either version 3 of the License, or
 *       (at your option) any later version.
 *
 *       weidentity-sample is distributed in the hope that it will be useful,
 *       but WITHOUT ANY WARRANTY; without even the implied warranty of
 *       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *       GNU Lesser General Public License for more details.
 *
 *       You should have received a copy of the GNU Lesser General Public License
 *       along with weidentity-sample.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.timechainer.did.medical.service;

import com.timechainer.did.medical.constant.ApiResult;
import com.timechainer.did.medical.model.DidQueryModel;
import com.timechainer.did.medical.model.DidModel;
import com.webank.weid.protocol.response.CreateWeIdDataResult;
import com.webank.weid.protocol.response.ResponseData;

/**
 * demo interface.
 *
 * @author v_wbgyang
 *
 */
public interface WebWeidService {

    /**
     * Check whether patient DID exist on the blockchain
     * @param didModel did
     * @return result of verify patient DID
     */
    ApiResult<Boolean> isDidExist(DidModel didModel);

    /**
     * Query information of patient DID
     * @param userModel did
     * @return information of patient DID
     */
    ApiResult<DidQueryModel> query(DidModel userModel);

    ResponseData<CreateWeIdDataResult> createWeId();
}
