package com.timechainer.did.medical.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.timechainer.did.medical.constant.ApiResult;
import com.timechainer.did.medical.entity.WebCpt;
import com.timechainer.did.medical.model.CreateCptModel;
import com.timechainer.did.medical.model.QueryCptModel;
import com.timechainer.did.medical.service.WebCptService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;


/**
 * Created with IntelliJ IDEA.
 *
 * @Author:zhangjiaheng
 * @Date: 2021/09/02/12:36 下午
 * @Description:
 */
@Slf4j
@RestController
@RequestMapping("/cpt")
@Api(description = "cpt",
        tags = {"CPT"}, position = 0, hidden = false)
public class CptController {

    @Autowired
    private WebCptService webCptService;

    @ApiOperation(value = "注册CPT")
    @PostMapping("/register")
    @ResponseBody
    public ApiResult<WebCpt> registerCpt(@RequestBody CreateCptModel createCptModel) throws IOException {
        return webCptService.create(createCptModel);
    }

    @ApiOperation(value = "查询CPT")
    @PostMapping("/query")
    @ResponseBody
    public ApiResult<WebCpt> queryCpt(@RequestBody QueryCptModel cptId) throws JsonProcessingException {
        return webCptService.selectById(cptId.getCptId());
    }
}
