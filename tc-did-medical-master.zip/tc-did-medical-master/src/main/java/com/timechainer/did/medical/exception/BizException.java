package com.timechainer.did.medical.exception;

import com.timechainer.did.medical.constant.ErrorCodeEnum;
import lombok.Data;

/**
 * @author lpan
 * @version 0.0.1
 * @email lpan@timechainer.com
 * @date 2020/10/21 3:27 下午
 * Desc:
 */
@Data
public class BizException extends RuntimeException{
    private int code;

    public BizException(int code, String message) {
        super(message);
        this.code = code;
    }

    public BizException(ErrorCodeEnum errorCodeEnum){
        super(errorCodeEnum.getMsg());
        this.code = errorCodeEnum.getCode();
    }

    public BizException(ErrorCodeEnum errorCodeEnum, Throwable cause){
        super(errorCodeEnum.getMsg(), cause);
        this.code = errorCodeEnum.getCode();
    }

    public BizException(String message, Throwable cause) {
        super(message, cause);
    }

    public BizException(Throwable cause) {
        super(cause);
    }

    public BizException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
