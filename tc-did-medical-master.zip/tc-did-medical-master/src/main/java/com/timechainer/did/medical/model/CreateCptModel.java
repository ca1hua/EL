package com.timechainer.did.medical.model;

import com.timechainer.did.medical.constant.CptTypeEnum;
import lombok.Data;

import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author:zhangjiaheng
 * @Date: 2021/09/02/10:45 下午
 * @Description:
 */
@Data
public class CreateCptModel {

    private String title;

    private String description;

    private CptTypeEnum type;

    private Map<String, Object> claim;

    private Integer cptID;
}
