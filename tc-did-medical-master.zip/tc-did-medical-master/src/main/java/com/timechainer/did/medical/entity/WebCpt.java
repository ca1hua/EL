package com.timechainer.did.medical.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.timechainer.did.medical.constant.CptTypeEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date  2021/9/15 11:46 AM
 * @Description //TODO $end$
 **/
@ApiModel(value="com-timechainer-did-medical-entity-WebCpt")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "BCOH.web_cpt")
public class WebCpt {
    @TableId(value = "cpt_id", type = IdType.AUTO)
    @ApiModelProperty(value="")
    private Integer cptId;

    @TableField(value = "cpt_version")
    @ApiModelProperty(value="")
    private Integer cptVersion;

    @TableField(value = "cpt_type")
    @ApiModelProperty(value="")
    private CptTypeEnum cptType;

    @TableField(value = "publisher")
    @ApiModelProperty(value="")
    private String publisher;

    @TableField(value = "created_at")
    @ApiModelProperty(value="")
    private Date createdAt;

    @TableField(value = "claim")
    @ApiModelProperty(value="")
    private String claim;

    @TableField(value = "title")
    @ApiModelProperty(value="")
    private String title;

    @TableField(value = "des")
    @ApiModelProperty(value="")
    private String des;

    @TableField(value = "tx_Id")
    @ApiModelProperty(value="")
    private String txId;

    @TableField(value = "block_height")
    @ApiModelProperty(value="")
    private Long blockHeight;

    public static final String COL_CPT_ID = "cpt_id";

    public static final String COL_CPT_VERSION = "cpt_version";

    public static final String COL_CPT_TYPE = "cpt_type";

    public static final String COL_PUBLISHER = "publisher";

    public static final String COL_CREATED_AT = "created_at";

    public static final String COL_CLAIM = "claim";

    public static final String COL_TITLE = "title";

    public static final String COL_DES = "des";

    public static final String COL_TX_ID = "tx_Id";

    public static final String COL_BLOCK_HEIGHT = "block_height";
}