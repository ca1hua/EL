package com.timechainer.did.medical.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import javax.validation.constraints.NotNull;

/**
 * 创建凭证存证接口（包含关键字和日志）模板.
 * @author VictorLyl
 * @date 2021/9/3
 **/
@Data
@ToString
@ApiModel(description = "创建凭证存证接口（包含日志）模板")
public class CreateEvidenceWithLogModel {

    @ApiModelProperty(name = "credentialId", value = "已创建的凭证ID号", required = true,
            example = "a70d9127-8132-4041-a12d-32545755076a")
    @NotNull(message = "凭证ID不能为空")
    private String credentialId;

    @ApiModelProperty(name = "did", value = "已注册DID", required = true,
            example = "did:weid:1:0x693d4d2bec6c79229f01c020168fb093a5599738")
    private String did;

    @ApiModelProperty(name = "privateKey", value = "已注册DID的私钥", required = true,
            example = "74041054744801473947392169786116757693945589485498694327198269872450350882718")
    @NotNull(message = "私钥不能为空")
    private String privateKey;

    @ApiModelProperty(name = "log", value = "用户自设日志", required = true,
            example = "abc abc")
    private String log;
}
