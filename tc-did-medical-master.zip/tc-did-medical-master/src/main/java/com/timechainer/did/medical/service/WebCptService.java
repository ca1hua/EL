package com.timechainer.did.medical.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.timechainer.did.medical.constant.ApiResult;
import com.timechainer.did.medical.entity.WebCpt;
import com.timechainer.did.medical.model.CreateCptModel;

import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author:zhangjiaheng
 * @Date: 2021/09/03/7:15 上午
 * @Description:
 */
public interface WebCptService {

    ApiResult<WebCpt> create(CreateCptModel createCptModel) throws IOException;

    ApiResult<WebCpt> selectById(long cptId) throws JsonProcessingException;
}

