package com.timechainer.did.medical.constant;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/11 6:27 PM
 * @Description //TODO $
 **/
public enum UserRoleEnum {
    PATIENT(""),
    DOCTOR("5HsGFNLTH5XnQqVAXAee2TxSNrvj"),
    CHEMIST("Fd9bBBEWxDxPPfhLfYHVuei"),
    PHARMACIST("jxT7nvsN2zAwc37US7UKCiS"),
    EXECUTOR("zq35QJFW57zdZoAQCW76pMj"),
    PHARMACY("WuGwQ2jPZxWdfpCvMKACLYH");

    private final String invitationCode;

    public String getCode() {
        return this.invitationCode;
    }

    private UserRoleEnum(String invitationCode) {
        this.invitationCode = invitationCode;
    }
}
