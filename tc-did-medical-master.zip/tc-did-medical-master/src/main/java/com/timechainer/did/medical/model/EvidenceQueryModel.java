package com.timechainer.did.medical.model;

import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.annotation.Nullable;
import java.util.Date;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/16 12:29 PM
 * @Description //TODO $
 **/
@Data
public class EvidenceQueryModel {

    /**
     * 手机号
     */
    @ApiModelProperty(value = "手机号")
    private String cellPhone;

    /**
     * 真实姓名
     */
    @ApiModelProperty(value = "真实姓名")
    private String realName;

    /**
     * 患者DID
     */
    @ApiModelProperty(value = "患者DID")
    private String did;

    /**
     * 性别
     */
    @ApiModelProperty(value = "性别")
    private Byte sex;

    /**
     * 出生日期
     */
    @ApiModelProperty(value = "出生日期")
    private Date birth;

    /**
     * 年龄
     */
    @ApiModelProperty(value = "年龄")
    private int age;

    /**
     * 过敏史
     */
    @ApiModelProperty(value = "过敏史")
    private String allergicHistory;

    /**
     * 检查部门
     */
    @ApiModelProperty(value = "科室、检查部门")
    private String department;

    /**
     * 检查项目
     */
    @ApiModelProperty(value = "病历信息、检查项目、检查结果、药单")
    private String content;

    /**
     * 是否审核
     */
    @ApiModelProperty(value = "是否审核")
    @Nullable
    private Boolean isReview;

    /**
     * 审核结果
     */
    @ApiModelProperty(value = "审核结果")
    @Nullable
    private String result;

    /**
     * 区块高度
     */
    @ApiModelProperty(value = "区块高度")
    private Long blockHeight;

    /**
     * 交易hash值
     */
    @ApiModelProperty(value = "交易hash值")
    private String txHash;
}
