package com.timechainer.did.medical.model;

import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/15 4:58 PM
 * @Description //TODO $
 **/
@Data
public class QueryResultModel {

    @ApiModelProperty(value = "用户DID")
    private String did;

    @ApiModelProperty(value = "用户姓名")
    private String realName;

    /**
     * 性别
     */
    @ApiModelProperty(value = "性别")
    private Byte sex;

    /**
     * 出生日期
     */
    @ApiModelProperty(value = "出生日期")
    private Date birth;

    /**
     * 过敏史
     */
    @ApiModelProperty(value = "过敏史")
    private String allergicHistory;

    /**
     * 检查部门
     */
    @ApiModelProperty(value = "检查部门")
    private String inspectDepartment;

    /**
     * 检查项目
     */
    @ApiModelProperty(value = "检查项目")
    private String inspectItem;

    /**
     * 是否通过
     */
    @ApiModelProperty(value = "是否通过")
    private String isPassed;

    /**
     * 原因
     */
    @ApiModelProperty(value = "原因")
    private String reason;

    /**
     * 区块高度
     */
    @ApiModelProperty(value = "区块高度")
    private Long blockHeight;

    /**
     * 创建evidence时的交易hash值
     */
    @ApiModelProperty(value = "创建evidence时的交易hash值")
    private String txHash;
}
