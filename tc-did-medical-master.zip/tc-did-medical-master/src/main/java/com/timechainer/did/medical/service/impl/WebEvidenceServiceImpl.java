package com.timechainer.did.medical.service.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.timechainer.did.medical.constant.ApiResult;
import com.timechainer.did.medical.constant.ErrorCodeEnum;
import com.timechainer.did.medical.entity.User;
import com.timechainer.did.medical.entity.WebCredential;
import com.timechainer.did.medical.mapper.UserMapper;
import com.timechainer.did.medical.mapper.WebCredentialMapper;
import com.timechainer.did.medical.model.AddLogModel;
import com.timechainer.did.medical.model.EvidenceQueryModel;
import com.timechainer.did.medical.model.QueryEvidenceModel;
import com.timechainer.did.medical.model.VerifyEvidenceModel;
import com.timechainer.did.medical.service.WebEvidenceService;
import com.timechainer.did.medical.util.AgeUtil;
import com.timechainer.did.medical.util.CommonUtils;
import com.webank.weid.constant.ErrorCode;
import com.webank.weid.protocol.base.CredentialPojo;
import com.webank.weid.protocol.base.EvidenceInfo;
import com.webank.weid.protocol.base.EvidenceSignInfo;
import com.webank.weid.protocol.base.WeIdPrivateKey;
import com.webank.weid.protocol.response.ResponseData;
import com.webank.weid.rpc.EvidenceService;
import com.webank.weid.service.impl.EvidenceServiceImpl;
import jodd.util.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * 创建凭证存证接口实现.
 *
 * @author VictorLyl
 * @date 2021/9/3
 **/
@Slf4j
@Service
public class WebEvidenceServiceImpl implements WebEvidenceService {

    @Autowired
    private WebCredentialMapper webCredentialMapper;

    private final EvidenceService evidenceService = new EvidenceServiceImpl();

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private AgeUtil toolService;

    /**
     * 查询凭证存证（凭证ID或关键字）
     *
     * @param queryEvidenceModel query evidence model
     * @return returns signature
     */
    @Override
    public ApiResult<EvidenceQueryModel> queryEvidence(QueryEvidenceModel queryEvidenceModel) {
        WebCredential webCredential = webCredentialMapper.selectOne(new
                QueryWrapper<WebCredential>().eq("credential_hash", queryEvidenceModel.getEvidenceHash()));
        if (null == webCredential){
            return ApiResult.failed(ErrorCodeEnum.CREDENTIAL_IS_NOT_EXIST);
        } else {
            if (webCredential.getCredentialType() != queryEvidenceModel.getCredentialType()) {
                return ApiResult.failed(ErrorCodeEnum.CREDENTIAL_TYPE_NOT_MATCH);
            }
            ResponseData<EvidenceInfo> queryResponse;
            if (StringUtil.isEmpty(queryEvidenceModel.getCustomKey())) {
                queryResponse = evidenceService.getEvidence(queryEvidenceModel.getEvidenceHash());
            } else {
                queryResponse = evidenceService.getEvidenceByCustomKey(queryEvidenceModel.getCustomKey());
            }
            if (queryResponse.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
                return ApiResult.failed(queryResponse.getErrorCode(), queryResponse.getErrorMessage());
            }
            User user = userMapper.selectById(webCredential.getPatientDid());
            if (null == user) {
                return ApiResult.failed(ErrorCodeEnum.PATIENT_NOT_EXIST);
            }

            EvidenceQueryModel evidenceQueryModel = new EvidenceQueryModel();

            BeanUtils.copyProperties(user, evidenceQueryModel);

            // 获取发布和过期时间
            CredentialPojo credentialPojo = JSON.parseObject(webCredential.getCredential(), CredentialPojo.class);
            BeanUtils.copyProperties(credentialPojo, evidenceQueryModel);

            try {
                evidenceQueryModel.setAge(toolService.computeAge(evidenceQueryModel.getBirth()));
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }

            evidenceQueryModel.setDepartment(webCredential.getDepartment());
            evidenceQueryModel.setContent(webCredential.getContent());
            evidenceQueryModel.setBlockHeight(webCredential.getBlockHeight());
            evidenceQueryModel.setTxHash(webCredential.getTxHash());
            if (null != webCredential.getIsPassed()) {
                evidenceQueryModel.setIsReview(webCredential.getIsPassed());
            }
            if (null != webCredential.getReason()) {
                evidenceQueryModel.setResult(webCredential.getReason());
            }

            return ApiResult.success(evidenceQueryModel);
        }
    }

    /**
     * 验证凭证存证（凭证ID）
     *
     * @param verifyEvidenceModel verify evidence model
     * @return returns signature
     */
    @Override
    public ApiResult<Boolean> verifyEvidence(VerifyEvidenceModel verifyEvidenceModel) {
        ResponseData<EvidenceInfo> queryResponse;
        if (StringUtil.isEmpty(verifyEvidenceModel.getCustomKey())) {
            queryResponse = evidenceService.getEvidence(verifyEvidenceModel.getEvidenceHash());
        } else {
            queryResponse = evidenceService.getEvidenceByCustomKey(verifyEvidenceModel.getCustomKey());
        }

        if (ErrorCode.SUCCESS.getCode() != queryResponse.getErrorCode()) {
            return ApiResult.success(false);
        }

        WebCredential webCredential = webCredentialMapper.selectOne(new QueryWrapper<WebCredential>()
                .eq("credential_hash", verifyEvidenceModel.getEvidenceHash()));

        User user = userMapper.selectOne(new QueryWrapper<User>().eq("did", webCredential.getIssuer()));
        verifyEvidenceModel.setDid(user.getDid());
        verifyEvidenceModel.setPublicKey(user.getPublicKey());

        CredentialPojo credentialPojo = JSON.parseObject(webCredential.getCredential(), CredentialPojo.class);
        ResponseData<Boolean> verifyResult;
        // 验证某签名者的签名是否有效
        if (null != verifyEvidenceModel.getPublicKey()) {
            verifyResult = evidenceService.verifySigner(credentialPojo, queryResponse.getResult(),
                    verifyEvidenceModel.getDid(), verifyEvidenceModel.getPublicKey());
        } else {
            verifyResult = evidenceService.verifySigner(credentialPojo, queryResponse.getResult(),
                    verifyEvidenceModel.getDid());
        }
        if (verifyResult.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            return ApiResult.success(false);
        } else {
            return ApiResult.success(true);
        }
    }

    /**
     * 添加日志
     *
     * @param addLogModel add log model
     * @return returns status of add log (success or error)
     */
    @Override
    public ApiResult<ResponseData<Boolean>> addLog(AddLogModel addLogModel) {

        WeIdPrivateKey weIdPrivateKey = new WeIdPrivateKey();
        weIdPrivateKey.setPrivateKey(addLogModel.getPrivateKey());
        ResponseData<Boolean> responseData;
        if (null == addLogModel.getCustomKey()) {
            responseData = evidenceService.addSignatureAndLogByHash(addLogModel.getEvidenceHash(),
                    addLogModel.getLog(), weIdPrivateKey);
        } else {
            responseData = evidenceService.addSignatureAndLogByCustomKey(addLogModel.getEvidenceHash(),
                    addLogModel.getCustomKey(), addLogModel.getLog(), weIdPrivateKey);
        }
        if (responseData.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            return ApiResult.failed(responseData.getErrorCode(), responseData.getErrorMessage());
        }

        ResponseData<EvidenceInfo> queryResponse;
        if (StringUtil.isEmpty(addLogModel.getCustomKey())) {
            queryResponse = evidenceService.getEvidence(addLogModel.getEvidenceHash());
        } else {
            queryResponse = evidenceService.getEvidenceByCustomKey(addLogModel.getCustomKey());
        }
        if (ErrorCode.SUCCESS.getCode() != queryResponse.getErrorCode()) {
            return ApiResult.failed(queryResponse.getErrorCode(), queryResponse.getErrorMessage());
        }

        Map<String, EvidenceSignInfo> info = queryResponse.getResult().getSignInfo();
        webCredentialMapper.updateLogByPrimaryKey(queryResponse.getResult().getCredentialHash(), CommonUtils.formatObjectToString(info));

        return ApiResult.success(responseData);
    }
}
