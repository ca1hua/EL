package com.timechainer.did.medical.service.impl;

import com.timechainer.did.medical.util.AgeUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.Date;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/14 4:29 PM
 * @Description //TODO $end$
 **/
@Slf4j
@Service
public class AgeUtilImpl implements AgeUtil {

    /**
     * 实现出生日期到年纪的转换
     * @param datetime date time
     * @return age
     * @throws IllegalAccessException illegal access exception
     */
    @Override
    public int computeAge(Date datetime) throws IllegalAccessException {
        Calendar calendar = Calendar.getInstance();
        if (calendar.before(datetime)){
            throw new IllegalAccessException("The birthDay is before Now.It's unbelievable!");
        }
        int yearNow =  calendar.get(Calendar.YEAR);
        int monthNow = calendar.get(Calendar.MONTH);
        int dayOfMonthNow = calendar.get(Calendar.DAY_OF_MONTH);
        calendar.setTime(datetime);
        int yearBirth = calendar.get(Calendar.YEAR);
        int monthBirth = calendar.get(Calendar.MONTH);
        int dayOfMonthBirth = calendar.get(Calendar.DAY_OF_MONTH);
        int age = yearNow - yearBirth;
        return monthNow <= monthBirth ? (monthNow == monthBirth && dayOfMonthNow < dayOfMonthBirth ? age-1 : age ) : age;
    }
}
