package com.timechainer.did.medical.shiro;

import org.apache.shiro.authc.AuthenticationToken;

/**
 * @author lpan
 * @version 0.0.1
 * @email lpan@timechainer.com
 * @date 2020/10/20 12:41 下午
 * Desc:
 */
public class JwtToken implements AuthenticationToken {
    private static final long serialVersionUID = 9048425780065859223L;
    /**
     * Token
     */
    private String token;

    public JwtToken(String token) {
        this.token = token;
    }

    @Override
    public Object getPrincipal() {
        return token;
    }

    @Override
    public Object getCredentials() {
        return token;
    }
}
