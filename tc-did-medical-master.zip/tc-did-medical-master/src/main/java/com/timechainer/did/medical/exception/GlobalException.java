package com.timechainer.did.medical.exception;


import com.timechainer.did.medical.constant.ApiResult;
import com.timechainer.did.medical.constant.ErrorCodeEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authz.UnauthenticatedException;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.NoHandlerFoundException;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author lpan
 * @version 0.0.1
 * @email lpan@timechainer.com
 * @date 2020/10/20 9:16 下午
 * Desc:
 */
@Slf4j
@ControllerAdvice
public class GlobalException {
    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public ApiResult exceptionHandler(Exception e){
        log.error("Global exception error", e);
        if(e instanceof BizException){
            return ApiResult.failed(((BizException) e).getCode(), e.getMessage());
        }else if (e instanceof ConstraintViolationException){
            List<String> defaultMsg = ((ConstraintViolationException) e).getConstraintViolations()
                    .stream()
                    .map(ConstraintViolation::getMessage)
                    .collect(Collectors.toList());
            return ApiResult.failed(ErrorCodeEnum.PARAM_ERROR.getCode(), defaultMsg.get(0));
        }else if (e instanceof AuthenticationException){
            return ApiResult.failed(ErrorCodeEnum.AUTH_ERROR.getCode(),e.getMessage());
        }else if (e instanceof UnauthenticatedException){
            return ApiResult.failed(ErrorCodeEnum.NO_PERMISSION.getCode(),e.getMessage());
        }else if(e instanceof IllegalAccessException){
            return ApiResult.failed(ErrorCodeEnum.PARAM_ERROR.getCode(), e.getMessage());
        }
        return ApiResult.failed(ErrorCodeEnum.REQUEST_TIMEOUT.getCode(),e.getMessage());
    }

    @ExceptionHandler(NoHandlerFoundException.class)
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    @ResponseBody
    public ApiResult notFoundHandler(){
        return ApiResult.failed(ErrorCodeEnum.NOT_FOUND);
    }

    @ExceptionHandler(BindException.class)
    @ResponseBody
    public ApiResult validateErrorHandler(BindException e) {
        StringBuilder stringBuilder = new StringBuilder();
        e.getBindingResult().getFieldErrors().forEach((fieldError)->{
            stringBuilder.append("["+fieldError.getField()+"]:["+fieldError.getDefaultMessage()+"]");
        });
        return ApiResult.failed(ErrorCodeEnum.PARAM_ERROR.getCode(),stringBuilder.toString());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseBody
    public ApiResult<?> validateErrorHandler(MethodArgumentNotValidException e) {
        StringBuilder stringBuilder = new StringBuilder();
        e.getBindingResult().getFieldErrors().forEach((fieldError)->{
            stringBuilder.append("["+fieldError.getField()+"]:["+fieldError.getDefaultMessage()+"]");
        });
        return ApiResult.failed(ErrorCodeEnum.PARAM_ERROR.getCode(),stringBuilder.toString());
    }
}
