package com.timechainer.did.medical.util;

import com.webank.weid.util.DataToolUtils;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/8/26 12:14 PM
 * @Description //TODO Common Util$
 **/
public class CommonUtils {
    /**
     * format Object to String.
     *
     * @return return JSON string
     */
    public static String formatObjectToString(Object obj) {
        return DataToolUtils.serialize(obj);
    }

}
