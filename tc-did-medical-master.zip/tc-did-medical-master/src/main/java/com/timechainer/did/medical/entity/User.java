package com.timechainer.did.medical.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.timechainer.did.medical.constant.UserRoleEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/15 5:08 PM
 * @Description //TODO $end$
 **/
@ApiModel(value = "com-timechainer-did-medical-entity-User")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "BCOH.`user`")
public class User implements Serializable {

    /**
     * 用户DID
     */
    @TableId(value = "did", type = IdType.AUTO)
    @ApiModelProperty(value = "用户DID")
    private String did;

    /**
     * 用户名
     */
    @TableField(value = "username")
    @ApiModelProperty(value = "用户名")
    private String username;

    /**
     * 密码
     */
    @TableField(value = "`password`")
    @ApiModelProperty(value = "密码")
    private String password;

    /**
     * 手机号
     */
    @TableField(value = "cell_phone")
    @ApiModelProperty(value = "手机号")
    private String cellPhone;

    /**
     * 真实姓名
     */
    @TableField(value = "real_name")
    @ApiModelProperty(value = "真实姓名")
    private String realName;

    /**
     * 身份证号码
     */
    @TableField(value = "id_number")
    @ApiModelProperty(value = "身份证号码")
    private String idNumber;

    /**
     * 用户角色
     */
    @TableField(value = "`role`")
    @ApiModelProperty(value = "用户角色")
    private UserRoleEnum role;

    /**
     * 创建时间
     */
    @TableField(value = "create_time")
    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    /**
     * 性别
     */
    @TableField(value = "sex")
    @ApiModelProperty(value = "性别")
    private Byte sex;

    /**
     * 出生日期
     */
    @TableField(value = "birth")
    @ApiModelProperty(value = "出生日期")
    private Date birth;

    /**
     * 过敏史
     */
    @TableField(value = "allergic_history")
    @ApiModelProperty(value = "过敏史")
    private String allergicHistory;

    /**
     * 部门名称
     */
    @TableField(value = "department")
    @ApiModelProperty(value = "部门名称")
    private String department;

    /**
     * 工商号
     */
    @TableField(value = "business_number")
    @ApiModelProperty(value = "工商号")
    private String businessNumber;

    /**
     * 地址
     */
    @TableField(value = "address")
    @ApiModelProperty(value = "地址")
    private String address;

    /**
     * 区块高度
     */
    @TableField(value = "block_height")
    @ApiModelProperty(value = "区块高度")
    private Long blockHeight;

    /**
     * 创建evidence时的交易hash值
     */
    @TableField(value = "tx_hash")
    @ApiModelProperty(value = "创建evidence时的交易hash值")
    private String txHash;

    /**
     * did document
     */
    @TableField(value = "did_doc")
    @ApiModelProperty(value = "did document")
    private String didDoc;

    @TableField(value = "public_key")
    @ApiModelProperty(value = "")
    private String publicKey;

    @TableField(value = "private_key")
    @ApiModelProperty(value = "")
    private String privateKey;

    public static final String COL_DID = "did";

    public static final String COL_USERNAME = "username";

    public static final String COL_PASSWORD = "password";

    public static final String COL_CELL_PHONE = "cell_phone";

    public static final String COL_REAL_NAME = "real_name";

    public static final String COL_ID_NUMBER = "id_number";

    public static final String COL_ROLE = "role";

    public static final String COL_CREATE_TIME = "create_time";

    public static final String COL_SEX = "sex";

    public static final String COL_BIRTH = "birth";

    public static final String COL_ALLERGIC_HISTORY = "allergic_history";

    public static final String COL_DEPARTMENT = "department";

    public static final String COL_BUSINESS_NUMBER = "business_number";

    public static final String COL_ADDRESS = "address";

    public static final String COL_BLOCK_HEIGHT = "block_height";

    public static final String COL_TX_HASH = "tx_hash";

    public static final String COL_DID_DOC = "did_doc";

    public static final String COL_PUBLIC_KEY = "public_key";

    public static final String COL_PRIVATE_KEY = "private_key";
}