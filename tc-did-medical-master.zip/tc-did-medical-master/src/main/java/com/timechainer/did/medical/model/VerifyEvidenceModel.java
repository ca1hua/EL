package com.timechainer.did.medical.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import javax.validation.constraints.NotNull;

/**
 * 验证凭证存证接口模板.
 * @author VictorLyl
 * @date 2021/9/4
 **/
@Data
@ToString
@ApiModel(description = "存证验签接口模板")
public class VerifyEvidenceModel {

    private String customKey;

    @ApiModelProperty(name = "evidenceHash", value = "凭证哈希", required = true,
            example = "did0x8df99e52e9fa1ba57f2aa10b9bd31490a878c27f755006019702cb9bfb38e470")
    private String evidenceHash;

    @ApiModelProperty(name = "did", value = "已注册DID", required = true,
            example = "did:weid:1:0x693d4d2bec6c79229f01c020168fb093a5599738")
    @NotNull(message = "DID不能为空")
    private String did;

    @ApiModelProperty(name = "weidPublicKeyId", value = "did公钥ID", required = true,
            example = "did:weid:1:0x693d4d2bec6c79229f01c020168fb093a5599738#key:1")
    private String publicKey;
}
