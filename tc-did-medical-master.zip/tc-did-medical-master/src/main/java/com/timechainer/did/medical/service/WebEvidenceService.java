package com.timechainer.did.medical.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.timechainer.did.medical.model.*;
import com.timechainer.did.medical.constant.ApiResult;
import com.webank.weid.protocol.response.ResponseData;

/**
 * 创建凭证存证接口.
 * @author VictorLyl
 * @date 2021/9/3
 **/
public interface WebEvidenceService {

    /**
     * 查询凭证存证（凭证ID或关键字）
     * @param queryEvidenceModel query evidence model
     * @return returns some data of evidence
     */
    ApiResult<EvidenceQueryModel> queryEvidence(QueryEvidenceModel queryEvidenceModel) throws JsonProcessingException;

    /**
     * 验证凭证存证（凭证ID）
     * @param verifyEvidenceModel verify evidence model
     * @return returns status of verify (success or error)
     */
    ApiResult<Boolean> verifyEvidence(VerifyEvidenceModel verifyEvidenceModel) throws JsonProcessingException;

    /**
     * 添加日志
     * @param addLogModel add log model
     * @return returns status of add log (success or error)
     */
    ApiResult<ResponseData<Boolean>> addLog(AddLogModel addLogModel);

}
