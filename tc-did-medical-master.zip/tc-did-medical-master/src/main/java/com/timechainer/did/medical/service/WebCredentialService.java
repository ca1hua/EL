package com.timechainer.did.medical.service;

import com.timechainer.did.medical.model.*;
import com.timechainer.did.medical.constant.ApiResult;
import com.timechainer.did.medical.entity.WebCredential;

/**
 * @email $1602205111@qq.com
 * @author: mayifan
 * @date: 2021/9/2
 * @time: 10:04
 */

public interface WebCredentialService {

     ApiResult<WebCredential> selectById(String id);

     ApiResult<Boolean> verifyById(VerifyPoJoModel verifyPoJoModel);

     ApiResult<CredentialReturnModel> createCredentialPojo(CreateCredentialPojoModel createCredentialPojoModel);

     ApiResult<Boolean> reviewByHash(ReviewModel reviewModel);
}
