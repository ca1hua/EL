package com.timechainer.did.medical.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.timechainer.did.medical.entity.WebCredential;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/15 12:58 PM
 * @Description //TODO $end$
 **/
@Mapper
@Repository
public interface WebCredentialMapper extends BaseMapper<WebCredential> {
    int queryByCredentialHash(@Param("credential_hash") String credentialHash);

    int updateIsPassedByPrimaryKey(@Param("credential_hash") String credentialHash,
                                   @Param("is_passed") Boolean isPassed,
                                   @Param("reason") String reason,
                                   @Param("tx_hash") String tx_hash,
                                   @Param("block_height") Long block_height);

    int updateLogByPrimaryKey(@Param("credential_hash") String credentialHash,
                              @Param("log") String log);
}