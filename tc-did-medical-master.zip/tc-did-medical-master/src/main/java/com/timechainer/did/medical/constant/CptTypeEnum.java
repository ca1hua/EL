package com.timechainer.did.medical.constant;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/11 6:27 PM
 * @Description //TODO $
 **/
public enum CptTypeEnum {

    CASE_LIST,CHECK_LIST,LAB_TEST_LIST,DRUG_LIST
}
