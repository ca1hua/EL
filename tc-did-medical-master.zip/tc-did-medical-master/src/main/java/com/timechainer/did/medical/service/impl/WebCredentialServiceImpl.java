package com.timechainer.did.medical.service.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.timechainer.did.medical.constant.ApiResult;
import com.timechainer.did.medical.constant.CredentialTypeEnum;
import com.timechainer.did.medical.constant.ErrorCodeEnum;
import com.timechainer.did.medical.constant.UserRoleEnum;
import com.timechainer.did.medical.entity.User;
import com.timechainer.did.medical.entity.WebCredential;
import com.timechainer.did.medical.mapper.UserMapper;
import com.timechainer.did.medical.mapper.WebCredentialMapper;
import com.timechainer.did.medical.model.*;
import com.timechainer.did.medical.service.WebCredentialService;
import com.timechainer.did.medical.service.WebEvidenceService;
import com.timechainer.did.medical.util.CommonUtils;
import com.webank.weid.constant.CredentialType;
import com.webank.weid.constant.ErrorCode;
import com.webank.weid.protocol.base.*;
import com.webank.weid.protocol.request.CreateCredentialPojoArgs;
import com.webank.weid.protocol.response.ResponseData;
import com.webank.weid.protocol.response.TransactionInfo;
import com.webank.weid.rpc.CredentialPojoService;
import com.webank.weid.rpc.EvidenceService;
import com.webank.weid.service.impl.CredentialPojoServiceImpl;
import com.webank.weid.service.impl.EvidenceServiceImpl;
import com.webank.weid.util.DataToolUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.SecurityUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Map;

/**
 * @email $1602205111@qq.com
 * @author: mayifan
 * @date: 2021/9/2
 * @time: 10:04
 */
@Slf4j
@Service
public class WebCredentialServiceImpl implements WebCredentialService {

    @Autowired
    private WebCredentialMapper credentialMapper;

    private final EvidenceService evidenceService = new EvidenceServiceImpl();

    private final CredentialPojoService credentialPojoService = new CredentialPojoServiceImpl();

    @Autowired
    private WebEvidenceService webEvidenceService;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private WebCredentialMapper webCredentialMapper;

    private static final long EXPIRATION_DATE  = 1000L * 60 * 60 * 24 * 365;

    /**
     * 按照凭证ID查询相关的证书信息
     * @param id
     * @return
     */
    @Override
    public ApiResult<WebCredential> selectById(String id) {
        WebCredential webCredential = credentialMapper.selectById(id);
        if (null == webCredential) {
            return ApiResult.failed(ErrorCode.CREDENTIAL_CPT_NOT_EXISTS);
        }
        else {
            return ApiResult.success(credentialMapper.selectById(id));
        }
    }

    @Override
    public ApiResult<Boolean> verifyById(VerifyPoJoModel verifyPoJoModel) {
        WebCredential webCredentialResult = credentialMapper.selectById(verifyPoJoModel.getCredentialID());
        // 查询为空
        if (null == webCredentialResult) {
            return ApiResult.failed(ErrorCodeEnum.CREDENTIAL_IS_NOT_EXIST);
        } else {
            CredentialPojo credentialPojo = JSON.parseObject(webCredentialResult.getCredential(), CredentialPojo.class);
            WeIdPublicKey weIdPublicKey = new WeIdPublicKey();
            weIdPublicKey.setPublicKey(verifyPoJoModel.getPublicKey());
            ResponseData<Boolean> verifyResult =  credentialPojoService.verifyOffline(weIdPublicKey, credentialPojo);

            if (verifyResult.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
                return ApiResult.failed(verifyResult.getErrorCode(), verifyResult.getErrorMessage());
            } else {
                return ApiResult.success(verifyResult.getResult());
            }
        }
    }

    @Override
    public ApiResult<CredentialReturnModel> createCredentialPojo(
            CreateCredentialPojoModel createCredentialPojoModel) {

        String methodName = Thread.currentThread().getStackTrace()[1].getMethodName();
        log.info("{} createCredentialPojoModel: {}", methodName,
                DataToolUtils.objToJsonStrWithNoPretty(createCredentialPojoModel));

        if (null == createCredentialPojoModel
                || createCredentialPojoModel.getClaimData().isEmpty()
        ) {
            return ApiResult.failed(ErrorCode.ILLEGAL_INPUT);
        }
        String did;
        try {
            did = (String) createCredentialPojoModel.getClaimData().get("did");
        } catch (NullPointerException e) {
            return ApiResult.failed(ErrorCodeEnum.PLEASE_RETRY_DID);
        }

        User patient = userMapper.selectById(did);
        if (null == patient) {
            return ApiResult.failed(ErrorCodeEnum.USER_NOT_EXIST);
        } else if (UserRoleEnum.PATIENT != patient.getRole()) {
            return ApiResult.failed(ErrorCodeEnum.IS_NOT_PATIENT);
        }

        UserAndRoleModel userAndRole = (UserAndRoleModel) SecurityUtils.getSubject().getPrincipal();

        // 设置创建参数
        CreateCredentialPojoArgs<Map<String, Object>> createCredentialPojoArgs
                = new CreateCredentialPojoArgs<>();

//        createCredentialPojoArgs.setCptId(2000024);
        createCredentialPojoArgs.setCptId(createCredentialPojoModel.getCredentialType().getCode());
        createCredentialPojoArgs.setIssuer(userAndRole.getDid());
        Date expire = null;
        try {
            expire = createCredentialPojoModel.getExpireDate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null == expire) {
            createCredentialPojoArgs.setExpirationDate(System.currentTimeMillis() + EXPIRATION_DATE);
        } else {
            createCredentialPojoArgs.setExpirationDate(createCredentialPojoModel.getExpireDate().getTime());
        }
        createCredentialPojoArgs.setClaim(createCredentialPojoModel.getClaimData());

//        createCredentialPojoArgs.setId("");
//        createCredentialPojoArgs.setContext("");
        createCredentialPojoArgs.setType(CredentialType.ORIGINAL);

        // 设置当前用户的权检信息
        WeIdAuthentication weIdAuthentication = new WeIdAuthentication();
        User user = userMapper.selectById(userAndRole.getDid());
        WeIdPrivateKey weIdPrivateKey = new WeIdPrivateKey();
        weIdPrivateKey.setPrivateKey(user.getPrivateKey());
        weIdAuthentication.setWeId(user.getDid());
        weIdAuthentication.setWeIdPrivateKey(weIdPrivateKey);
        weIdAuthentication.setWeIdPublicKeyId(user.getDid() + "#keys-0");
        createCredentialPojoArgs.setWeIdAuthentication(weIdAuthentication);

        ResponseData<CredentialPojo> responseData
                = credentialPojoService.createCredential(createCredentialPojoArgs);
        log.info("{} responseData:{}",
                methodName, DataToolUtils.objToJsonStrWithNoPretty(responseData));
        if (responseData.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            return ApiResult.failed(responseData.getErrorCode(), responseData.getErrorMessage());
        }

        // 直接根据凭证注册 evidence
        ResponseData<String> createResponse;
        if (null != createCredentialPojoModel.getCustomKey()) {
            createResponse = evidenceService.createEvidenceWithLogAndCustomKey(responseData.getResult(), weIdPrivateKey, createCredentialPojoModel.getLogInfo(), createCredentialPojoModel.getCustomKey());
        } else if (null != createCredentialPojoModel.getLogInfo()) {
            createResponse = evidenceService.createEvidenceWithLog(responseData.getResult(), createCredentialPojoModel.getLogInfo(), weIdAuthentication);
        } else {
            createResponse = evidenceService.createEvidence(responseData.getResult(), weIdPrivateKey);
        }
        // 根据 evidenceHash 获取 evidenceInfo
        ResponseData<EvidenceInfo> evidenceInfo = evidenceService.getEvidence(createResponse.getResult());
        if (evidenceInfo.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            return ApiResult.failed(evidenceInfo.getErrorCode(), evidenceInfo.getErrorMessage());
        }

        if (createResponse.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            return ApiResult.failed(createResponse.getErrorCode(), createResponse.getErrorMessage());
        } else {
            savetoDB(responseData.getResult(), createResponse.getTransactionInfo(), createCredentialPojoModel, evidenceInfo.getResult());
            CredentialReturnModel credentialReturnModel = new CredentialReturnModel();
            BeanUtils.copyProperties(responseData.getResult(), credentialReturnModel);
            credentialReturnModel.setTransactionHash(createResponse.getTransactionInfo().getTransactionHash());
            credentialReturnModel.setBlockHeight(createResponse.getTransactionInfo().getBlockNumber().longValue());
            credentialReturnModel.setHash(evidenceInfo.getResult().getCredentialHash());
            return ApiResult.success(credentialReturnModel);
        }
    }

    private void savetoDB(CredentialPojo credentialPojo, TransactionInfo transactionInfo,
                          CreateCredentialPojoModel createCredentialPojoModel, EvidenceInfo evidenceInfo) {

        WebCredential webCredential = new WebCredential();
        webCredential.setCredentialId(credentialPojo.getId());
        webCredential.setCptId(credentialPojo.getCptId());
        webCredential.setIssuer(credentialPojo.getIssuer());
        webCredential.setCredential(CommonUtils.formatObjectToString(credentialPojo));
        webCredential.setIsValid(true);
        webCredential.setCredentialHash(evidenceInfo.getCredentialHash());
        webCredential.setLog(CommonUtils.formatObjectToString(evidenceInfo.getSignInfo()));
        webCredential.setBlockHeight(transactionInfo.getBlockNumber().longValue());
        webCredential.setTxHash(transactionInfo.getTransactionHash());

        webCredential.setPatientDid(createCredentialPojoModel.getClaimData().get("did").toString());

        webCredential.setCredentialType(createCredentialPojoModel.getCredentialType());
        webCredential.setDepartment(createCredentialPojoModel.getClaimData().get("department").toString());
        webCredential.setContent(createCredentialPojoModel.getClaimData().get("content").toString());
        webCredential.setIsPassed(null);
        webCredential.setReason("未审核");
        credentialMapper.insert(webCredential);
    }

    @Override
    public ApiResult<Boolean> reviewByHash(ReviewModel reviewModel) {
        WebCredential webCredential = webCredentialMapper.selectOne(new QueryWrapper<WebCredential>().
                eq("credential_hash", reviewModel.getEvidenceHash()));

        if (null == webCredential){
            return ApiResult.failed(ErrorCodeEnum.CREDENTIAL_IS_NOT_EXIST);
        } else {
            if (webCredential.getCredentialType() == CredentialTypeEnum.CHECKLIST
                    || webCredential.getCredentialType() == CredentialTypeEnum.PRESCRIPTIONS) {

                if (null != webCredential.getIsPassed()) {
                    return ApiResult.failed(ErrorCodeEnum.HAS_BEEN_REVIEW);
                }

                User user = userMapper.selectOne(new QueryWrapper<User>().eq("did", webCredential.getIssuer()));

                AddLogModel addLogModel = new AddLogModel();
                addLogModel.setCustomKey(reviewModel.getCostomKey());
                addLogModel.setWeid(user.getDid());
                addLogModel.setPrivateKey(user.getPrivateKey());
                addLogModel.setEvidenceHash(reviewModel.getEvidenceHash());
                addLogModel.setLog(reviewModel.getLoginfo());

                ResponseData<Boolean> responseData = webEvidenceService.addLog(addLogModel).getData();

                webCredentialMapper.updateIsPassedByPrimaryKey(reviewModel.getEvidenceHash(), reviewModel.getIsPass(), reviewModel.getLoginfo(),
                        responseData.getTransactionInfo().getTransactionHash(), responseData.getTransactionInfo().getBlockNumber().longValue());
                return ApiResult.success(true);
            } else {
                return ApiResult.failed(ErrorCodeEnum.NOT_NEED_REVIEW);
            }
        }
    }
}
