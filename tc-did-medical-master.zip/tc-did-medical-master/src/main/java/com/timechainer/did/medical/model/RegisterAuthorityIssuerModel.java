package com.timechainer.did.medical.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

/**
 * 权威机构认证接口模板.
 * @author v_wbgyang
 * @date 2020/11/23
 **/
@Data
@ToString
@ApiModel(description = "权威机构认证接口模板")
public class RegisterAuthorityIssuerModel {

    @ApiModelProperty(name = "weid", value = "机构weid", required = true,
            example = "did:weid:1:0x19607cf2bc4538b49847b43688acf3befc487a41")
    private String weid;

    @ApiModelProperty(name = "name", value = "机构名称", required = true,
            example = "name")
    private String name;
}
