package com.timechainer.did.medical.model;

import com.timechainer.did.medical.constant.CredentialTypeEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import java.util.Date;
import java.util.Map;

/**
 * 创建电子凭证接口模板.
 * @author darwindu
 * @date 2020/1/6
 **/
@Data
@ToString
@ApiModel(description = "创建电子凭证接口模板")
public class CreateCredentialPojoModel {

    private CredentialTypeEnum credentialType;

    @ApiModelProperty(name = "claimData", value = "claim数据", required = true,
        example = "{\n"
            + "    \n"
            + "    \"age\": 32,\n"
            + "    \"name\": \"zhang san\",\n"
            + "    \"gender\": \"F\"\n"
            + "}")
    private Map<String, Object> claimData;

    @ApiModelProperty(name = "expireDate", value = "过期时间", required = true,
            example = "23456789")
    private Date expireDate;

    private String customKey;

    private String logInfo;
}
