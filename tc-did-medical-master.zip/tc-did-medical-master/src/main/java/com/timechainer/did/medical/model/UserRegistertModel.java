package com.timechainer.did.medical.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.timechainer.did.medical.constant.UserRoleEnum;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author:zhangjiaheng
 * @Date: 2021/09/02/10:45 下午
 * @Description:
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserRegistertModel {

    /**
     * 邀请码
     */
    @ApiModelProperty(value = "邀请码")
    private String invitationCode;

    /**
     * 用户名
     */
    @ApiModelProperty(value = "用户名")
    private String username;

    /**
     * 密码
     */
    @ApiModelProperty(value = "密码")
    private String password;

    /**
     * 确认密码
     */
    @ApiModelProperty(value = "确认密码")
    private String rePassword;

    /**
     * 手机号
     */
    @ApiModelProperty(value = "手机号")
    private String cellPhone;

    /**
     * 真实姓名
     */
    @ApiModelProperty(value = "真实姓名")
    private String realName;

    /**
     * 身份证号码
     */
    @ApiModelProperty(value = "身份证号码")
    private String idNumber;

    /**
     * 用户角色
     */
    @ApiModelProperty(value = "用户角色")
    private UserRoleEnum role;

    /**
     * 性别
     */
    @ApiModelProperty(value = "性别")
    private Byte sex;

    /**
     * 出生日期
     */
    @ApiModelProperty(value = "出生日期")
    private Date birth;

    /**
     * 过敏史
     */
    @ApiModelProperty(value = "过敏史")
    private String allergicHistory;

    /**
     * 部门名称
     */
    @ApiModelProperty(value = "部门名称")
    private String department;

    /**
     * 工商号
     */
    @ApiModelProperty(value = "工商号")
    private String businessNumber;

    /**
     * 地址
     */
    @ApiModelProperty(value = "地址")
    private String address;
}