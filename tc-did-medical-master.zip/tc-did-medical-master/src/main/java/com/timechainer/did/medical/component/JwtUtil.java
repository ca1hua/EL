package com.timechainer.did.medical.component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.timechainer.did.medical.constant.Constant;
import com.timechainer.did.medical.util.Base64ConvertUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;
import java.util.Date;

/**
 * @author lpan
 * @version 0.0.1
 * @email lpan@timechainer.com
 * @date 2020/10/20 12:43 下午
 * Desc:
 */
@Slf4j
@Component
public class JwtUtil {
    /**
     * 过期时间改为从配置文件获取
     */
    private static long accessTokenExpireTime;
    private static long refreshTokenExpireTime;

    /**
     * JWT认证加密私钥(Base64加密)
     */
    private static String encryptJwtKey;

    @Value("${shiro.jwt.accessTokenExpireTime}")
    public void setAccessTokenExpireTime(long accessTokenExpireTime) {
        JwtUtil.accessTokenExpireTime = accessTokenExpireTime;
    }
    @Value("${shiro.jwt.refreshTokenExpireTime}")
    public void setRefreshTokenExpireTime(long refreshTokenExpireTime) {
        JwtUtil.refreshTokenExpireTime = refreshTokenExpireTime;
    }
    @Value("${shiro.jwt.encryptJwtKey}")
    public void setEncryptJwtKey(String encryptJwtKey) {
        JwtUtil.encryptJwtKey = encryptJwtKey;
    }

    public static long getAccessTokenExpireTime() {
        return accessTokenExpireTime;
    }

    public static long getRefreshTokenExpireTime() {
        return refreshTokenExpireTime;
    }

    public static String getEncryptJwtKey() {
        return encryptJwtKey;
    }

    public static void init(long accessTokenExpireTime, long refreshTokenExpireTime, String encryptJwtKey){
        JwtUtil.accessTokenExpireTime = accessTokenExpireTime;
        JwtUtil.refreshTokenExpireTime = refreshTokenExpireTime;
        JwtUtil.encryptJwtKey = encryptJwtKey;
    }


    /**
     * 校验token是否正确
     *
     * @param token Token
     * @return boolean 是否正确
     * @author Wang926454
     * @date 2018/8/31 9:05
     */
    public static boolean verify(String token) throws UnsupportedEncodingException {
        // 帐号加JWT私钥解密
        String secret = getClaim(token, Constant.ACCOUNT) + Base64ConvertUtil.decode(encryptJwtKey);
        Algorithm algorithm = Algorithm.HMAC256(secret);
        JWTVerifier verifier = JWT.require(algorithm).build();
        verifier.verify(token);
        return true;
    }

    /**
     * 获得Token中的信息无需secret解密也能获得
     *
     * @param token
     * @param claim
     * @return java.lang.String
     * @author Wang926454
     * @date 2018/9/7 16:54
     */
    public static String getClaim(String token, String claim) {
        try {
            DecodedJWT jwt = JWT.decode(token);
            // 只能输出String类型，如果是其他类型返回null
            return jwt.getClaim(claim).asString();
        } catch (JWTDecodeException e) {
            log.error("解密Token中的公共信息出现JWTDecodeException异常", e);
            throw e;
        }
    }

    /**
     * 生成签名
     *
     * @param account 帐号
     * @return java.lang.String 返回加密的Token
     * @author Wang926454
     * @date 2018/8/31 9:07
     */
    public static String sign(String account, String currentTimeMillis) throws UnsupportedEncodingException {

        // 帐号加JWT私钥加密
        String secret = account + Base64ConvertUtil.decode(encryptJwtKey);
        // 此处过期时间是以毫秒为单位，所以乘以1000
        Date date = new Date(System.currentTimeMillis() + accessTokenExpireTime * 1000);
        Algorithm algorithm = Algorithm.HMAC256(secret);
        // 附带account帐号信息
        return JWT.create()
                .withClaim("account", account)
                .withClaim("currentTimeMillis", currentTimeMillis)
                .withExpiresAt(date)
                .sign(algorithm);
    }
}
