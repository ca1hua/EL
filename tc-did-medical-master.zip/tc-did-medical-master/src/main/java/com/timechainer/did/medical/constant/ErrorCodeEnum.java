package com.timechainer.did.medical.constant;

/**
 * 错误码表
 */
public enum ErrorCodeEnum {
    ISSUER_IS_REGISTERED(501, "This issue has been registered"),
    ISSUER_IS_NOT_REGISTERED(502, "This issue has not been registered"),
    ISSUER_IS_RECOGNIZE(511, "This issue has been recognized"),
    ISSUER_IS_NOT_RECOGNIZE(512, "This issue has not been recognized"),

    PRIVATE_KEY_NOT_MATCH(601, "Private key does not match"),

    CPT_IS_NOT_EXIST(701, "该CPT不存在"),
    CPT_IS_INVALID(702, "The CPTID you provided is invalid"),

    CREDENTIAL_IS_NOT_EXIST(801, "该凭证不存在"),
    CREDENTIAL_IS_EXPIRED(802, "该凭证已经过期"),

    EVIDENCE_IS_NOT_EXIST(803, "该存证不存在"),
    CREDENTIAL_TYPE_NOT_MATCH(804, "凭证类型不匹配"),

    AUTH_VERIFY_FAILED(901, "账户名密码不匹配"),
    USER_NOT_EXIST(902, "用户不存在"),

    AUTH_ERROR(903, "授权失败"),
    NO_PERMISSION(904, "你没有权限"),
    AUTH_CREATE_JWT_FAILED(905, "JWT授权失败"),

    PARAM_ERROR(1001, "参数验证失败，请检查参数"),
    REQUEST_TIMEOUT(1002, "请求超时"),
    NOT_FOUND(1101, "未找到"),
    NOT_NEED_REVIEW(1201, "该凭证不需要审核"),
    HAS_BEEN_REVIEW(1202, "该凭证已经被审核"),

    PATIENT_NOT_EXIST(1301, "该患者不存在"),
    THIS_USER_CANT_QUERY(1302, "该用户不能被查询"),
    NOT_MATCH_CREDENTIAL_TYPE(1303, "审批单类型不匹配"),
    IS_NOT_PATIENT(1304, "该用户不是患者"),
    PLEASE_RETRY_DID(1305, "请重新输入患者DID"),
    THIS_USER_CANT_VERIFY(1306, "该用户不能被验证");


    private Integer code;
    private String msg;

    public Integer getCode() {
        return this.code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return this.msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    private ErrorCodeEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }
}
