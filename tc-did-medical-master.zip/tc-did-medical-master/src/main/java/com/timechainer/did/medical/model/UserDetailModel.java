package com.timechainer.did.medical.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.timechainer.did.medical.constant.UserRoleEnum;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/16 10:02 AM
 * @Description //TODO $
 **/
@Data
public class UserDetailModel {

    /**
     * 用户DID
     */
    @ApiModelProperty(value = "用户DID")
    private String did;

    /**
     * 用户名
     */
    @ApiModelProperty(value = "用户名")
    private String username;

    /**
     * 手机号
     */
    @ApiModelProperty(value = "手机号")
    private String cellPhone;

    /**
     * 真实姓名
     */
    @ApiModelProperty(value = "真实姓名")
    private String realName;

    /**
     * 身份证号码
     */
    @ApiModelProperty(value = "身份证号码")
    private String idNumber;

    /**
     * 用户角色
     */
    @ApiModelProperty(value = "用户角色")
    private UserRoleEnum role;

    /**
     * 性别
     */
    @ApiModelProperty(value = "性别")
    private Byte sex;

    /**
     * 出生日期
     */
    @ApiModelProperty(value = "出生日期")
    private Date birth;

    /**
     * 年龄
     */
    @ApiModelProperty(value = "年龄")
    private int age;

    /**
     * 过敏史
     */
    @ApiModelProperty(value = "过敏史")
    private String allergicHistory;

    /**
     * 部门名称
     */
    @ApiModelProperty(value = "部门名称")
    private String department;

    /**
     * 工商号
     */
    @ApiModelProperty(value = "工商号")
    private String businessNumber;

    /**
     * 地址
     */
    @ApiModelProperty(value = "地址")
    private String address;

    /**
     * 区块高度
     */
    @ApiModelProperty(value = "区块高度")
    private Long blockHeight;

    /**
     * 创建evidence时的交易hash值
     */
    @ApiModelProperty(value = "创建evidence时的交易hash值")
    private String txHash;

    @TableField(value = "public_key")
    @ApiModelProperty(value = "")
    private String publicKey;

    @TableField(value = "private_key")
    @ApiModelProperty(value = "")
    private String privateKey;

}
