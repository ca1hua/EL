package com.timechainer.did.medical.model;

import com.timechainer.did.medical.constant.CredentialTypeEnum;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/15 3:55 PM
 * @Description //TODO $
 **/
@Data
public class ReviewModel {

    @ApiModelProperty(name = "credentialType", value = "凭证类型", required = true,
            example = "CHECKLIST or PRESCRIPTIONS")
    private CredentialTypeEnum credentialType;

    @ApiModelProperty(name = "evidenceHash", value = "凭证哈希", required = true,
            example = "0x923fe80e2b0da905651626fda28522ca3829d18d6ec609f3eb48fcae88816ba6")
    private String evidenceHash;

    @ApiModelProperty(name = "costomKey", value = "关键字", required = true,
            example = "abc")
    private String costomKey;

    @ApiModelProperty(name = "isPass", value = "审核状态", required = true,
            example = "0 or 1")
    private Boolean isPass;

    @ApiModelProperty(name = "loginfo", value = "审核结果", required = true,
            example = "审核通过")
    private String loginfo;
}
