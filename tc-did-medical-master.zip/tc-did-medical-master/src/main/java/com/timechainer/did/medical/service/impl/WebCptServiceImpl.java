package com.timechainer.did.medical.service.impl;
import com.timechainer.did.medical.constant.ErrorCodeEnum;
import com.webank.weid.constant.CptType;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.timechainer.did.medical.constant.ApiResult;
import com.timechainer.did.medical.entity.User;
import com.timechainer.did.medical.entity.WebCpt;
import com.timechainer.did.medical.mapper.UserMapper;
import com.timechainer.did.medical.mapper.WebCptMapper;
import com.timechainer.did.medical.model.UserAndRoleModel;
import com.timechainer.did.medical.service.WebCptService;
import com.timechainer.did.medical.model.CreateCptModel;
import com.timechainer.did.medical.util.CommonUtils;
import com.timechainer.did.medical.service.WebWeidService;
import com.webank.weid.constant.ErrorCode;
import com.webank.weid.constant.JsonSchemaConstant;
import com.webank.weid.protocol.base.Cpt;
import com.webank.weid.protocol.base.CptBaseInfo;
import com.webank.weid.protocol.base.WeIdAuthentication;
import com.webank.weid.protocol.base.WeIdPrivateKey;
import com.webank.weid.protocol.request.CptMapArgs;
import com.webank.weid.protocol.response.ResponseData;
import com.webank.weid.rpc.CptService;
import com.webank.weid.service.impl.CptServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;


/**
 * Created with IntelliJ IDEA.
 *
 * @Author:zhangjiaheng
 * @Date: 2021/09/03/7:13 上午
 * @Description:
 */
@Slf4j
@Service
public class WebCptServiceImpl implements WebCptService {

    @Autowired
    private WebCptMapper cptMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private WebWeidService weidService;

    private final CptService cptService = new CptServiceImpl();

    /**
     * 存储生成的证书信息
     *
     * @param
     * @return
     */
    @Override
    public ApiResult<WebCpt> create(CreateCptModel createCptModel) {
        UserAndRoleModel userAndRole = (UserAndRoleModel) SecurityUtils.getSubject().getPrincipal();
        User user = userMapper.selectOne(new QueryWrapper<User>().eq("did", userAndRole.getDid()));
        ResponseData<CptBaseInfo> response = registCpt(user.getDid(),
                user.getPrivateKey(),
                createCptModel.getClaim(),
                createCptModel.getCptID());
        if (response.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            log.info(
                    "registerAuthorityIssuer is result,errorCode:{},errorMessage:{}",
                    response.getErrorCode(),
                    response.getErrorMessage()
            );
            return ApiResult.failed(response.getErrorCode(), response.getErrorMessage());
        }
        response.getResult().getCptId();
        response.getResult().getCptVersion();
        WebCpt cpt = new WebCpt();

        cpt.setCptId(response.getResult().getCptId());
        cpt.setCptVersion(response.getResult().getCptVersion());
        cpt.setCptType(createCptModel.getType());
        cpt.setPublisher(user.getDid());
        cpt.setCreatedAt(new Date());
        cpt.setClaim(CommonUtils.formatObjectToString(createCptModel.getClaim()));
        cpt.setTitle(createCptModel.getTitle());
        cpt.setDes(createCptModel.getDescription());
        cpt.setTxId(response.getTransactionInfo().getTransactionHash());
        cpt.setBlockHeight(response.getTransactionInfo().getBlockNumber().longValue());

        cptMapper.insert(cpt);
        return ApiResult.success(cpt);
    }

    @Override
    public ApiResult<WebCpt> selectById(long cptId) {
        WebCpt cpt = cptMapper.selectById(cptId);
        if (null == cpt) {
            return ApiResult.failed(ErrorCodeEnum.CPT_IS_NOT_EXIST);
        } else {
            ResponseData<Cpt> cptResponseData = queryCpt((int) cptId);
            if (cptResponseData.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
                log.info(
                        "queryCpt is result,errorCode:{},errorMessage:{}",
                        cptResponseData.getErrorCode(),
                        cptResponseData.getErrorMessage()
                );
                return ApiResult.failed(cptResponseData.getErrorCode(),
                        cptResponseData.getErrorMessage());
            }
            return ApiResult.success(cpt);
        }
    }

    /**
     * registered CPT.
     *
     * @param publisher the weId of the publisher
     * @param privateKey the private key of the publisher
     * @param claim claim of CPT
     * @return returns cptBaseInfo
     */
    private ResponseData<CptBaseInfo> registCpt(
            String publisher,
            String privateKey,
            Map<String, Object> claim,
            Integer cptID) {

        // build registerCpt parameters.
        WeIdAuthentication weIdAuthentication = new WeIdAuthentication();
        weIdAuthentication.setWeId(publisher);
        weIdAuthentication.setWeIdPrivateKey(new WeIdPrivateKey());
        weIdAuthentication.getWeIdPrivateKey().setPrivateKey(privateKey);

        CptMapArgs cptMapArgs = new CptMapArgs();

        cptMapArgs.setWeIdAuthentication(weIdAuthentication);
        cptMapArgs.setCptJsonSchema(claim);
        cptMapArgs.setCptType(CptType.ORIGINAL);

        // create CPT by SDK
        ResponseData<CptBaseInfo> response;
        if (null != cptID) {
            response = cptService.registerCpt(cptMapArgs, cptID);
        } else {
            response = cptService.registerCpt(cptMapArgs);
        }
        log.info(
                "registerCpt is result,errorCode:{},errorMessage:{}",
                response.getErrorCode(),
                response.getErrorMessage()
        );
        return response;
    }

    private ResponseData<Cpt> queryCpt(Integer cptId) {
        ResponseData<Cpt> cptResponseData = cptService.queryCpt(cptId);
        log.info(
                "queryCpt is result,errorCode:{},errorMessage:{}",
                cptResponseData.getErrorCode(),
                cptResponseData.getErrorMessage()
        );
        return cptResponseData;
    }
}
