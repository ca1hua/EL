package com.timechainer.did.medical.constant;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/11 6:27 PM
 * @Description //TODO $
 **/
public enum AgentTypeEnum {
    REGISTER, RECOGNIZE, DERECOGNIZE
}
