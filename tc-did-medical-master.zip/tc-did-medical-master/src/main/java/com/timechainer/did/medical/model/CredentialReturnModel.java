package com.timechainer.did.medical.model;

import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/16 8:13 PM
 * @Description //TODO $
 **/
@Data
public class CredentialReturnModel {

    /**
     * Required: The Hash.
     */
    private String hash;

    /**
     * Required: The context field.
     */
    private String context;

    /**
     * Required: The ID.
     */
    private String id;

    /**
     * Required: The CPT type in standard integer format.
     */
    private Integer cptId;

    /**
     * Required: The issuer WeIdentity DID.
     */
    private String issuer;

    /**
     * Required: The create date.
     */
    private Long issuanceDate;

    /**
     * Required: The expire date.
     */
    private Long expirationDate;

    /**
     * Required: The claim data.
     */
    private Map<String, Object> claim;

    /**
     * Required: The credential proof data.
     */
    private Map<String, Object> proof;

    /**
     * Required: The transactionHash.
     */
    private String transactionHash;

    /**
     * Required: The blockHeight.
     */
    private long blockHeight;

}
