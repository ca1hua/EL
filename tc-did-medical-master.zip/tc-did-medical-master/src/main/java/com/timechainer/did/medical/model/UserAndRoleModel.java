package com.timechainer.did.medical.model;

import com.timechainer.did.medical.constant.UserRoleEnum;
import lombok.Data;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/15 3:33 PM
 * @Description //TODO $
 **/
@Data
public class UserAndRoleModel {

    private String did;

    private UserRoleEnum role;
}
