package com.timechainer.did.medical.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.timechainer.did.medical.constant.ApiResult;
import com.timechainer.did.medical.model.*;
import com.timechainer.did.medical.service.WebCredentialService;
import com.timechainer.did.medical.service.WebEvidenceService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @email $1602205111@qq.com
 * @author: mayifan
 * @date: 2021/9/1
 * @time: 10:04
 */
@Slf4j
@RestController
@RequestMapping("/credential")
@Api(description = "credential",
        tags = {"credential"}, position = 0, hidden = false)
public class CredentialController {

    @Autowired
    private WebEvidenceService webEvidenceService;

    @Autowired
    private WebCredentialService webCredentialService;

    @ApiOperation(value = "传入Credential信息生成CredentialPoJo")
    @PostMapping("/createCredentialPojo")
    public ApiResult<CredentialReturnModel> createCredentialPoJo(
            @ApiParam(name = "createCredentialPoJoModel", value = "电子凭证模板")
            @RequestBody CreateCredentialPojoModel createCredentialPojoModel) {
        return webCredentialService.createCredentialPojo(createCredentialPojoModel);
    }

    /**
     * 验证凭证的时候使用的是创建Credential的weid和公钥
     * @param verifyEvidenceModel
     * @return
     * @throws JsonProcessingException
     */
    @ApiOperation(value ="验证凭证存证（凭证ID）")
    @PostMapping("/verifyEvidence")
    @ResponseBody
    public ApiResult<Boolean> verifyEvidence(
            @ApiParam(name="VerifyEvidenceModel", value = "验证凭证存证模板")
            @Valid @RequestBody VerifyEvidenceModel verifyEvidenceModel) throws JsonProcessingException {
        return webEvidenceService.verifyEvidence(verifyEvidenceModel);
    }

    @ApiOperation(value ="查询凭证存证（凭证ID或关键字）")
    @PostMapping("/queryEvidence")
    @ResponseBody
    public ApiResult<EvidenceQueryModel> queryEvidence(
            @ApiParam(name="queryEvidenceModel", value = "查询凭证存证（凭证ID）模板")
            @Valid @RequestBody QueryEvidenceModel queryEvidenceModel) throws JsonProcessingException {
        return webEvidenceService.queryEvidence(queryEvidenceModel);
    }

    @ApiOperation(value = "审核凭证")
    @PostMapping("/review")
    public ApiResult<Boolean> reviewByHash(
            @ApiParam(name = "id", value = "按照ID查询凭证")
            @Valid @RequestBody ReviewModel reviewModel) {
        return webCredentialService.reviewByHash(reviewModel);
    }
}