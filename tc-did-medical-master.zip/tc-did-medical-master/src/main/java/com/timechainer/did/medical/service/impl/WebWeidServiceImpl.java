/*
 *       Copyright© (2019) WeBank Co., Ltd.
 *
 *       This file is part of weidentity-sample.
 *
 *       weidentity-sample is free software: you can redistribute it and/or modify
 *       it under the terms of the GNU Lesser General Public License as published by
 *       the Free Software Foundation, either version 3 of the License, or
 *       (at your option) any later version.
 *
 *       weidentity-sample is distributed in the hope that it will be useful,
 *       but WITHOUT ANY WARRANTY; without even the implied warranty of
 *       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *       GNU Lesser General Public License for more details.
 *
 *       You should have received a copy of the GNU Lesser General Public License
 *       along with weidentity-sample.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.timechainer.did.medical.service.impl;

import com.timechainer.did.medical.constant.ApiResult;
import com.timechainer.did.medical.constant.ErrorCodeEnum;
import com.timechainer.did.medical.constant.UserRoleEnum;
import com.timechainer.did.medical.entity.User;
import com.timechainer.did.medical.mapper.UserMapper;
import com.timechainer.did.medical.mapper.WebCptMapper;
import com.timechainer.did.medical.model.DidQueryModel;
import com.timechainer.did.medical.model.DidModel;
import com.timechainer.did.medical.util.AgeUtil;
import com.timechainer.did.medical.util.FileUtil;
import com.timechainer.did.medical.service.WebWeidService;
import com.timechainer.did.medical.util.PrivateKeyUtil;
import com.webank.weid.constant.ErrorCode;
import com.webank.weid.protocol.base.*;
import com.webank.weid.protocol.request.AuthenticationArgs;
import com.webank.weid.protocol.response.CreateWeIdDataResult;
import com.webank.weid.protocol.response.ResponseData;
import com.webank.weid.rpc.AuthorityIssuerService;
import com.webank.weid.rpc.CptService;
import com.webank.weid.rpc.CredentialPojoService;
import com.webank.weid.rpc.WeIdService;
import com.webank.weid.service.impl.AuthorityIssuerServiceImpl;
import com.webank.weid.service.impl.CptServiceImpl;
import com.webank.weid.service.impl.CredentialPojoServiceImpl;
import com.webank.weid.service.impl.WeIdServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/8/31 2:58 PM
 * @Description //TODO now$
 **/
@Slf4j
@Service
public class WebWeidServiceImpl implements WebWeidService {

    static {
        FileUtil.loadConfigFromEnv();
    }

    private AuthorityIssuerService authorityIssuerService = new AuthorityIssuerServiceImpl();

    private CptService cptService = new CptServiceImpl();

    private CredentialPojoService credentialService = new CredentialPojoServiceImpl();

    private WeIdService weIdService = new WeIdServiceImpl();

    private UserMapper userMapper;

    private WebCptMapper webCptMapper;

    @Autowired
    private AgeUtil toolService;
    
    @Autowired
    public void setInjectedBean(UserMapper userMapper, WebCptMapper webCptMapper) {
        this.userMapper = userMapper;
        this.webCptMapper = webCptMapper;
    }

    /**
     * Check whether patient DID exist on the blockchain
     * @param didModel did
     * @return result of verify patient DID
     */
    @Override
    public ApiResult<Boolean> isDidExist(DidModel didModel){
        ResponseData<Boolean> responseData = weIdService.isWeIdExist(didModel.getDid());
        log.info(
                "isWeIdExist is result,errorCode:{},errorMessage:{}",
                responseData.getErrorCode(),
                responseData.getErrorMessage()
        );

        if (responseData.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            return ApiResult.success(false);
        } else {
            User user = userMapper.selectById(didModel.getDid());
            if (!responseData.getResult() || user.getRole() != UserRoleEnum.PATIENT) {
                return ApiResult.success(false);
            } else {
                return ApiResult.success(true);
            }
        }
    }

    /**
     * Query information of patient DID
     * @param userModel did
     * @return information of patient DID
     */
    @Override
    public ApiResult<DidQueryModel> query(DidModel userModel) {
        ResponseData<Boolean> responseData = weIdService.isWeIdExist(userModel.getDid());
        log.info(
                "isWeIdExist is result,errorCode:{},errorMessage:{}",
                responseData.getErrorCode(),
                responseData.getErrorMessage()
        );
        if (responseData.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            return ApiResult.failed(responseData.getErrorCode(), responseData.getErrorMessage());
        } else {
            User user = userMapper.selectById(userModel.getDid());
            if (!responseData.getResult()) {
                return ApiResult.failed(ErrorCodeEnum.PATIENT_NOT_EXIST);
            } else if (user.getRole() != UserRoleEnum.PATIENT) {
                return ApiResult.failed(ErrorCodeEnum.THIS_USER_CANT_QUERY);
            } else {
                DidQueryModel didQueryModel = new DidQueryModel();
                BeanUtils.copyProperties(user, didQueryModel);
                try {
                    didQueryModel.setAge(toolService.computeAge(didQueryModel.getBirth()));
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
                return ApiResult.success(didQueryModel);
            }
        }
    }

    /**
     * 创建weid.
     * @return
     */
    @Override
    public ResponseData<CreateWeIdDataResult> createWeId() {

        ResponseData<CreateWeIdDataResult> response = createWeIdWithSetAttr();
        // if weId is created successfully, save its private key.
        if (response.getErrorCode() == ErrorCode.SUCCESS.getCode()) {
            PrivateKeyUtil.savePrivateKey(
                    PrivateKeyUtil.KEY_DIR,
                    response.getResult().getWeId(),
                    response.getResult().getUserWeIdPrivateKey().getPrivateKey()
            );
        }
        PrivateKeyUtil.savePrivateKey(
                PrivateKeyUtil.KEY_DIR,
                response.getResult().getWeId(),
                response.getResult().getUserWeIdPrivateKey().getPrivateKey()
        );
        return response;
    }

    /**
     * create weId and set related properties.
     *
     * @return returns the create weId and public private keys
     */
    private ResponseData<CreateWeIdDataResult> createWeIdWithSetAttr() {

        log.info("begin create weId and set attribute");

        // 1, create weId, this method automatically creates public and private keys
        ResponseData<CreateWeIdDataResult> createResult = weIdService.createWeId();
        log.info(
                "weIdService is result,errorCode:{},errorMessage:{}",
                createResult.getErrorCode(), createResult.getErrorMessage()
        );

        if (createResult.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            return createResult;
        }

        // 3, call set authentication
        ResponseData<Boolean> setAuthenticateRes = this.setAuthentication(createResult.getResult());
        if (!setAuthenticateRes.getResult()) {
            createResult.setErrorCode(
                    ErrorCode.getTypeByErrorCode(setAuthenticateRes.getErrorCode())
            );
            return createResult;
        }
        return createResult;
    }

    /**
     * Set Authentication For WeIdentity DID Document.
     *
     * @param createWeIdDataResult createWeIdDataResult the object of CreateWeIdDataResult
     * @return the response data
     */
    private ResponseData<Boolean> setAuthentication(CreateWeIdDataResult createWeIdDataResult) {

        AuthenticationArgs authenticationArgs = new AuthenticationArgs();
        authenticationArgs.setPublicKey(createWeIdDataResult.getUserWeIdPublicKey().getPublicKey());

        ResponseData<Boolean> setResponse = weIdService.setAuthentication(
                createWeIdDataResult.getWeId(),
                authenticationArgs,
                createWeIdDataResult.getUserWeIdPrivateKey());

        log.info(
                "setAuthentication is result,errorCode:{},errorMessage:{}",
                setResponse.getErrorCode(),
                setResponse.getErrorMessage()
        );
        return setResponse;
    }
}
