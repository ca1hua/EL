package com.timechainer.did.medical.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.timechainer.did.medical.constant.UserRoleEnum;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/16 12:03 PM
 * @Description //TODO $
 **/
@Data
public class DidQueryModel {

    /**
     * 用户DID
     */
    @ApiModelProperty(value = "用户DID")
    private String did;

    /**
     * 手机号
     */
    @ApiModelProperty(value = "手机号")
    private String cellPhone;

    /**
     * 真实姓名
     */
    @ApiModelProperty(value = "真实姓名")
    private String realName;

    /**
     * 性别
     */
    @ApiModelProperty(value = "性别")
    private Byte sex;

    /**
     * 出生日期
     */
    @ApiModelProperty(value = "出生日期")
    private Date birth;

    /**
     * 年龄
     */
    @ApiModelProperty(value = "年龄")
    private int age;

    /**
     * 过敏史
     */
    @ApiModelProperty(value = "过敏史")
    private String allergicHistory;

    /**
     * 区块高度
     */
    @ApiModelProperty(value = "区块高度")
    private Long blockHeight;

    /**
     * 创建evidence时的交易hash值
     */
    @ApiModelProperty(value = "创建evidence时的交易hash值")
    private String txHash;
}
