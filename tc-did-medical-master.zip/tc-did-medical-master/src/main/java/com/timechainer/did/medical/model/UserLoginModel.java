package com.timechainer.did.medical.model;

import lombok.Data;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/14 8:48 PM
 * @Description //TODO $
 **/
@Data
public class UserLoginModel {
    private String phoneOrAccount;
    private String password;
}
