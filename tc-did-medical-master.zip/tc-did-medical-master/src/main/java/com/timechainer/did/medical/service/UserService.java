package com.timechainer.did.medical.service;

import com.timechainer.did.medical.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;
import com.timechainer.did.medical.exception.BizException;
import com.timechainer.did.medical.model.UserDetailModel;
import com.timechainer.did.medical.model.UserModel;
import com.timechainer.did.medical.model.UserRegistertModel;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/14 4:29 PM
 * @Description //TODO $end$
 **/
public interface UserService extends IService<User> {

    UserModel login(String phone, String password) throws BizException;

    UserModel register(UserRegistertModel userRegistertModel);

    UserDetailModel queryDetail() throws IllegalAccessException;
}



