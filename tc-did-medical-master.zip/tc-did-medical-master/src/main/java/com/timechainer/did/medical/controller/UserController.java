package com.timechainer.did.medical.controller;


import com.timechainer.did.medical.constant.ApiResult;
import com.timechainer.did.medical.exception.BizException;
import com.timechainer.did.medical.model.UserDetailModel;
import com.timechainer.did.medical.model.UserModel;
import com.timechainer.did.medical.model.UserLoginModel;
import com.timechainer.did.medical.model.UserRegistertModel;
import com.timechainer.did.medical.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * <p>
 * 管理员 前端控制器
 * </p>
 *
 * @author zhangqiye
 * @since 2021-04-19
 */
@Api(tags = "用户")
@RestController
@RequestMapping("/user")
@Slf4j
public class UserController {
    @Lazy
    @Autowired
    private UserService userService;

    @ApiOperation("登录")
    @PostMapping("/login")
    public ApiResult<UserModel> login(@Valid @RequestBody UserLoginModel userLoginModel) throws BizException {
        UserModel adminVo = userService.login(userLoginModel.getPhoneOrAccount(), userLoginModel.getPassword());
        return ApiResult.success(adminVo);
    }

    @ApiOperation("注册")
    @PostMapping("/register")
    public ApiResult<UserModel> register(@Valid @RequestBody UserRegistertModel userRegistertModel) throws BizException {
        UserModel adminVo = userService.register(userRegistertModel);
        return ApiResult.success(adminVo);
    }

    @ApiOperation("查询")
    @PostMapping("/query")
    public ApiResult<UserDetailModel> query() throws BizException, IllegalAccessException {
        UserDetailModel adminVo = userService.queryDetail();
        return ApiResult.success(adminVo);
    }

}

