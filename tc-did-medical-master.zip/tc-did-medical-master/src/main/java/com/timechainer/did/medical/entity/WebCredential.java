package com.timechainer.did.medical.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.timechainer.did.medical.constant.CredentialTypeEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/15 12:58 PM
 * @Description //TODO $end$
 **/
@ApiModel(value = "com-timechainer-did-medical-entity-WebCredential")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "BCOH.web_credential")
public class WebCredential {
    public static final String COL_ISVALID = "isValid";
    public static final String COL_CREDENTIALHASH = "credentialHash";
    public static final String COL_EXPIRATIONDATE = "expirationDate";
    public static final String COL_ISSUANCEDATE = "issuanceDate";
    public static final String COL_CPTID = "cptid";
    public static final String COL_CONTEXT = "context";
    public static final String COL_ISSUANCE_DATE = "issuance_date";
    public static final String COL_EXPIRATION_DATE = "expiration_date";
    public static final String COL_CLAIM = "claim";
    public static final String COL_PROOF = "proof";
    public static final String COL_TYPE = "type";
    public static final String COL_SALT = "salt";
    public static final String COL_TX_ID = "tx_Id";
    public static final String COL_ID = "id";
    /**
     * 凭证ID
     */
    @TableId(value = "credential_id", type = IdType.AUTO)
    @ApiModelProperty(value = "凭证ID")
    private String credentialId;

    @TableField(value = "cpt_id")
    @ApiModelProperty(value = "")
    private Integer cptId;

    /**
     * 凭证发行者ID
     */
    @TableField(value = "issuer")
    @ApiModelProperty(value = "凭证发行者ID")
    private String issuer;

    /**
     * 存储credentialPojo的hash串
     */
    @TableField(value = "credential")
    @ApiModelProperty(value = "存储credentialPojo的hash串")
    private String credential;

    /**
     * 凭证是否有效
     */
    @TableField(value = "is_valid")
    @ApiModelProperty(value = "凭证是否有效")
    private Boolean isValid;

    /**
     * 凭证hash值
     */
    @TableField(value = "credential_hash")
    @ApiModelProperty(value = "凭证hash值")
    private String credentialHash;

    /**
     * credential的log
     */
    @TableField(value = "log")
    @ApiModelProperty(value = "credential的log")
    private String log;

    /**
     * 区块高度
     */
    @TableField(value = "block_height")
    @ApiModelProperty(value = "区块高度")
    private Long blockHeight;

    /**
     * 创建evidence时的交易hash值
     */
    @TableField(value = "tx_hash")
    @ApiModelProperty(value = "创建evidence时的交易hash值")
    private String txHash;

    /**
     * 病人DID
     */
    @TableField(value = "patient_did")
    @ApiModelProperty(value = "病人DID")
    private String patientDid;

    /**
     * 凭证种类
     */
    @TableField(value = "credential_type")
    @ApiModelProperty(value = "凭证种类")
    private CredentialTypeEnum credentialType;

    /**
     * 医生（化验师）所在部门
     */
    @TableField(value = "department")
    @ApiModelProperty(value = "医生（化验师）所在部门")
    private String department;

    /**
     * 凭证内容
     */
    @TableField(value = "content")
    @ApiModelProperty(value = "凭证内容")
    private String content;

    /**
     * 凭证是否通过（检查单和药单需要审核）
     */
    @TableField(value = "is_passed")
    @ApiModelProperty(value = "凭证是否通过（检查单和药单需要审核）")
    private Boolean isPassed;

    /**
     * 凭证驳回原因
     */
    @TableField(value = "reason")
    @ApiModelProperty(value = "凭证驳回原因")
    private String reason;

    public static final String COL_CREDENTIAL_ID = "credential_id";

    public static final String COL_CPT_ID = "cpt_id";

    public static final String COL_ISSUER = "issuer";

    public static final String COL_CREDENTIAL = "credential";

    public static final String COL_IS_VALID = "is_valid";

    public static final String COL_CREDENTIAL_HASH = "credential_hash";

    public static final String COL_LOG = "log";

    public static final String COL_BLOCK_HEIGHT = "block_height";

    public static final String COL_TX_HASH = "tx_hash";

    public static final String COL_PATIENT_DID = "patient_did";

    public static final String COL_CREDENTIAL_TYPE = "credential_type";

    public static final String COL_DEPARTMENT = "department";

    public static final String COL_CONTENT = "content";

    public static final String COL_IS_PASSED = "is_passed";

    public static final String COL_REASON = "reason";
}