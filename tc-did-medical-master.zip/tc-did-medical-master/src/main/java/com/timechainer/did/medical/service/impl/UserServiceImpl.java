package com.timechainer.did.medical.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.timechainer.did.medical.component.CacheUtil;
import com.timechainer.did.medical.component.JwtUtil;
import com.timechainer.did.medical.component.RedisUtil;
import com.timechainer.did.medical.constant.Constant;
import com.timechainer.did.medical.constant.ErrorCodeEnum;
import com.timechainer.did.medical.entity.User;
import com.timechainer.did.medical.exception.BizException;
import com.timechainer.did.medical.mapper.UserMapper;
import com.timechainer.did.medical.model.UserAndRoleModel;
import com.timechainer.did.medical.model.UserDetailModel;
import com.timechainer.did.medical.model.UserModel;
import com.timechainer.did.medical.model.UserRegistertModel;
import com.timechainer.did.medical.util.AgeUtil;
import com.timechainer.did.medical.service.UserService;
import com.timechainer.did.medical.service.WebWeidService;
import com.timechainer.did.medical.shiro.JwtToken;
import com.timechainer.did.medical.util.BCryptUtil;
import com.timechainer.did.medical.util.CommonUtils;
import com.webank.weid.constant.ErrorCode;
import com.webank.weid.protocol.response.CreateWeIdDataResult;
import com.webank.weid.protocol.response.ResponseData;
import com.webank.weid.rpc.WeIdService;
import com.webank.weid.service.impl.WeIdServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.SecurityUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/14 4:29 PM
 * @Description //TODO $end$
 **/
@Slf4j
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private WebWeidService webWeidService;

    @Autowired
    private AgeUtil toolService;

    private final WeIdService weIdService = new WeIdServiceImpl();

    @Override
    public UserModel login(String phone, String password) throws BizException {
        User user = userMapper.selectOne(new QueryWrapper<User>().eq("cell_phone", phone));
        if (user == null){
            throw new BizException(ErrorCodeEnum.USER_NOT_EXIST);
        }
        if(!BCryptUtil.checkpw(password, user.getPassword())){
            throw new BizException(ErrorCodeEnum.AUTH_VERIFY_FAILED);
        }
        String token = login(user);
        UserModel loginDto = new UserModel();
        BeanUtils.copyProperties(user, loginDto);
        loginDto.setToken(token);
        loginDto.setRole(user.getRole());
        return loginDto;
    }

    @Override
    public UserModel register(UserRegistertModel userRegistertModel) {
        Assert.isTrue(Objects.equals(userRegistertModel.getInvitationCode(), userRegistertModel.getRole().getCode()), "邀请码不正确");

        List<User> phone = userMapper.selectList(new QueryWrapper<User>().eq("cell_phone", userRegistertModel.getCellPhone()));
        Assert.isTrue(phone.isEmpty(), "注册手机号已存在");
        Assert.isTrue((userRegistertModel.getPassword() != null && userRegistertModel.getPassword().equals(userRegistertModel.getRePassword())), "密码不一致");

        ResponseData<CreateWeIdDataResult> weidResult = webWeidService.createWeId();
        log.debug("createWeId result:{}", CommonUtils.formatObjectToString(weidResult));
        Assert.isTrue(weidResult.getErrorCode().equals(ErrorCode.SUCCESS.getCode()),"创建用户DID失败，请重试！");

        ResponseData<String> docResult = weIdService.getWeIdDocumentJson(weidResult.getResult().getWeId());
        log.info(
                "getWeIdDocumentJson is result,errorCode:{},errorMessage:{}",
                docResult.getErrorCode(),
                docResult.getErrorMessage()
        );

        // 密码hash
        String password = BCryptUtil.hashpw(userRegistertModel.getPassword(), BCryptUtil.gensalt(6));

        User user = new User();

        user.setDid(weidResult.getResult().getWeId());
        user.setUsername(userRegistertModel.getUsername());
        user.setPassword(password);
        user.setCellPhone(userRegistertModel.getCellPhone());
        user.setRealName(userRegistertModel.getRealName());
        user.setIdNumber(userRegistertModel.getIdNumber());
        user.setRole(userRegistertModel.getRole());
        user.setCreateTime(new Date());
        user.setSex(userRegistertModel.getSex());
        user.setBirth(userRegistertModel.getBirth());
        user.setAllergicHistory(userRegistertModel.getAllergicHistory());
        user.setDepartment(userRegistertModel.getDepartment());
        user.setBusinessNumber(userRegistertModel.getBusinessNumber());
        user.setAddress(userRegistertModel.getAddress());
        user.setBlockHeight(weidResult.getTransactionInfo().getBlockNumber().longValue());
        user.setTxHash(weidResult.getTransactionInfo().getTransactionHash());
        user.setDidDoc(docResult.getResult());

        // 保存公私钥
        user.setPrivateKey(weidResult.getResult().getUserWeIdPrivateKey().getPrivateKey());
        user.setPublicKey(weidResult.getResult().getUserWeIdPublicKey().getPublicKey());

        save(user);

        UserModel userModel = new UserModel();
        userModel.setDid(weidResult.getResult().getWeId());
        userModel.setCellPhone(userRegistertModel.getCellPhone());
        userModel.setRealName(userRegistertModel.getRealName());
        userModel.setUsername(userRegistertModel.getUsername());

        String token = login(user);

        userModel.setToken(token);

        weidResult.setResult(null);

        return userModel;
    }

    @Override
    public UserDetailModel queryDetail() throws IllegalAccessException {
        UserAndRoleModel userAndRole = (UserAndRoleModel) SecurityUtils.getSubject().getPrincipal();

        User user = userMapper.selectOne(new QueryWrapper<User>().eq("did", userAndRole.getDid()));

        UserDetailModel userDetail = new UserDetailModel();
        BeanUtils.copyProperties(user, userDetail);
        if (null != userDetail.getBirth()) {
            userDetail.setAge(toolService.computeAge(userDetail.getBirth()));
        }
        return userDetail;
    }

    private String login (User user) {
        String currentTimeMillis = String.valueOf(System.currentTimeMillis());
        String token = null;
        try {
            token = JwtUtil.sign(user.getDid(),currentTimeMillis);
        } catch (UnsupportedEncodingException e) {
            throw new BizException(ErrorCodeEnum.AUTH_CREATE_JWT_FAILED, e);
        }
        RedisUtil.set(Constant.PREFIX_SHIRO_ADMIN_REFRESH_TOKEN + user.getDid(), currentTimeMillis, JwtUtil.getRefreshTokenExpireTime());
        log.info((String) RedisUtil.get(Constant.PREFIX_SHIRO_ADMIN_REFRESH_TOKEN + user.getDid()));
        JwtToken jwtToken = new JwtToken(token);
        SecurityUtils.getSubject().login(jwtToken);
        CacheUtil.putAdmin(user);
        return token;
    }

}



