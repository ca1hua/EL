package com.timechainer.did.medical.util;

import com.timechainer.did.medical.constant.ApiResult;
import com.timechainer.did.medical.model.KeysModel;

import java.util.Date;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/8/31 2:58 PM
 * @Description //TODO now$
 **/
public interface AgeUtil {

    /**
     * 实现出生日期到年纪的转换
     * @param datetime date time
     * @return age
     * @throws IllegalAccessException illegal access exception
     */
    int computeAge(Date datetime) throws IllegalAccessException;
}
