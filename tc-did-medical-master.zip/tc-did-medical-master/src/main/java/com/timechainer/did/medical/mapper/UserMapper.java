package com.timechainer.did.medical.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.timechainer.did.medical.entity.User;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/15 5:08 PM
 * @Description //TODO $end$
 **/
@Mapper
public interface UserMapper extends BaseMapper<User> {
}