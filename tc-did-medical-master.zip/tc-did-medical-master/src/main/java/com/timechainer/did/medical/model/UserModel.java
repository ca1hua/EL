package com.timechainer.did.medical.model;

import com.timechainer.did.medical.constant.UserRoleEnum;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/14 4:47 PM
 * @Description //TODO $
 **/
@Data
public class UserModel {
    private static final long serialVersionUID=1L;

    /**
     * 用户DID
     */
    @ApiModelProperty(value = "用户DID")
    private String did;

    /**
     * 手机号
     */
    @ApiModelProperty(value = "手机号")
    private String cellPhone;

    /**
     * 真实姓名
     */
    @ApiModelProperty(value = "真实姓名")
    private String realName;

    /**
     * token
     */
    @ApiModelProperty(value = "token")
    private String token;

    /**
     * 角色
     */
    @ApiModelProperty(value = "角色")
    private UserRoleEnum role;

    /**
     * 用户名
     */
    @ApiModelProperty(value = "用户名")
    private String username;
}
