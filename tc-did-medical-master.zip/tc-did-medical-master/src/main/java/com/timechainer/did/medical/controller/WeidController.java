package com.timechainer.did.medical.controller;

import com.timechainer.did.medical.constant.ApiResult;
import com.timechainer.did.medical.model.DidQueryModel;
import com.timechainer.did.medical.model.DidModel;
import com.timechainer.did.medical.service.WebWeidService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author: renhuikang
 * @date: 2021/8/27 5:13 PM
 * @description:
 * Weid controller
 * @return
 **/
@Slf4j
@RestController
@RequestMapping("/did")
@Api(description = "did",
        tags = {"did"}, position = 0, hidden = false)
public class WeidController {

    @Autowired
    private WebWeidService weidService;

    @ApiOperation(value = "查询DID")
    @PostMapping("/query")
    @ResponseBody
    public ApiResult<DidQueryModel> query(@RequestBody DidModel userModel) {
        return weidService.query(userModel);
    }

    @ApiOperation(value = "验证DID是否在链上")
    @PostMapping("/isExist")
    @ResponseBody
    public ApiResult<Boolean> isDIDExist(@RequestBody DidModel didModel){
        return weidService.isDidExist(didModel);
    }
}
