package com.timechainer.did.medical.constant;

import lombok.Data;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/15 12:44 PM
 * @Description //TODO $
 **/
public enum CredentialTypeEnum {
    CASE_HISTORY(5000000),
    CHECKLIST(5000001),
    LIB_TEST_REPORT(5000002),
    PRESCRIPTIONS(5000003);

    private final Integer code;

    public Integer getCode() {
        return this.code;
    }

    private CredentialTypeEnum(Integer code) {
        this.code = code;
    }


}
