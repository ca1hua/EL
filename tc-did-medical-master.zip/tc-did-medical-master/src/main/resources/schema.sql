create table IF NOT EXISTS authority_agent_log
(
    id int not null AUTO_INCREMENT,
    did VARCHAR(60) null,
    name varchar(100) null,
    acc_value VARCHAR(10) null,
    update_type enum('REGISTER','RECOGNIZE','DERECOGNIZE') null,
    updated_at date null,
    tx_id        char(66) null,
    block_height BIGINT null,
    succeed BOOL not null,
    info varchar(255) null,
    primary key (id)
    );

create table IF NOT EXISTS authority_agent
(
    did VARCHAR(60) not null,
    name varchar(100) not null,
    acc_value VARCHAR(10) null,
    created_at date  null,
    type VARCHAR(30)  not null,
    is_issuer BOOL default false not null,
    is_valid BOOL default false not null,
    tx_id        char(66) not null,
    block_height BIGINT null,
    info varchar(255) null,
    primary key (did)
    );

CREATE TABLE IF NOT EXISTS `user` (
                                      `did` char(60) COLLATE utf8_croatian_ci NOT NULL,
                                      `username` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '用户名',
                                      `password` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '密码',
                                      `cell_phone` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '手机号',
                                      `real_name` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '真实姓名',
                                      `id_number` varchar(20) COLLATE utf8_croatian_ci DEFAULT NULL COMMENT '身份证号码',
                                      `role` enum('PATIENT','DOCTOR','CHEMIST','PHARMACIST','EXECUTOR','PHARMACY') NOT NULL COMMENT '用户角色',
                                      `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                                      `sex` tinyint(2) DEFAULT NULL COMMENT '性别',
                                      `birth` datetime DEFAULT NULL COMMENT '出生日期',
                                      `allergic_history` varchar(255) COLLATE utf8_croatian_ci DEFAULT NULL COMMENT '过敏史',
                                      `department` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '部门名称',
                                      `business_number` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '工商号',
                                      `address` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '地址',
                                      `block_height` bigint(20) DEFAULT NULL COMMENT '区块高度',
                                      `tx_hash` char(66) DEFAULT NULL COMMENT '创建evidence时的交易hash值',
                                      `did_doc` varchar(1200) NULL COMMENT 'did document',
                                      `public_key` varchar(255) COLLATE utf8_croatian_ci NOT NULL,
                                      `private_key` varchar(255) COLLATE utf8_croatian_ci NOT NULL,

                                      PRIMARY KEY (`did`),
                                      KEY ```cell_phone``` (`cell_phone`) USING BTREE,
                                      KEY ```real_name``` (`real_name`) USING BTREE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `web_cpt` (
                                         `cpt_id` int(20) NOT NULL COMMENT 'CPT ID',
                                         `cpt_version` int(6) DEFAULT NULL COMMENT 'CPT 版本',
                                         `cpt_type` enum('CASE_LIST','CHECK_LIST','LAB_TEST_LIST','DRUG_LIST') NULL COMMENT 'CPT 类型',
                                         `publisher` varchar(60) DEFAULT NULL COMMENT 'CPT发行者ID',
                                         `created_at` date DEFAULT NULL COMMENT 'CPT创建时间',
                                         `claim` varchar(500) DEFAULT NULL COMMENT 'CPT的Claim',
                                         `title` varchar(100) DEFAULT NULL COMMENT '该CPT标题',
                                         `des` varchar(400) DEFAULT NULL COMMENT '该CPT描述',
                                         `tx_id` char(66) DEFAULT NULL COMMENT '交易ID',
                                         `block_height` bigint(20) DEFAULT NULL COMMENT '交易区块',
                                         PRIMARY KEY (`cpt_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `web_credential` (
                                                `credential_id` varchar(40) Primary Key COMMENT '凭证ID',
                                                `cpt_id` int(11) DEFAULT NULL,
                                                `issuer` varchar(60) DEFAULT NULL COMMENT '凭证发行者ID',
                                                `credential` json DEFAULT NULL COMMENT '存储credentialPojo的hash串',
                                                `is_valid` tinyint(1) DEFAULT '0' COMMENT '凭证是否有效',
                                                `credential_hash` varchar(80) NOT NULL COMMENT '凭证hash值',
                                                `log` json DEFAULT NULL COMMENT 'credential的log',
                                                `block_height` bigint(20) DEFAULT NULL COMMENT '区块高度',
                                                `tx_hash` char(66) DEFAULT NULL COMMENT '创建evidence时的交易hash值',
                                                `patient_did` varchar(60) CHARACTER SET utf8 COLLATE utf8_croatian_ci NOT NULL COMMENT '病人DID',
                                                `credential_type` enum('CASE_HISTORY','CHECKLIST','LIB_TEST_REPORT','PRESCRIPTIONS') NULL COMMENT '凭证种类',
                                                `department` varchar(50) CHARACTER SET utf8 COLLATE utf8_croatian_ci DEFAULT NULL COMMENT '医生（化验师）所在部门',
                                                `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_croatian_ci DEFAULT NULL COMMENT '凭证内容',
                                                `is_passed` tinyint(1) DEFAULT NULL COMMENT '凭证是否通过（检查单和药单需要审核）',
                                                `reason` text CHARACTER SET utf8 COLLATE utf8_croatian_ci COMMENT '凭证驳回原因'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
