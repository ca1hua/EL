import Vue from 'vue';
import VueRouter from 'vue-router';
const originalPush = VueRouter.prototype.push;
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch((err) => err);
};

Vue.use(VueRouter);

const modulesFiles = require.context('./modules', true, /\.js$/);
var routeMap = [];
modulesFiles.keys().forEach((key) => {
  routeMap = routeMap.concat(modulesFiles(key).default);
});

const routes = [
  {
    path: '/',
    name: 'login',
    component: () => import(/* webpackChunkName: "login" */ '@/views/login/login.vue'),
  },
  {
    path: '/register',
    name: 'register',
    component: () => import(/* webpackChunkName: "register" */ '@/views/login/register.vue'),
  },
  {
    path: '',
    component: () => import('@/layout/index.vue'),
    children: [
      {
        path: '/did',
        name: 'did',
        meta:{ title:'患者DID管理/查询患者DID' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/did/query/query.vue'),
      },
    ],
  },
  ...routeMap,
];

const router = new VueRouter({
  routes,
});

export default router;
