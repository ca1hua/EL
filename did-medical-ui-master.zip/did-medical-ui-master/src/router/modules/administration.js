export default [
  {
    path: '/administration',
    component: () => import('@/layout/index.vue'),
    children: [
      {
        path: '/administration',
        name: 'administration',
        meta:{ title:'医疗凭证管理/创建病历凭证' },
        component: () => import(/* webpackChunkName: "administration" */ '@/views/administration/case/case.vue'),
      },
      {
        path: '/inspect',
        name: 'inspect',
        meta:{ title:'医疗凭证管理/创建检查单凭证' },
        component: () => import(/* webpackChunkName: "inspect" */ '@/views/administration/inspect/inspect.vue'),
      },
      {
        path: '/test',
        name: 'test',
        meta:{ title:'医疗凭证管理/创建化验单凭证' },
        component: () => import(/* webpackChunkName: "test" */ '@/views/administration/test/test.vue'),
      },
      {
        path: '/prescription',
        name: 'prescription',
        meta:{ title:'医疗凭证管理/创建药单凭证' },
        component: () => import(/* webpackChunkName: "prescription" */ '@/views/administration/prescription/prescription.vue'),
      },
      {
        path: '/check',
        name: 'check',
        meta:{ title:'医疗凭证管理/查询病历凭证' },
        component: () => import(/* webpackChunkName: "check" */ '@/views/administration/check/check.vue'),
      },
      {
        path: '/checkInspect',
        name: 'checkInspect',
        meta:{ title:'医疗凭证管理/查询检查单凭证' },
        component: () => import(/* webpackChunkName: "checkInspect" */ '@/views/administration/checkInspect/checkInspect.vue'),
      },
      {
        path: '/laboratory',
        name: 'laboratory',
        meta:{ title:'医疗凭证管理/查询化验单凭证' },
        component: () => import(/* webpackChunkName: "laboratory" */ '@/views/administration/laboratory/laboratory.vue'),
      },
      {
        path: '/checkPrescription',
        name: 'checkPrescription',
        meta:{ title:'医疗凭证管理/查询药单凭证' },
        component: () => import(/* webpackChunkName: "checkPrescription" */ '@/views/administration/checkPrescription/checkPrescription.vue'),
      },
      {
        path: '/examine',
        name: 'examine',
        meta:{ title:'医疗凭证管理/审核检查单凭证' },
        component: () => import(/* webpackChunkName: "examine" */ '@/views/administration/examine/examine.vue'),
      },
      {
        path: '/review',
        name: 'review',
        meta:{ title:'医疗凭证管理/审核药单凭证' },
        component: () => import(/* webpackChunkName: "review" */ '@/views/administration/review/review.vue'),
      },
      {
        path: '/queryVoucher',
        name: 'queryVoucher',
        meta:{ title:'医疗凭证管理/验证凭证' },
        component: () => import(/* webpackChunkName: "queryVoucher" */ '@/views/administration/queryVoucher/queryVoucher.vue'),
      }
      
    ],
  },
];
