export default [
  {
    path: '/personal',
    component: () => import('@/layout/index.vue'),
    children: [
      {
        path: '/personal',
        name: 'personal',
        meta:{ title:'个人信息管理/个人信息' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/personal/personal.vue'),
      },
     
    ],
  },
];
