export default [
  {
    path: '/did',
    component: () => import('@/layout/index.vue'),
    children: [
      {
        path: '/did',
        name: 'did',
        meta:{ title:'患者DID管理/查询患者DID' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/did/query/query.vue'),
      },
      {
        path: '/queryDID',
        name: 'queryDID',
        meta:{ title:'患者DID管理/验证患者DID' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/did/verify/verify.vue'),
      },
    ],
  },
];
