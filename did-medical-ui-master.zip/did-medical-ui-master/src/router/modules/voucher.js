export default [
  {
    path: '/voucher',
    component: () => import('@/layout/index.vue'),
    children: [
      {
        path: '/voucher',
        name: 'voucher',
        meta:{ title:'医疗凭证模板管理/发布医疗凭证模板' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/voucher/register/register.vue'),
      },
      {
        path: '/queryTemplate',
        name: 'queryTemplate',
        meta:{ title:'医疗凭证模板管理/查询医疗凭证模板' },
        component: () => import(/* webpackChunkName: "did" */ '@/views/voucher/queryTemplate/queryTemplate.vue'),
      },
     
    ],
  },
];
