<template>
  <div class="did-h">
    <div class="black black-h">
      <div>通过医疗凭证模板ID查询医疗凭证模板。</div>
      <el-row :gutter="20" class="el-row-black">
        <el-col :span="10" :offset="6">
          <el-form label-position="right" :rules="rules" ref="ruleForm" label-width="140px" :model="form">
            <el-form-item label="医疗凭证模板ID" prop="cptId">
              <el-input v-model="form.cptId" placeholder="请输入医疗凭证模板的ID"></el-input>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
      <div class="did-button">
        <el-button size="medium" type="primary" @click="register">查询</el-button>
      </div>
    </div>
   <el-dialog title="查询成功" :visible.sync="dialogVisible" width="70vh" :before-close="handleClose">
      <el-form ref="form" :model="form" label-width="240px">
        <el-form-item label="医疗凭证模板ID：">{{data.cptId}} </el-form-item>
        <el-form-item label="注册者DID：">{{data.publisher}}  </el-form-item>
        <el-form-item label="医疗凭证模板标题：">{{data.title}}  </el-form-item>
        <el-form-item label="医疗凭证模板描述：">{{data.des}}  </el-form-item>
        <el-form-item label="医疗凭证模板字段数据：">{{data.claim}}  </el-form-item>
        <el-form-item label="区块高度：">{{data.blockHeight}}  </el-form-item>
        <el-form-item label="交易哈希："> {{data.txId}} </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import NoData from '../../../components/noData.vue';
export default {
  components: {
    NoData,
  },
  data() {
    return {
      activeName: 'first',
      form: {
        cptId: '',
      },
      rules: {
        cptId: [{ required: true, message: '请输入CPT模板ID', trigger: 'blur' }],
      },
      data: {
        name:'',
        claim:'',
        des: '',
      },
      dialogVisible:false
    };
  },
  mounted() {},
  methods: {
    register() {
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          this.query();
        } else {
          return false;
        }
      });
    },
    addClick(){
      let arr = [{ name: '', type: '', describe: '' }]
      this.tableData.push(arr);
    },
    delClick(index){
      this.tableData.splice(index,1)
    },
    async query(){
      let res = await this.$http.post(this.$api.voucher.query, this.form);
      if (res.code == 200) {
        this.data = res.data;
        this.dialogVisible = true;
      }
    }
  },
};
</script>
<style lang="less" scoped>
.did-content {
  margin-top: 10%;
  h1 {
    color: #666666;
    width: 320px;
    margin: 0 auto;
  }
}
.did-button {
  width: 100px;
  margin: 0 auto;
  margin-top: 20px;
}
.m-a0 {
  margin: 0 auto;
}
.black-h {
  height: calc(100% - 40px);
  overflow-y: auto;
}
.nodata {
  margin-top: 10%;
}
.did-width {
  width: 500px;
  margin: 0 auto;
}
.text-c {
  text-align: center;
}
.add-button {
  width: 100%;
  padding: 8px 0;
  background: #fca400;
  color: white;
  border: 1px dashed #ccc;
  text-align: center;
  border-radius: 3px;
  margin-top: 10px;
  cursor: pointer;
}
.cursor {
  cursor: pointer;
}
.publicKey {
  display: flex;
  line-height: 30px;
  .span {
    width: 120px;
    text-align: right;
  }
  .span-key {
    width: calc(100% - 50px);
    word-break: break-word;
    white-space: pre-line;
  }
}
.el-row-black{
  margin-top: 100px;
}
</style>
