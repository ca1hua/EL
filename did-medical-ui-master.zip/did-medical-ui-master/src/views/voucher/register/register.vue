<template>
  <div class="did-h">
    <div class="black black-h">
      <div>发布医疗凭证模板。</div>
      <el-row :gutter="20" class="mt3">
        <el-col :span="10" :offset="6">
          <el-form label-position="right" :rules="rules" ref="ruleForm" label-width="150px" :model="form">
            <el-form-item label="医疗凭证模板标题：" prop="title">
              <el-input v-model="form.title" placeholder="请输入医疗凭证模板的标题"></el-input>
            </el-form-item>
            <el-form-item label="医疗凭证模板描述：" prop="description">
              <el-input v-model="form.description" placeholder="请输入医疗凭证模板的描述"></el-input>
            </el-form-item>
            <el-form-item label="医疗凭证模板ID：">
              <el-input v-model="form.cptID" placeholder="请输入医疗凭证模板的ID（大于5000000）" min="5000000" max="99999999"
              ></el-input>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
      <el-table :data="tableData" style="width: 100%">
        <el-table-column type="index" label="序号" align="center"> </el-table-column>
        <el-table-column prop="name" label="字段名" align="center">
          <template slot-scope="scope">
            <el-input v-model="scope.row.department" placeholder="请输入字段名"></el-input>
          </template>
        </el-table-column>
        <el-table-column label="字段描述" align="center">
          <template slot-scope="scope">
            <el-input v-model="scope.row.content" placeholder="请输入字段的描述"></el-input>
          </template>
        </el-table-column>
        <el-table-column align="center" width="50">
          <template slot-scope="scope">
            <i v-if="tableData.length > 1" class="el-icon-remove-outline cursor" @click="delClick(scope.$index)"></i>
          </template>
        </el-table-column>
      </el-table>
      <div class="add-button" @click="addClick">添加</div>
      <div class="did-button">
        <el-button size="medium" type="primary" @click="register">发布</el-button>
      </div>
    </div>
     <el-dialog title="成功" :visible.sync="dialogVisible" width="70vh" :before-close="handleClose">
      <el-form ref="form" :model="form" label-width="240px">
        <el-form-item label="医疗凭证模板ID：">{{data.cptId}} </el-form-item>
        <el-form-item label="发布者DID：">{{data.publisher}}  </el-form-item>
        <el-form-item label="医疗凭证模板标题：">{{data.title}}  </el-form-item>
        <el-form-item label="医疗凭证模板描述：">{{data.des}}  </el-form-item>
        <el-form-item label="医疗凭证模板字段数据：">{{data.claim}}  </el-form-item>
        <el-form-item label="区块高度：">{{data.blockHeight}}  </el-form-item>
        <el-form-item label="交易哈希："> {{data.txId}} </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import NoData from '../../../components/noData.vue';
export default {
  components: {
    NoData,
  },
  data() {
    return {
      activeName: 'first',
      form: {
        title: '',
        cptID: '',
        claim: {}
      },
      tableData: [{ department: '', content: '' }],
      rules: {
        title: [{ required: true, message: '请输入医疗凭证模板的标题', trigger: 'blur' }],
        description: [{ required: true, message: '请输入医疗凭证模板的描述', trigger: 'blur' }],
      },
      data: {
        publisher: '',
        jsonSchema: '',
        claim: '',
      },
      dialogVisible:false
    };
  },
  mounted() {},
  methods: {
    register() {
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          this.voucher();
        } else {
          return false;
        }
      });
    },
    addClick() {
      let arr = { department: '', content: '' };
      this.tableData.push(arr);
    },
    delClick(index) {
      this.tableData.splice(index, 1);
    },
    async voucher() {
      this.form.claim = {};
      this.tableData.forEach((item) => {
        this.form.claim[item.department] = item.content;
      });
      let res = await this.$http.post(this.$api.voucher.register, this.form);
      if (res.code == 200) {
        this.data = res.data;
        this.dialogVisible = true;
      }
    },
  },
};
</script>
<style lang="less" scoped>
.did-content {
  margin-top: 10%;
  h1 {
    color: #666666;
    width: 320px;
    margin: 0 auto;
  }
}
.did-button {
  width: 100px;
  margin: 0 auto;
  margin-top: 20px;
}
.m-a0 {
  margin: 0 auto;
}
.black-h {
  height: calc(100% - 40px);
  overflow-y: auto;
}

.nodata {
  margin-top: 10%;
}
.did-width {
  width: 500px;
  margin: 0 auto;
}
.text-c {
  text-align: center;
}
.add-button {
  width: 100%;
  padding: 8px 0;
  background: #fca400;
  color: white;
  border: 1px dashed #ccc;
  text-align: center;
  border-radius: 3px;
  margin-top: 10px;
  cursor: pointer;
}
.cursor {
  cursor: pointer;
}
.publicKey {
  display: flex;
  line-height: 30px;
  .span {
    width: 120px;
    text-align: right;
  }
  .span-key {
    width: calc(100% - 50px);
    word-break: break-word;
    white-space: pre-line;
  }
}
</style>
