<template>
  <div class="login">
    <div class="login-content">
      <div class="login-right">
        <div class="bai"><img src="../../assets/img/login/bai-logo.svg" alt="" /></div>
        <div class="painting"><img src="../../assets/img/login/painting.svg" alt="" /></div>
      </div>
      <div class="group">
        <div class="group-content">
          <el-form label-position="left" ref="form" :model="form" :rules="rules" label-width="100px">
            <el-form-item label="角色" prop="role">
              <el-select v-model="form.role" placeholder="请选择角色" @change="selectChange">
                <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value"> </el-option>
                <img class="patient" slot="prefix" src="../../assets/img/login/patient.png" alt="" />
              </el-select>
            </el-form-item>
            <el-form-item label="用户名" prop="username">
              <el-input v-model="form.username" placeholder="请输入用户名">
                <img class="patient" slot="prefix" src="../../assets/img/login/realName.png" alt="" />
              </el-input>
            </el-form-item>
            <el-form-item label="手机号" prop="cellPhone">
              <el-input v-model="form.cellPhone" placeholder="请输入手机号">
                <img class="patient" slot="prefix" src="../../assets/img/login/cellPhone.png" alt="" />
              </el-input>
            </el-form-item>
            <el-form-item label="密码" prop="password">
              <el-input v-model="form.password" show-password placeholder="请输入密码">
                <img class="patient" slot="prefix" src="../../assets/img/login/password.png" alt="" />
              </el-input>
            </el-form-item>
            <el-form-item label="确认密码" prop="rePassword">
              <el-input v-model="form.rePassword" show-password placeholder="请再次输入密码">
                <img class="patient" slot="prefix" src="../../assets/img/login/password.png" alt="" />
              </el-input>
            </el-form-item>
            <el-form-item v-if="isShow" :label="form.role == 'PHARMACY' ? '药店名' : '姓名'" prop="realName">
              <el-input v-model="form.realName" :placeholder="form.role == 'PHARMACY' ? '请输入药店名' : '请输入姓名'">
                <img class="patient" slot="prefix" src="../../assets/img/login/realName.png" alt="" />
              </el-input>
            </el-form-item>
            <el-form-item v-if="form.role != 'PHARMACY'" label="出生日期" prop="birth">
              <el-date-picker v-model="form.birth" type="date" placeholder="请选择出生日期"> </el-date-picker>
            </el-form-item>
            <el-form-item v-if="form.role != 'PHARMACY'" label="性别" prop="sex">
              <el-select v-model="form.sex" placeholder="请选择性别">
                <el-option v-for="item in sexOptions" :key="item.value" :label="item.label" :value="item.value"> </el-option>
                <img class="patient" slot="prefix" src="../../assets/img/login/sex.png" alt="" />
              </el-select>
            </el-form-item>
            <el-form-item v-if="form.role != 'PHARMACY'" label="身份证号" prop="idNumber">
              <el-input v-model="form.idNumber" placeholder="请输入身份证号">
                <img class="patient" slot="prefix" src="../../assets/img/login/idNumber.png" alt="" />
              </el-input>
            </el-form-item>
            <el-form-item v-if="form.role == 'DOCTOR' || form.role == 'CHEMIST'" label="所属部门" prop="department">
              <el-input v-model="form.department" placeholder="请输入所属部门">
                <i slot="prefix" class="el-input__icon el-icon-school" alt="" />
              </el-input>
            </el-form-item>
            <el-form-item v-if="form.role == 'PHARMACY'" label="工商注册号" prop="businessNumber">
              <el-input v-model="form.businessNumber" placeholder="请输入工商注册号">
                <i slot="prefix" class="el-input__icon el-icon-postcard" alt="" />
              </el-input>
            </el-form-item>
            <el-form-item v-if="form.role == 'PHARMACY'" label="地址" prop="address">
              <el-input v-model="form.address" placeholder="请输入地址">
                <i slot="prefix" class="el-input__icon el-icon-location-outline" alt="" />
              </el-input>
            </el-form-item>
            <el-form-item v-if="form.role == 'PATIENT'" label="过敏史" prop="allergicHistory">
              <el-input v-model="form.allergicHistory" placeholder="请输入过敏史">
                <i slot="prefix" class="el-input__icon el-icon-edit-outline" alt="" />
              </el-input>
            </el-form-item>
            <el-form-item v-if="form.role != 'PATIENT'" label="邀请码" prop="invitationCode">
              <el-input v-model="form.invitationCode" placeholder="请输入邀请码">
                <i slot="prefix" class="el-input__icon el-icon-edit-outline" alt="" />
              </el-input>
            </el-form-item>
          </el-form>
          <div class="signin" @click="submitForm()">注册</div>
          <div class="register" @click="loginClick">已有账号，立即登录</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  components: {},
  data() {
    var validateConfirmPassword = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入确认密码'));
      } else if (value != this.form.password) {
        callback(new Error('两次密码输入不一致'));
      } else {
        callback();
      }
    };
    var getName = (rule, value, callback) => {
      if (value === '') {
        if (this.form.role == 'PHARMACY') {
          callback(new Error('请输入药店名'));
        } else {
          callback(new Error('请输入姓名'));
        }
      } else {
        callback();
      }
    };
    return {
      form: {
        role: '',
        cellPhone: '',
        password: '',
        rePassword: '',
        sex: '',
        birth: '',
        username: '',
        realName: '',
        idNumber: '',
        department: '',
        businessNumber: '',
        address: '',
        allergicHistory: '',
        invitationCode: '',
      },
      isShow:true,
      options: [
        { label: '患者', value: 'PATIENT' },
        { label: '医生', value: 'DOCTOR' },
        { label: '化验师', value: 'CHEMIST' },
        { label: '药师', value: 'PHARMACIST' },
        { label: '行政医生', value: 'EXECUTOR' },
        { label: '药店', value: 'PHARMACY' },
      ],
      sexOptions: [
        { label: '男', value: '1' },
        { label: '女', value: '0' },
      ],
      rules: {
        role: [{ required: true, message: '请选择角色', trigger: 'blur' }],
        cellPhone: [
          { required: true, message: '请输入手机号', trigger: 'blur' },
          { required: true, pattern: /^1\d{10}$/, message: '手机号格式有误，请重新输入', trigger: 'blur' },
          { min: 11, max: 11, message: '手机号格式有误，请重新输入', trigger: 'blur' },
        ],
        password: [{ required: true, message: '请输入密码', trigger: 'blur' }],
        rePassword: [{ required: true, validator: validateConfirmPassword, trigger: 'blur' }],
        realName: [{ required: true, validator:getName ,trigger: 'blur' }],
        username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
        birth: [{ required: true, message: '请选择出生日期', trigger: 'blur' }],
        sex: [{ required: true, message: '请选择性别', trigger: 'blur' }],
        idNumber: [{ required: true, message: '请输入身份证号', trigger: 'blur' }],
        department: [{ required: true, message: '请输入所属部门', trigger: 'blur' }],
        businessNumber: [{ required: true, message: '请输入工商注册号', trigger: 'blur' }],
        address: [{ required: true, message: '请输入地址', trigger: 'blur' }],
        allergicHistory: [{ required: true, message: '请输入过敏史', trigger: 'blur' }],
      },
    };
  },
  mounted() {},
  methods: {
    loginClick() {
      this.$router.push({ name: 'login' });
    },
    submitForm() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          this.create();
        } else {
          return false;
        }
      });
    },
    async create() {
      let res = await this.$http.post(this.$api.login.create, this.form);
      if (res.code == 200) {
        this.$message.success('注册成功');
        this.$router.push({ name: 'login' });
      }
    },
    selectChange(e) {
      this.$refs.form.resetFields();
      this.form.role = e;
    },
  },
};
</script>
<style lang="less" scoped>
.login {
  position: absolute;
  width: calc(100% - 60px);
  height: calc(100% - 60px);
  background: url('../../assets/img/login/bg-login.png');
  padding: 30px;
  background-size: 100% 100%;
  color: #fff;
  font-size: 16px;
  overflow: auto;
  /deep/ .el-form-item__label {
    color: #c0ceea !important;
    margin-top: 5px;
  }

  /deep/ .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100%;
  }
  /deep/ .el-input--small .el-input__inner {
    background-color: transparent;
    border: 1px solid #374880;
    outline: none;
    color: #fff;
  }
  .login-content {
    display: flex;
    justify-content: space-between;
    margin-top: 1%;
    i {
      color: #6876a2;
    }
    .login-right {
      width: 50%;
      .bai {
        height: 75px;
        width: 260px;
        img {
          width: 100%;
          height: 100%;
        }
      }
      .painting {
        margin-top: 30px;
        img {
          width: 100%;
          height: 100%;
        }
      }
    }

    .group {
      width: 560px;
      background: url(../../assets/img/login/group.png) no-repeat;
      background-size: 100% 100%;
      padding-bottom: 20px;
      padding-left: 130px;
      padding-right: 50px;
    }
    .group-content {
      margin-top: 30px;
    }
  }
  .signin {
    width: 100%;
    height: 40px;
    text-align: center;
    line-height: 40px;
    background: rgba(105, 125, 189, 0.3);
    border-radius: 4px;
    border: 1px solid #374880;
    cursor: pointer;
    margin-top: 20px;
  }
  .register {
    color: #697dbd;
    text-align: right;
    margin-top: 10px;
    cursor: pointer;
  }
  .patient {
    width: 15px;
    margin-left: 3px;
    margin-top: 9px;
  }
}
</style>
