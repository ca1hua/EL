<template>
  <div class="login">
    <div class="login-content">
      <div class="login-right">
        <div class="bai"><img src="../../assets/img/login/bai-logo.svg" alt="" /></div>
        <div class="painting"><img src="../../assets/img/login/painting.svg" alt="" /></div>
      </div>
      <div class="group">
        <div class="logo">
          <img src="../../assets/img/logo.png" alt="" />
        </div>
        <div class="group-content">
          <el-form ref="form" :model="form" label-width="40px">
            <el-form-item label="账号">
              <el-input v-model="form.phoneOrAccount" placeholder="请输入账号">
                <i slot="prefix" class="el-input__icon el-icon-user"></i>
              </el-input>
            </el-form-item>
            <el-form-item label="密码">
              <el-input v-model="form.password" show-password placeholder="请输入密码">
                <i slot="prefix" class="el-input__icon el-icon-lock"></i>
              </el-input>
            </el-form-item>
          </el-form>
          <div class="signin" @click="signinClick()">登录</div>
          <div class="register" @click="registerClick">暂无账号，前去注册</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  components: {},
  data() {
    return {
      form: {
        phoneOrAccount: '',
        password: '',
      },
    };
  },
  mounted() {},
  methods: {
    registerClick() {
      this.$router.push({ name: 'register' });
    },
    signinClick() {
      if(!this.form.phoneOrAccount){
        this.$message.error('请输入账号');
        return
      }
      this.login();
    },
   async login(){
      let res = await this.$http.post(this.$api.login.login,this.form);
      if(res.code == 200){
         localStorage.setItem('token',res.data.token);
         localStorage.setItem('user',res.data.username);
         localStorage.setItem('realName',res.data.realName);
         localStorage.setItem('role',res.data.role);
         if(res.data.role == 'PATIENT'){
           this.$router.push({ name: 'check' });
         }
        if(res.data.role == 'DOCTOR' || res.data.role == 'CHEMIST' || res.data.role == 'PHARMACIST'|| res.data.role == 'EXECUTOR'){
          this.$router.push({ name: 'did' });
        }
        if(res.data.role == 'PHARMACY'){
          this.$router.push({ name: 'queryDID' });
        }

      }
    },
  },
};
</script>
<style lang="less" scoped>
.login {
  position: absolute;
  width: calc(100% - 60px);
  height: calc(100% - 60px);
  background: url('../../assets/img/login/bg-login.png');
  padding: 30px;
  background-size: 100% 100%;
  color: #fff;
  font-size: 16px;
  overflow: auto;
  /deep/ .el-form-item__label {
    color: #c0ceea !important;
    margin-top: 5px;
  }
  /deep/ .el-form-item--small.el-form-item {
    margin-bottom: 20px;
  }
  /deep/ .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100%;
  }
  /deep/ .el-input--small .el-input__inner {
    background-color: transparent;
    border: 1px solid #374880;
    outline: none;
    color: #fff;
    padding-top: 20px;
    padding-bottom: 20px;
  }
  .login-content {
    display: flex;
    justify-content: space-between;
    margin-top: 1%;
    i {
      color: #6876a2;
    }
    .login-right {
      width: 50%;
      .bai {
        height: 75px;
        width: 260px;
        img {
          width: 100%;
          height: 100%;
        }
      }
      .painting {
        margin-top: 30px;
        img {
          width: 100%;
          height: 100%;
        }
      }
    }

    .group {
      width: 560px;
      background: url(../../assets/img/login/group.png) no-repeat;
      background-size: 100% 100%;
      padding-bottom: 60px;
      padding-left: 130px;
      padding-right: 50px;
      margin-top: 100px;
    }
    .logo {
      margin-top: 100px;
    }
    .group-content {
      margin-top: 10px;
    }
  }
  .signin {
    width: 100%;
    height: 60px;
    text-align: center;
    line-height: 60px;
    background: rgba(105, 125, 189, 0.3);
    border-radius: 4px;
    border: 1px solid #374880;
    margin-top: 10px;
    cursor: pointer;
  }
  .register {
    color: #697dbd;
    text-align: right;
    margin-top: 10px;
    cursor: pointer;
  }
  .patient {
    width: 18px;
    margin-top: 12px;
  }
}
</style>
