<template>
  <div class="did-h">
    <div class="black black-h">
      <div>输入患者DID查询患者信息。</div>
      <el-row :gutter="20" class="mt3">
        <el-col :span="10" :offset="6">
          <el-form label-position="right" label-width="80px" :model="form">
            <el-form-item label="DID">
              <el-input v-model="form.did" placeholder="请输入患者的DID"></el-input>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
      <div class="did-button">
        <el-button size="medium" type="primary" @click="queryByDid">查询患者DID</el-button>
      </div>
    </div>
    <div class="black mt1 black-height">
      <el-row :gutter="20" class="mt3">
        <el-col :span="10" :offset="4">
          <ul>
            <li class="did">
              <span class="span">DID：</span>
              <span class="span-key">{{ data.did }}</span>
            </li>
          </ul>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="10" :offset="4">
          <ul>
            <li class="age">
              <span class="span">患者年龄：</span>
              <span class="span-key">{{ data.age }}</span>
            </li>
            <li class="allergicHistory">
              <span class="span">患者过敏史：</span>
              <span class="span-key">{{ data.allergicHistory }}</span>
            </li>
          </ul>
        </el-col>
        <el-col :span="10">
          <ul>
            <li class="realName">
              <span class="span">患者姓名：</span>
              <span class="span-key">{{ data.realName }}</span>
            </li>
            <li class="sex">
              <span class="span">患者性别：</span>
              <span class="span-key">{{ data.sex==null?'':(data.sex==null?"":(data.sex==1?'男':'女'))}}</span>
            </li>
          </ul>
        </el-col>
      </el-row>
    </div>
    <div class="black mt1 black-height">
     <div class="black-information">交易信息</div>
      <el-row :gutter="20">
        <el-col :span="10" :offset="4">
          <ul>
            <li class="blockHeight">
              <span class="span">区块高度：</span>
              <span class="span-key">{{ data.blockHeight }}</span>
            </li>
            <li class="txHash">
              <span class="span">交易Hash：</span>
              <span class="span-key">{{ data.txHash }}</span>
            </li>
          </ul>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
import NoData from '../../../components/noData.vue';
export default {
  components: {
    NoData,
  },
  data() {
    return {
      activeName: 'first',
      form: {
        did: '',
      },
      formDID: {},
      data: {
        userWeIdPublicKey: {
          publicKey: '',
        },
        userWeIdPrivateKey: {
          privateKey: '',
        },
        weId: '',
      },
    };
  },
  mounted() {},
  methods: {
    async queryByDid() {
      let params = this.form;
      let res = await this.$http.post(this.$api.did.query, params);
      if (res.code == 200) {
        this.data = res.data;
      }
    },
  },
};
</script>
<style lang="less" scoped>
.did-content {
  margin-top: 10%;
  h1 {
    color: #666666;
    width: 320px;
    margin: 0 auto;
  }
}
.did-button {
  width: 100px;
  margin: 0 auto;
  margin-top: 20px;
}
.m-a0 {
  margin: 0 auto;
}
.black-h {
}
.black-height {
  height: 33%;
}
.nodata {
  margin-top: 10%;
}
.did-width {
  width: 500px;
  margin: 0 auto;
}
.publicKey {
  display: flex;
  line-height: 30px;
  .span {
    width: 150px;
    text-align: right;
  }
  .span-key {
    width: calc(100% - 50px);
    word-break: break-word;
    white-space: pre-line;
  }
 
}
 .black-information{
    text-align: center;
    font-size: 20px;
  }
</style>
