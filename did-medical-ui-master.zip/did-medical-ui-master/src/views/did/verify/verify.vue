<template>
  <div class="did-h">
    <div class="black black-h">
      <div>输入患者DID验证患者DID是否合法。</div>
      <el-row :gutter="20" class="mt3">
        <el-col :span="10" :offset="6">
          <el-form label-position="right" label-width="80px" :model="form">
            <el-form-item label="DID">
              <el-input v-model="form.did" placeholder="请输入患者的DID"></el-input>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
      <div class="did-button">
        <el-button size="medium" type="primary" @click="isExist">验证患者DID</el-button>
      </div>
    </div>
    <div class="black mt1 black-height">
      <span v-if="isdata"> {{ data ? '验证成功' : '验证失败' }}</span>
    </div>
  </div>
</template>
<script>
import NoData from '../../../components/noData.vue';
export default {
  components: {
    NoData,
  },
  data() {
    return {
      activeName: 'first',
      form: {
        did: '',
      },
      data: '',
      isdata: false,
    };
  },

  mounted() {},
  methods: {
    async isExist() {
      this.isdata = false;
      let res = await this.$http.post(this.$api.did.isExist, this.form);
      if (res.code == 200) {
        this.isdata = true;
        this.data = res.data;
      }
    },
  },
};
</script>
<style lang="less" scoped>
.did-content {
  margin-top: 10%;
  h1 {
    color: #666666;
    width: 320px;
    margin: 0 auto;
  }
}
.did-button {
  width: 100px;
  margin: 0 auto;
  margin-top: 20px;
}
.m-a0 {
  margin: 0 auto;
}
.black-h {
  height: 50%;
}
.black-height {
  height: calc(50% - 90px);
  text-align: center;
  font-size: 30px;
  line-height: 200px;
}
.nodata {
  margin-top: 10%;
}
.did-width {
  width: 500px;
  margin: 0 auto;
}
.publicKey {
  display: flex;
  line-height: 30px;
  .span {
    width: 180px;
    text-align: right;
  }
  .span-key {
    width: calc(100% - 50px);
    word-break: break-word;
    white-space: pre-line;
  }
}
</style>
