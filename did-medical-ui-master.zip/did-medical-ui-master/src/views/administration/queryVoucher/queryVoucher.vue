<template>
  <div class="did-h">
    <div class="black black-h">
      <div>验证电子凭证</div>
      <el-row :gutter="20" class="mt3">
        <el-col :span="10" :offset="6">
          <el-form label-position="right" :rules="rules" ref="ruleForm" label-width="140px" :model="form">
            <el-form-item label="凭证号" prop="evidenceHash">
              <el-input v-model="form.evidenceHash" placeholder="请输入凭证号"></el-input>
            </el-form-item>
            <el-form-item label="公钥" >
              <el-input v-model="form.publicKey" placeholder="请输入公钥（可选）"></el-input>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
      <div class="did-button">
        <el-button size="medium" type="primary" @click="queryDoc">验证凭证</el-button>
      </div>
    </div>
    <div class="black mt1 black-height" >
        <div v-if="isShow" class="text-center">{{data?'验证成功':'验证失败'}}</div>
    </div>
  </div>
</template>
<script>
import NoData from '../../../components/noData.vue';
export default {
  components: {
    NoData,
  },
  data() {
    return {
      activeName: 'first',
      form: {
        evidenceHash:'',
        publicKey:''
      },
      rules:{
        evidenceHash: [{ required: true, message: '请输入', trigger: 'blur' }],
      },
      data:'',
      isShow:false
    };
  },
  
  mounted() {},
  methods: {
    async queryDoc(){
       this.isShow = false;
      let res = await this.$http.post(this.$api.administration.verifyEvidence,this.form);
      if (res.code == 200) {
        this.data = res.data;
        this.isShow = true;
      }
    }
  },
};
</script>
<style lang="less" scoped>
.did-content {
  margin-top: 10%;
  h1 {
    color: #666666;
    width: 320px;
    margin: 0 auto;
  }
}
.did-button {
  width: 100px;
  margin: 0 auto;
  margin-top: 20px;
}
.m-a0 {
  margin: 0 auto;
}
.black-h {
  height: 50%;
}
.black-height {
  height: calc(50% - 90px);
}
.nodata {
  margin-top: 10%;
}
.did-width {
  width: 500px;
  margin: 0 auto;
}
.publicKey {
  display: flex;
  line-height: 30px;
  .span {
    width: 180px;
    text-align: right;
  }
  .span-key {
    width: calc(100% - 50px);
    word-break: break-word;
    white-space: pre-line;
  }
}
.text-center{
  text-align: center;
  font-size: 20px;
  line-height: 200px;
}
</style>
