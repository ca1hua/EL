<template>
  <div class="did-h">
    <div class="black black-h">
      <div>根据病历凭证模板创建病历凭证</div>
      <el-table class="mt2" :data="tableData" style="width: 100%">
        <el-table-column type="index" label="序号" width="100" align="center"> </el-table-column>
        <el-table-column label="字段名" align="center">
          <template slot-scope="scope">
            {{ scope.row.department }}
          </template>
        </el-table-column>
        <el-table-column label="内容" align="center">
          <template slot-scope="scope">
            <el-input v-model="scope.row.content" placeholder="请输入内容"></el-input>
          </template>
        </el-table-column>
      </el-table>
      <div class="did-button">
        <el-button size="medium" type="primary" @click="register">创建</el-button>
      </div>
    </div>
    <el-dialog title="成功" :visible.sync="dialogVisible" width="60vh" >
      <el-form ref="form" :model="form" label-width="120px">
        <el-form-item label="凭证号：">{{ data.hash }} </el-form-item>
        <el-form-item label="凭证模板ID：">{{ data.cptId }} </el-form-item>
        <el-form-item label="创建者DID：">{{ data.issuer }} </el-form-item>
        <!-- <el-form-item label="注册时间：" > {{ data.issuanceDate }} </el-form-item>
        <el-form-item label="过期时间：" > {{ data.expirationDate }} </el-form-item> -->
        <el-form-item label="患者DID：">{{ data.claim.did }} </el-form-item>
        <el-form-item label="科室："> {{ data.claim.department }} </el-form-item>
        <el-form-item label="病历信息：">{{ data.claim.content }} </el-form-item>
        <el-form-item label="区块高度："> {{ data.blockHeight }} </el-form-item>
        <el-form-item label="交易哈希："> {{ data.transactionHash }} </el-form-item>
      </el-form>
    </el-dialog>
  </div> 
</template>
<script>
import NoData from '../../../components/noData.vue';
export default {
  components: {
    NoData,
  },
  data() {
    return {
      activeName: 'first',
      tableData: [
        { department: '患者DID', content: '' },
        { department: '科室', content: '' },
        { department: '病历信息', content: '' },
      ],
      options: [
        {
          value: 'String',
          label: 'String',
        },
        {
          value: 'integer',
          label: 'integer',
        },
      ],
      data: {
        blockHeight: '',
        claim: { department: '', content: '', did: '' },
        context: '',
        hash: '',
        expirationDate:'',
        cptId:'',
        issuanceDate:'',
        transactionHash:''
      },
      form: {
        credentialType: 'CASE_HISTORY',
        claimData: {
          did: '',
          department: '',
          content: '',
        },
      },
      dialogVisible: false,
    };
  },
  mounted() {},
  methods: {
    register() {
      this.createCredentialPojo();
    },
    addClick() {
      let arr = { department: '', content: '' };
      this.tableData.push(arr);
    },
    delClick(index) {
      this.tableData.splice(index, 1);
    },
    async createCredentialPojo() {
      // this.tableData.forEach((item) => {
      //   this.form.claimData[item.department] = item.content;
      // });
      this.form.claimData.did = this.tableData[0].content;
      this.form.claimData.department = this.tableData[1].content;
      this.form.claimData.content = this.tableData[2].content;
      let res = await this.$http.post(this.$api.administration.createCredentialPojo, this.form);
      if (res.code == 200) {
        this.data = res.data;
        this.dialogVisible = true;
      }
    },
  },
};
</script>
<style lang="less" scoped>
.did-content {
  margin-top: 10%;
  h1 {
    color: #666666;
    width: 320px;
    margin: 0 auto;
  }
}
.did-button {
  width: 100px;
  margin: 0 auto;
  margin-top: 20px;
}
.m-a0 {
  margin: 0 auto;
}
.black-h {
  height: calc(100% - 40px);
  overflow-y: auto;
}
.black-height {
  height: calc(50% - 90px);
  overflow-y: auto;
}
.nodata {
  margin-top: 10%;
}
.did-width {
  width: 500px;
  margin: 0 auto;
}
.text-c {
  text-align: center;
}
.add-button {
  width: 100%;
  padding: 8px 0;
  background: #fca400;
  color: white;
  border: 1px dashed #ccc;
  text-align: center;
  border-radius: 3px;
  margin-top: 10px;
  cursor: pointer;
}
.cursor {
  cursor: pointer;
}
.publicKey {
  display: flex;
  line-height: 30px;
  .span {
    width: 120px;
    text-align: right;
  }
  .span-key {
    width: calc(100% - 50px);
    word-break: break-word;
    white-space: pre-line;
  }
}
</style>
