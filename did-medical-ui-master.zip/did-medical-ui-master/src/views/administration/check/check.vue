<template>
  <div class="did-h">
    <div class="black black-h">
      <div>根据病历凭证号查询病历凭证</div>
      <el-row :gutter="20" class="check">
        <el-col :span="10" :offset="6">
          <el-form label-position="right" :rules="rules" ref="ruleForm" label-width="140px" :model="form">
            <el-form-item label="凭证号" prop="evidenceHash">
              <el-input v-model="form.evidenceHash" placeholder="请输入凭证号"></el-input>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
      <div class="did-button">
        <el-button size="medium" type="primary" @click="register">查询</el-button>
      </div>
    </div>
    <el-dialog title="成功" :visible.sync="dialogVisible" width="70vh">
      <el-form ref="form" :model="form" label-width="150px">
        <el-form-item label="患者DID：">{{data.did}} </el-form-item>
        <el-form-item label="患者年龄：">{{data.age}}  </el-form-item>
        <el-form-item label="患者性别："> {{data.sex==null?"":(data.sex==1?'男':'女')}} </el-form-item>
        <el-form-item label="患者过敏史："> {{data.allergicHistory}} </el-form-item>
        <el-form-item label="科室："> {{data.department}} </el-form-item>
        <el-form-item label="病历信息："> {{data.content}} </el-form-item>
        <el-form-item label="区块高度：">{{data.blockHeight}}  </el-form-item>
        <el-form-item label="交易哈希：">{{data.txHash}}  </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import NoData from '../../../components/noData.vue';
export default {
  components: {
    NoData,
  },
  data() {
    return {
      form: {
        evidenceHash: '',
        credentialType:'CASE_HISTORY',
      },
      activeName: 'first',
      tableData: [{ name: '', age: '' }],
      rules: {
        evidenceHash: [{ required: true, message: '请输入凭证号', trigger: 'blur' }],
      },
      options: [
        {
          value: 'String',
          label: 'String',
        },
        {
          value: 'integer',
          label: 'integer',
        },
      ],
      data: {
        age: '',
        allergicHistory: '',
        birth: '',
        blockHeight: '',
        cellPhone: '',
        content: '',
        department: '',
        did: '',
        isAudit: '',
        realName: '',
        result: '',
        sex: '',
        txHash: '',
      },
      dialogVisible: false,
    };
  },
  mounted() {},
  methods: {
    register() {
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          this.registerCpt();
        } else {
          return false;
        }
      });
    },
    addClick() {
      let arr = { name: '', age: '' };
      this.tableData.push(arr);
    },
    delClick(index) {
      this.tableData.splice(index, 1);
    },
    async registerCpt() {
      let res = await this.$http.post(this.$api.administration.queryEvidence, this.form);
      if (res.code == 200) {
        this.data = res.data;
        this.dialogVisible = true;
      }
    },
  },
};
</script>
<style lang="less" scoped>
.check {
  margin-top: 300px;
}
.did-content {
  margin-top: 10%;
  h1 {
    color: #666666;
    width: 320px;
    margin: 0 auto;
  }
}
.did-button {
  width: 100px;
  margin: 0 auto;
  margin-top: 20px;
}
.m-a0 {
  margin: 0 auto;
}
.black-h {
  height: calc(100% - 40px);
  overflow-y: auto;
}
.black-height {
  height: calc(50% - 90px);
  overflow-y: auto;
}
.nodata {
  margin-top: 10%;
}
.did-width {
  width: 500px;
  margin: 0 auto;
}
.text-c {
  text-align: center;
}
.add-button {
  width: 100%;
  padding: 8px 0;
  background: #fca400;
  color: white;
  border: 1px dashed #ccc;
  text-align: center;
  border-radius: 3px;
  margin-top: 10px;
  cursor: pointer;
}
.cursor {
  cursor: pointer;
}
.publicKey {
  display: flex;
  line-height: 30px;
  .span {
    width: 120px;
    text-align: right;
  }
  .span-key {
    width: calc(100% - 50px);
    word-break: break-word;
    white-space: pre-line;
  }
}
</style>
