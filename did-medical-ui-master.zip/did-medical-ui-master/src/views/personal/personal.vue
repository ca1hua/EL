<template>
  <div class="black black-h">
    <div class="right">
      <div class="right-img">
        <img src="../../assets/img/personal.jpg" alt="" />
      </div>
    </div>
    <div class="left">
      <el-row :gutter="24">
        <el-col :span="12">
          <el-form ref="form" :model="form" label-width="100px">
            <el-form-item v-if="role !=='PHARMACY'" label="姓名:">
              <div class="font-color">{{ form.realName }}</div>
            </el-form-item>
            <el-form-item v-if="role == 'PHARMACY'" label="药店名:">
              <div class="font-color">{{ form.realName }}</div>
            </el-form-item>

            <el-form-item v-if="role!=='PHARMACY'" label="性别:">
              <div class="font-color">{{ form.sex==null?"":(form.sex==1?'男':'女') }}</div>
            </el-form-item>

            <el-form-item v-if="role == 'DOCTOR'" label="科室:">
              <div class="font-color">{{ form.department }}</div>
            </el-form-item>
  
            <el-form-item v-if="role == 'CHEMIST'" label="检查部门:">
              <div class="font-color">{{ form.department }}</div>
            </el-form-item>
  
            <el-form-item v-if="role == 'PHARMACY'" label="工商注册号:">
              <div class="font-color">{{ form.businessNumber }}</div>
            </el-form-item>
  
            <el-form-item v-if="role == 'PHARMACY'" label="地址:">
              <div class="font-color">{{ form.address }}</div>
            </el-form-item>
            <el-form-item label="角色:">
              <div class="font-color">{{getValue(form.role)}}</div>
            </el-form-item>  
          </el-form>
        </el-col>
        <el-col :span="12" >
          <el-form ref="form" :model="form" label-width="100px">
            <el-form-item v-if="role!=='PHARMACY'" label="年龄:">
              <div class="font-color">{{ form.age }}</div>
            </el-form-item>
            <el-form-item v-if="role!=='PHARMACY'" label="身份证号:">
              <div class="font-color">{{ form.idNumber }}</div>
            </el-form-item>
            <el-form-item v-if="role=='PATIENT'" label="过敏史:">
              <div class="font-color">{{ form.allergicHistory }}</div>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>


      <el-divider></el-divider>
      <el-form ref="form" :model="form" label-width="80px">
        <el-form-item label="DID:">
          <div class="font-color">{{ form.did }}</div>
        </el-form-item>
        <el-form-item label="公钥:">
          <div class="font-color">{{ form.publicKey }}</div>
        </el-form-item>
        <el-form-item label="私钥:">
          <div class="font-color">{{ form.privateKey }}</div>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
export default {
  components: {},
  data() {
    return {
      form: {
        address: '',
        age: '',
        allergicHistory: '',
        birth: '',
        blockHeight: '',
        businessNumber: '',
        cellPhone: '',
        createTime: '',
        department: '',
        did: '',
        idNumber: ' ',
        privateKey: '',
        publicKey: '',
        realName: '',
        role: '',
        sex: '',
        txHash: '',
        username: '',
      },
      roleOption:[
        { label: '患者', value: 'PATIENT' },
        { label: '医生', value: 'DOCTOR' },
        { label: '化验师', value: 'CHEMIST' },
        { label: '药师', value: 'PHARMACIST' },
        { label: '行政医生', value: 'EXECUTOR' },
        { label: '药店', value: 'PHARMACY' },
      ],
      isShow:false,
      role:''
    };
  },
  mounted() {
    this.role = localStorage.getItem('role');
    this.query();
  },
  methods: {
    async query() {
      let res = await this.$http.post(this.$api.login.query);
      if (res.code == 200) {
        this.form = res.data;
      }
    },
    getValue(name){
      let arr = ''
      this.roleOption.forEach(item =>{
        if(name == item.value){
          arr = item.label
        }
      })
      return arr
    },
  },
};
</script>
<style lang="less" scoped>
.did-content {
  margin-top: 10%;
  h1 {
    color: #666666;
    width: 320px;
    margin: 0 auto;
  }
}
.did-button {
  width: 100px;
  margin: 0 auto;
  margin-top: 20px;
}
.m-a0 {
  margin: 0 auto;
}
.black-h {
  height: calc(100% - 40px);
  overflow: auto;
}
.black {
  display: flex;
}
.right {
  width: 300px;
  border-right: 1px solid #f2f2f2;
}
.left {
  width: calc(100% - 300px);
  padding: 30px;
}
.right-img {
  padding: 30px;
  img {
    width: 100%;
    height: 100%;
    border-radius: 10px;
  }
}
.font-color {
  color: #474e66;
  word-wrap:break-word;
  width: 80%;
}
</style>
