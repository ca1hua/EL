export default {
  login:{
    create: '/user/register', //注册
    login: '/user/login', //登录
    query: '/user/query', //个人信息
  },
  voucher:{
    register: '/cpt/register', //注册凭证模板
    query: '/cpt/query', //查询
  },
  did:{
    isExist: '/did/isExist', //验证did
    query: '/did/query', //  查询did
  },
  administration:{
    createCredentialPojo: '/credential/createCredentialPojo', //创建病历凭证
    queryEvidence: '/credential/queryEvidence', //查询病历
    review: '/credential/review', //审核检查单
    verifyEvidence: '/credential/verifyEvidence', //验证
  }
  
};
