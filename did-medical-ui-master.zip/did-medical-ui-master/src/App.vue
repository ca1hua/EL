<template>
  <router-view />
</template>

<script>
export default {
  data() {
    return {};
  },
  watch: {
   
  },
  computed: {
  },
  mounted() {},
  methods: {
  },
};
</script>

<style lang="less">
@import url('./style/default.less');
</style>
