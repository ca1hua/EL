<template>
  <el-aside width="216px" class="app-aside">
    <el-scrollbar class="aside-scrollbar">
      <div class="bcim-img">
        <img src="../../assets/img/logo.png" alt="" />
      </div>
      <el-menu :collapse="collapsed" :default-active="activeMenu" router :unique-opened="false" :collapse-transition="false" active-text-color="#EFC377" text-color="#fff" background-color="#213166">
        <el-submenu :index="index + ''" v-for="(item, index) in menus" :key="index">
          <template #title>
            <div class="menu-img">
              <img :src="item.icon" alt="" />
              <span class="ml1">{{ item.name }}</span>
            </div>
          </template>
          <el-menu-item v-for="(node, key) in item.children" :index="node.to" :key="index + '-' + key">{{ node.name }}</el-menu-item>
        </el-submenu>
      </el-menu>
    </el-scrollbar>
  </el-aside>
</template>

<script>
import { mapState } from 'vuex';
export default {
  data() {
    return {
      activeMenu: '0',
      menus: [
        {
          icon: require('../../assets/img/DID.svg'),
          name: '患者DID管理',
          children: [
            { name: '查询患者DID', to: 'did' },
            { name: '验证患者DID', to: 'queryDID' },
          ],
        },
        {
          icon: require('../../assets/img/voucher.svg'),
          name: '医疗凭证模板管理',
          children: [
            { name: '发布医疗凭证模板', to: 'voucher' },
            { name: '查询医疗凭证模板', to: 'queryTemplate' },
          ],
        },
        {
          icon: require('../../assets/img/card.svg'),
          name: '医疗凭证管理',
          children: [
            { name: '创建病历凭证', to: 'administration' },
            { name: '创建检查单凭证', to: 'inspect' },
            { name: '创建化验单凭证', to: 'test' },
            { name: '创建药单凭证', to: 'prescription' },
            { name: '查询病历凭证', to: 'check' },
            { name: '查询检查单凭证', to: 'checkInspect' },
            { name: '查询化验单凭证', to: 'laboratory' },
            { name: '查询药单凭证', to: 'checkPrescription' },
            { name: '审核检查单凭证', to: 'examine' },
            { name: '审核药单凭证', to: 'review' },
            { name: '验证凭证', to: 'queryVoucher' },
          ],
        },
        {
          icon: require('../../assets/img/mechanism.svg'),
          name: '个人信息管理',
          children: [{ name: '个人信息', to: 'personal' }],
        },
      ],
    };
  },
  computed: {
    ...mapState(['collapsed']),
  },
  watch: {
    $route() {
      this.setCurrentRoute();
    },
  },
  mounted() {
    this.setCurrentRoute();
    this.init();
  },
  methods: {
    setCurrentRoute() {
      this.activeMenu = this.$route.name;
    },
    init() {
      let role = localStorage.getItem('role');
      if (role == 'PATIENT') {
        this.menus = [
          {
            icon: require('../../assets/img/card.svg'),
            name: '医疗凭证管理',
            children: [
              { name: '查询病历凭证', to: 'check' },
              { name: '查询检查单凭证', to: 'checkInspect' },
              { name: '查询化验单凭证', to: 'laboratory' },
              { name: '查询药单凭证', to: 'checkPrescription' },
              { name: '验证凭证', to: 'queryVoucher' },
            ],
          },
        ];
      }
      if (role == 'DOCTOR') {
        this.menus = [
          {
            icon: require('../../assets/img/DID.svg'),
            name: '患者DID管理',
            children: [
              { name: '查询患者DID', to: 'did' },
              { name: '验证患者DID', to: 'queryDID' },
            ],
          },
          {
            icon: require('../../assets/img/card.svg'),
            name: '医疗凭证管理',
            children: [
              { name: '创建病历凭证', to: 'administration' },
              { name: '创建检查单凭证', to: 'inspect' },
              { name: '创建药单凭证', to: 'prescription' },
              { name: '查询病历凭证', to: 'check' },
              { name: '查询检查单凭证', to: 'checkInspect' },
              { name: '查询化验单凭证', to: 'laboratory' },
              { name: '查询药单凭证', to: 'checkPrescription' },
              { name: '验证凭证', to: 'queryVoucher' },
            ],
          },
        ];
      }
      if (role == 'CHEMIST') {
        this.menus = [
          {
            icon: require('../../assets/img/DID.svg'),
            name: '患者DID管理',
            children: [
              { name: '查询患者DID', to: 'did' },
              { name: '验证患者DID', to: 'queryDID' },
            ],
          },
          {
            icon: require('../../assets/img/card.svg'),
            name: '医疗凭证管理',
            children: [
               { name: '创建化验单凭证', to: 'test' },
              { name: '查询病历凭证', to: 'check' },
              { name: '查询检查单凭证', to: 'checkInspect' },
              { name: '查询化验单凭证', to: 'laboratory' },
              { name: '审核检查单凭证', to: 'examine' },
              { name: '验证凭证', to: 'queryVoucher' },
            ],
          },
        ];
      }
       if (role == 'PHARMACIST') {
        this.menus = [
          {
            icon: require('../../assets/img/DID.svg'),
            name: '患者DID管理',
            children: [
              { name: '查询患者DID', to: 'did' },
              { name: '验证患者DID', to: 'queryDID' },
            ],
          },
          {
            icon: require('../../assets/img/card.svg'),
            name: '医疗凭证管理',
            children: [
              { name: '查询病历凭证', to: 'check' },
              { name: '查询化验单凭证', to: 'laboratory' },
              { name: '查询药单凭证', to: 'checkPrescription' },
              { name: '审核药单凭证', to: 'review' },
              { name: '验证凭证', to: 'queryVoucher' },
            ],
          },
        ];
      }
      if (role == 'EXECUTOR') {
        this.menus = [
          {
            icon: require('../../assets/img/DID.svg'),
            name: '患者DID管理',
            children: [
              { name: '查询患者DID', to: 'did' },
              { name: '验证患者DID', to: 'queryDID' },
            ],
          },
          {
            icon: require('../../assets/img/voucher.svg'),
            name: '医疗凭证模板管理',
            children: [
              { name: '发布医疗凭证模板', to: 'voucher' },
              { name: '查询医疗凭证模板', to: 'queryTemplate' },
            ],
          },
          {
            icon: require('../../assets/img/card.svg'),
            name: '医疗凭证管理',
            children: [
              { name: '创建病历凭证', to: 'administration' },
              { name: '创建检查单凭证', to: 'inspect' },
              { name: '创建化验单凭证', to: 'test' },
              { name: '创建药单凭证', to: 'prescription' },
              { name: '查询病历凭证', to: 'check' },
              { name: '查询检查单凭证', to: 'checkInspect' },
              { name: '查询化验单凭证', to: 'laboratory' },
              { name: '查询药单凭证', to: 'checkPrescription' },
              { name: '审核检查单凭证', to: 'examine' },
              { name: '审核药单凭证', to: 'review' },
              { name: '验证凭证', to: 'queryVoucher' },
            ],
          },
        ];
      }
       if (role == 'PHARMACY') {
        this.menus = [
          {
            icon: require('../../assets/img/DID.svg'),
            name: '患者DID管理',
            children: [
              { name: '验证患者DID', to: 'queryDID' },
            ],
          },
          {
            icon: require('../../assets/img/card.svg'),
            name: '医疗凭证管理',
            children: [
              { name: '查询药单凭证', to: 'checkPrescription' },
              { name: '验证凭证', to: 'queryVoucher' },
            ],
          },
        ];
      }
      
    },
  },
};
</script>

<style lang="less" scoped>
.bcim-img {
  padding: 10px;
  img {
    width: 190px;
  }
}
.menu-img {
  display: flex;
}
</style>
