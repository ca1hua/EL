<template>
  <div class="header-menu">
    <div class="menu-left">
      <!-- <el-button type="text" @click="collapseHandler">
        <i :class="['collapse', collapsed ? 'el-icon-s-fold' : 'el-icon-s-unfold']"></i>
      </el-button> -->
      <!-- {{currentRoute}} -->
      <el-breadcrumb class="breadcrumb" separator="/">
        <!-- <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item> -->
        <el-breadcrumb-item>{{  role=='PHARMACY'?'药店信息管理': currentRoute.meta.title}}</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
  
    <div class="menu-right">
      <!-- <el-button type="text" @click="$router.push({ name: 'home' })" icon="el-icon-menu">首页</el-button> -->
      <div class="fdiv">
           <div class="fdiv">
              <img src="../../assets/img/news.svg" alt="">
              <span class="menu-span">您好，欢迎使用医链—医疗信息管理系统</span>
           </div>
           <el-button type="text" @click="getFullCreeen" icon="el-icon-rank">全屏</el-button>
           <el-button type="text" @click="$router.push({ name: 'personal' })">{{ realName }}({{ getValue(role)}})</el-button>

            <el-button type="text" @click="signout" icon="el-icon-switch-button">退出</el-button>
      </div>
      <!-- <el-button type="text" @click="getFullCreeen" icon="el-icon-rank">全屏</el-button> -->
       
      <!-- <el-button type="text" icon="el-icon-user-solid" @click="$router.push({ name: 'personal' })">{{ username }}</el-button> -->
     
    </div>
   
  </div>
</template>

<script>
import screenfull from 'screenfull';
// import { mapMutations, mapState } from 'vuex';
export default {
  data() {
    return {
      currentRoute: {
      },
      userName:'',
      role:'',
      roleOption:[
        { label: '患者', value: 'PATIENT' },
        { label: '医生', value: 'DOCTOR' },
        { label: '化验师', value: 'CHEMIST' },
        { label: '药师', value: 'PHARMACIST' },
        { label: '行政医生', value: 'EXECUTOR' },
        { label: '药店', value: 'PHARMACY' },
      ]
    };
  },
  watch: {
    $route(to) {
      this.currentRoute = to;
    },
  },
  computed: {
    // ...mapState(['collapsed', 'username']),
  },
  created() {
    this.userName = localStorage.getItem('user');
    // this.signout();
    this.currentRoute = this.$route;
    this.role = localStorage.getItem('role');
    this.realName = localStorage.getItem('realName');

  },
  methods: {
    getValue(name){
      let arr = ''
      this.roleOption.forEach(item =>{
        if(name == item.value){
          arr = item.label
        }
      })
      return arr
    },
    // ...mapMutations(['mttSide', 'mttSignout']),
    // collapseHandler() {
    //   this.mttSide(!this.collapsed);
    // },
    getFullCreeen() {
      if (screenfull.isEnabled) {
        screenfull.toggle();
      }
    },
    signout() {
      // this.mttSignout();
      this.$router.push({ name: 'login' });
    },
  },
};
</script>
