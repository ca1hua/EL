<template>
  <el-container class="app-container">
    <Sidebar></Sidebar>
    <el-container>
      <el-header class="app-header">
        <Navbar></Navbar>
      </el-header>
      <el-main>
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import Sidebar from './components/sidebar.vue';
import Navbar from './components/navbar.vue';
import { mapState } from 'vuex';
export default {
  components: { Sidebar, Navbar },
  data() {
    return {};
  },
  computed: {
    ...mapState(['token', 'username']),
  },
  watch: {
    $route() {
      this.checkSign();
    },
  },
  mounted() {
    this.checkSign();
  },
  methods: {
    checkSign() {
    },
    async initAdmin() {
      var resp = await this.$http.get(this.$api.auth.getUserFullInfo);
      // var resp = await this.$http.get(this.$api.auth.getUserInfo);
      console.log('current', resp);
    },
  },
};
</script>

<style lang="less"></style>
