import IconButton from './iconButton/iconButton.vue';

export default { IconButton };
