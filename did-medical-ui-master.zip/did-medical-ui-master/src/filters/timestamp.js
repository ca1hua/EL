import dayjs from 'dayjs';

const timestampFilter = (value, format) => {
  if (!value) return '';
  return dayjs(value * 1000).format(format);
};

export default timestampFilter;
