import dayjs from 'dayjs';

const datetimeFilter = (value, format) => {
  if (!value) return '';
  return dayjs(value).format(format);
};

export default datetimeFilter;
/// {{ '' | datetimeFilter('YYYY-MM-DD HH:mm:ss') }}
