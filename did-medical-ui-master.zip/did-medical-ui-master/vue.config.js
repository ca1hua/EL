const path = require('path');
function resolve(dir) {
  return path.join(__dirname, dir);
}

module.exports = {
  publicPath: './',
  chainWebpack: (config) => {
    //CDN引入
    // config.externals = {
    //     vue: 'Vue',
    //     'vue-router': 'VueRouter',
    //     vuex: 'Vuex',
    //     axios: 'axios',
    //     moment: 'moment',
    //     'element-ui': 'ELEMENT',
    //   };
    //添加别名
    config.resolve.alias.set('@', resolve('src')).set('assets', resolve('src/assets')).set('components', resolve('src/components'));
  },
  productionSourceMap: false, // 生产环境是否生成 sourceMap 文件
  lintOnSave: false,
  devServer: {
    open: true, //自动打开浏览器
    overlay: {
      warning: false,
      errors: false,
    },
    proxy: {
      '': {
        target: 'http://10.0.11.44:8081/', //阿里云环境外网
        ws: true, //如果要代理 websockets，配置这个参数
        secure: false, // 如果是https接口，需要配置这个参数
        changeOrigin: true, //是否跨域`
        pathRewrite: {
          '^/api': 'api',
        },
      },
    },
  },
};
