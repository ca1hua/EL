###
更新时间 2021年11月9日17时08分

# tc-did-base

#### 介绍
BCIM区块链身份管理系统-后端代码。

#### 先决条件
1. 部署FISCO BCOS国密版本(https://fisco-bcos-documentation.readthedocs.io/zh_CN/latest/docs/manual/guomi_crypto.html)
2. 部署WeIdentity(https://weidentity.readthedocs.io/zh_CN/latest/docs/one-stop-experience.html#)

#### 安装教程
1. 仓库拉取代码
2. 将WeIdentity的[weid-build-tools/resources](weid-build-tools/resources)文件夹下的文件拷贝到[/src/main/resources](/src/main/resources)文件夹

（文件包括fisco.properties、gmensdk.crt、gmsdk.crt、gmca.crt、gmensdk.key、gmsdk.key、weidentity.properties，不包括log4j2.xml）

（weidentity.properties的nodes需更新为自己FISCO BCOS的IP地址和端口号）

3. 将WeIdentity的[weid-build-tools/output/admin/](weid-build-tools/output/admin/)文件夹下的ecdsa_key文件拷贝到[/src/main/resources/keys/priv](/src/main/resources/keys/priv)文件夹
4. 运行[src/main/java/com/timechainer/weid/WebApplication.java](src/main/java/com/timechainer/weid/WebApplication.java)文件启动系统

#### 使用说明
1. 运行[src/main/java/com/timechainer/weid/WebApplication.java](src/main/java/com/timechainer/weid/WebApplication.java)文件启动系统

#### 参与贡献
1. fork原仓库；
2. 克隆原仓库（git clone 仓库地址）；
3. 拉取fork仓库代码（进入项目文件夹，git remote add 别名 fork仓库）；
4. 新建分支（git branch 分支名）；
5. 开发代码；
6. 提交到fork仓库（git push fork仓库别名 分支名）；
7. 新建Pull Request。
8. 通知管理员merge新代码。