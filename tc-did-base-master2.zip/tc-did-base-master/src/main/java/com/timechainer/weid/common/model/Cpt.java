package com.timechainer.weid.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date  2021/9/24 3:55 PM
 * @Description //TODO $end$
 **/
@ApiModel(value="cpt")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "cpt")
public class Cpt {
    @TableId(value = "cpt_id", type = IdType.INPUT)
    @ApiModelProperty(value="")
    private Integer cptId;

    @TableField(value = "cpt_version")
    @ApiModelProperty(value="")
    private Integer cptVersion;

    @TableField(value = "publisher")
    @ApiModelProperty(value="")
    private String publisher;

    @TableField(value = "created_at")
    @ApiModelProperty(value="")
    private Date createdAt;

    @TableField(value = "claim")
    @ApiModelProperty(value="")
    private String claim;

    /**
     * 该CPT标题
     */
    @TableField(value = "title")
    @ApiModelProperty(value="该CPT标题")
    private String title;

    /**
     * 该CPT描述
     */
    @TableField(value = "des")
    @ApiModelProperty(value="该CPT描述")
    private String des;

    @TableField(value = "tx_hash")
    @ApiModelProperty(value="")
    private String txHash;

    @TableField(value = "block_height")
    @ApiModelProperty(value="")
    private Long blockHeight;

    public static final String COL_CPT_ID = "cpt_id";

    public static final String COL_CPT_VERSION = "cpt_version";

    public static final String COL_PUBLISHER = "publisher";

    public static final String COL_CREATED_AT = "created_at";

    public static final String COL_CLAIM = "claim";

    public static final String COL_TITLE = "title";

    public static final String COL_DES = "des";

    public static final String COL_TX_HASH = "tx_hash";

    public static final String COL_BLOCK_HEIGHT = "block_height";
}