package com.timechainer.weid.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.timechainer.weid.entity.Cpt;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/24 4:03 PM
 * @Description //TODO $end$
 **/
@Mapper
@Repository
public interface CptMapper extends BaseMapper<Cpt> {
}