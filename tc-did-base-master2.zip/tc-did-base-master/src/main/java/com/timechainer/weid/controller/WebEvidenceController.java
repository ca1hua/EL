package com.timechainer.weid.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.timechainer.weid.common.model.*;
import com.timechainer.weid.constant.ApiResult;
import com.timechainer.weid.service.WebEvidenceService;
import com.webank.weid.protocol.base.EvidenceInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.IOException;

/**
 * 创建凭证存证接口Controller.
 * @author VictorLyl
 * @date 2021/9/3
 **/
@Slf4j
@RestController
@RequestMapping("/evidence")
@Api(description = "evidence",
        tags = {"evidence"}, position = 0, hidden = false)
public class WebEvidenceController {
    @Autowired
    private WebEvidenceService webEvidenceService;

    /**
     * 注册Evidence的时候，是针对一个已经注册是credential，使用的是他的id和私钥，不然验证的时候会报错
     * @param createEvidenceModel
     * @return
     * @throws IOException
     */
    @ApiOperation(value ="签发凭证存证")
    @PostMapping("/createEvidence")
    @ResponseBody
    public ApiResult<String> createEvidence(
            @ApiParam(name="createEvidenceModel", value = "签发凭证存证接口模板")
            @Valid @RequestBody CreateEvidenceModel createEvidenceModel) throws IOException {
        return webEvidenceService.createEvidence(createEvidenceModel);
    }

    @ApiOperation(value ="查询凭证存证（凭证哈希或关键字）")
    @PostMapping("/queryEvidence")
    @ResponseBody
    public ApiResult<EvidenceInfo> queryEvidence(
            @ApiParam(name="queryEvidenceModel", value = "查询凭证存证（凭证哈希或关键字）模板")
            @Valid @RequestBody QueryEvidenceModel queryEvidenceModel) throws JsonProcessingException {
        return webEvidenceService.queryEvidence(queryEvidenceModel);
    }

    /**
     * 验证凭证的时候使用的是创建Credential的weid和公钥
     * @param verifyEvidenceModel
     * @return
     * @throws JsonProcessingException
     */
    @ApiOperation(value ="验证凭证存证")
    @PostMapping("/verifyEvidence")
    @ResponseBody
    public ApiResult<Boolean> verifyEvidence(
            @ApiParam(name="VerifyEvidenceModel", value = "验证凭证存证模板")
            @Valid @RequestBody VerifyEvidenceModel verifyEvidenceModel) throws JsonProcessingException {
        return webEvidenceService.verifyEvidence(verifyEvidenceModel);
    }

    @ApiOperation(value ="添加凭证存证日志")
    @PostMapping("/addLog")
    @ResponseBody
    public ApiResult<Boolean> addLog(
            @ApiParam(name="addLog", value = "添加凭证存证日志模板")
            @Valid @RequestBody AddLogModel addLogModel){
        return webEvidenceService.addLog(addLogModel);
    }
}
