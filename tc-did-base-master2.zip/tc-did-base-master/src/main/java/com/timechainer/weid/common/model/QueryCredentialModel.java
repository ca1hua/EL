package com.timechainer.weid.common.model;

import lombok.Data;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/25 6:00 PM
 * @Description //TODO $
 **/
@Data
public class QueryCredentialModel {
    String credentialId;
}
