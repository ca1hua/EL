package com.timechainer.weid.service.impl;

import com.timechainer.weid.common.model.AuthorityIssuerModel;
import com.timechainer.weid.common.util.FileUtil;
import com.timechainer.weid.common.util.PrivateKeyUtil;
import com.timechainer.weid.constant.ApiResult;
import com.timechainer.weid.service.AuthorityAgentService;
import com.webank.weid.constant.ErrorCode;
import com.webank.weid.protocol.base.AuthorityIssuer;
import com.webank.weid.protocol.base.WeIdPrivateKey;
import com.webank.weid.protocol.request.RegisterAuthorityIssuerArgs;
import com.webank.weid.protocol.response.ResponseData;
import com.webank.weid.rpc.AuthorityIssuerService;
import com.webank.weid.service.impl.AuthorityIssuerServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/2 11:08 AM
 * @Description //TODO $
 **/
@Slf4j
@Service
public class AuthorityAgentServiceImpl implements AuthorityAgentService {

    AuthorityIssuerService authorityIssuerService = new AuthorityIssuerServiceImpl();

//    private AuthorityAgentMapper authorityIssuerMapper;
//
//    @Autowired
//    public void setInjectedBean(AuthorityAgentMapper authorityIssuerMapper) {
//        this.authorityIssuerMapper = authorityIssuerMapper;
//    }

    /**
     * register on the chain as an authoritative body.
     *
     * @param authorityIssuerModel the name of the issue
     * @return true is success, false is failure
     */
    @Override
    public ResponseData<Boolean> registerAuthorityIssuer(AuthorityIssuerModel authorityIssuerModel) {
        AuthorityIssuer authorityIssuer = new AuthorityIssuer();
        authorityIssuer.setWeId(authorityIssuerModel.getDid());
        authorityIssuer.setName(authorityIssuerModel.getAuthorityName());

        // 设置默认信用值为0
        authorityIssuer.setAccValue("0");

        WeIdPrivateKey weIdPrivateKey = new WeIdPrivateKey();
        weIdPrivateKey.setPrivateKey(FileUtil.getDataByPath(PrivateKeyUtil.SDK_PRIVKEY_PATH));

        RegisterAuthorityIssuerArgs registerAuthorityIssuerArgs = new RegisterAuthorityIssuerArgs();
        registerAuthorityIssuerArgs.setAuthorityIssuer(authorityIssuer);
        registerAuthorityIssuerArgs.setWeIdPrivateKey(weIdPrivateKey);

        ResponseData<Boolean> registResponse =
                authorityIssuerService.registerAuthorityIssuer(registerAuthorityIssuerArgs);
        log.info(
                "registerAuthorityIssuer is result,errorCode:{},errorMessage:{}",
                registResponse.getErrorCode(),
                registResponse.getErrorMessage()
        );
        return registResponse;
    }

    /**
     * Recognize this WeID to be an authority issuer.
     * Params:
     * true if succeeds, false otherwise
     * @param issuer the issue
     * @return
     */
    @Override
    public ResponseData<Boolean> recognizeAuthorityIssuer(String issuer) {
        WeIdPrivateKey weIdPrivateKey = new WeIdPrivateKey();
        weIdPrivateKey.setPrivateKey(FileUtil.getDataByPath(PrivateKeyUtil.SDK_PRIVKEY_PATH));

//        直接从数据库查询
//        AuthorityAgent authorityAgent = authorityIssuerMapper.selectByPrimaryKey(issuer);
        ResponseData<Boolean> booleanResponseData = authorityIssuerService.recognizeAuthorityIssuer(issuer, weIdPrivateKey);
        log.info(
                "recognize issuer end,errorCode:{},errorMessage:{}",
                booleanResponseData.getErrorCode(),
                booleanResponseData.getErrorMessage()
        );
        return booleanResponseData;
    }

    /**
     * de recognize the issuer on chain.
     *
     * @param issuer the issue
     * @return true is success, false is failure
     */
    @Override
    public ResponseData<Boolean> deRecognizeAuthorityIssuer(String issuer) {

//        AuthorityAgent authorityAgent = authorityIssuerMapper.selectByPrimaryKey(issuer);
        String privKey = FileUtil.getDataByPath(PrivateKeyUtil.SDK_PRIVKEY_PATH);
        ResponseData<Boolean> booleanResponseData = authorityIssuerService.deRecognizeAuthorityIssuer(issuer, new WeIdPrivateKey(privKey));
        // de recognize
        log.info(
                "recognizeAuthorityIssuer is result,errorCode:{},errorMessage:{}",
                booleanResponseData.getErrorCode(),
                booleanResponseData.getErrorMessage()
        );
        return booleanResponseData;
    }

    /**
     * derecognize the issuer on chain.
     *
     * @param issuer the issue
     * @return true is success, false is failure
     */
    @Override
    public ApiResult<AuthorityIssuer> queryAuthorityIssuer(String issuer) {
        ResponseData<AuthorityIssuer> authorityAgent = authorityIssuerService.queryAuthorityIssuerInfo(issuer);
        if (authorityAgent.getErrorCode() !=ErrorCode.SUCCESS.getCode()) {
            return ApiResult.failed(authorityAgent.getErrorCode(), authorityAgent.getErrorMessage());
        }
        return ApiResult.success(authorityAgent.getResult());
    }

    public ApiResult<Boolean> isAuthorityIssuer(String issuer){
        AuthorityIssuerService authorityIssuerService=new AuthorityIssuerServiceImpl();

        ResponseData<Boolean> responseData=authorityIssuerService.isAuthorityIssuer(issuer);
        return ApiResult.success(responseData.getResult());
    }
}
