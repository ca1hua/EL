package com.timechainer.weid.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.Date;
import lombok.Data;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/13 5:25 PM
 * @Description //TODO $end$
 **/
@ApiModel(value = "com-timechainer-weid-entity-AuthorityAgentLog")
@Data
@TableName(value = "BCIM.authority_agent_log")
public class AuthorityAgentLog {
    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private Integer id;

    @TableField(value = "did")
    @ApiModelProperty(value = "")
    private String did;

    @TableField(value = "`name`")
    @ApiModelProperty(value = "")
    private String name;

    @TableField(value = "acc_value")
    @ApiModelProperty(value = "")
    private String accValue;

    @TableField(value = "update_type")
    @ApiModelProperty(value = "")
    private Object updateType;

    @TableField(value = "updated_at")
    @ApiModelProperty(value = "")
    private Date updatedAt;

    @TableField(value = "tx_hash")
    @ApiModelProperty(value = "")
    private String txHash;

    @TableField(value = "block_height")
    @ApiModelProperty(value = "")
    private Long blockHeight;

    @TableField(value = "succeed")
    @ApiModelProperty(value = "")
    private Boolean succeed;

    @TableField(value = "info")
    @ApiModelProperty(value = "")
    private String info;

    public static final String COL_ID = "id";

    public static final String COL_DID = "did";

    public static final String COL_NAME = "name";

    public static final String COL_ACC_VALUE = "acc_value";

    public static final String COL_UPDATE_TYPE = "update_type";

    public static final String COL_UPDATED_AT = "updated_at";

    public static final String COL_TX_HASH = "tx_hash";

    public static final String COL_BLOCK_HEIGHT = "block_height";

    public static final String COL_SUCCEED = "succeed";

    public static final String COL_INFO = "info";
}