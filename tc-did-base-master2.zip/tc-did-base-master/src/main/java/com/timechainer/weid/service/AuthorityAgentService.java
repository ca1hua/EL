package com.timechainer.weid.service;

import com.timechainer.weid.common.model.AuthorityIssuerModel;
import com.timechainer.weid.constant.ApiResult;
import com.webank.weid.protocol.base.AuthorityIssuer;
import com.webank.weid.protocol.response.ResponseData;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/2 10:58 AM
 * @Description //TODO $
 **/
public interface AuthorityAgentService {

    /**
     * register on the chain as an authoritative body.
     *
     * @param authorityIssuerModel the name of the issue
     * @return true is success, false is failure
     */
    ResponseData<Boolean> registerAuthorityIssuer(AuthorityIssuerModel authorityIssuerModel);

    /**
     * recognize the issuer on chain.
     *
     * @param issuer the issue
     * @return true is success, false is failure
     */
    ResponseData<Boolean> recognizeAuthorityIssuer(String issuer);

    /**
     * de recognize the issuer on chain.
     *
     * @param issuer the issuer
     * @return true is success, false is failure
     */
    ResponseData<Boolean> deRecognizeAuthorityIssuer(String issuer);

    /**
     * derecognize the issuer on chain.
     *
     * @param issuer the issue
     * @return true is success, false is failure
     */
    ApiResult<AuthorityIssuer> queryAuthorityIssuer(String issuer);

    ApiResult<Boolean> isAuthorityIssuer(String issuer);
}
