package com.timechainer.weid.controller;

import com.timechainer.weid.common.model.*;
import com.timechainer.weid.constant.ApiResult;
import com.timechainer.weid.service.WebWeidService;
import com.webank.weid.protocol.base.*;
import com.webank.weid.protocol.response.CreateWeIdDataResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author: renhuikang
 * @date: 2021/8/27 5:13 PM
 * @description:
 * Weid controller
 * @return
 **/
@Slf4j
@RestController
@RequestMapping("/did")
@Api(description = "did",
        tags = {"did"}, position = 0, hidden = false)
public class WeidController {

    @Autowired
    private WebWeidService weidService;

    @ApiOperation(value = "自动注册DID")
    @GetMapping("/create")
    public ApiResult<CreateWeIdDataResult> createWeid() {
        return weidService.createWeId();
    }

    @ApiOperation(value = "通过传入私钥注册DID")
    @PostMapping("/createByPrikey")
    public ApiResult<CreateWeIdDataResult> createWeidByPriKey(
            @RequestBody CreateByPriKeyModel createByPriKeyModel) {
        return weidService.createWeIdByPriKey(createByPriKeyModel.getPrivateKey());
    }

    @ApiOperation(value = "通过传入公私钥注册DID")
    @PostMapping ("/createByKeys")
    @ResponseBody
    public ApiResult<CreateWeIdDataResult> createWeidKeys(@Valid @RequestBody KeysModel keys) {
        return weidService.createWeIdAndSetAttr(keys.getPublicKey(), keys.getPrivateKey());
    }

    @ApiOperation(value = "通过代理注册DID")
    @PostMapping("/delegateCreateDId")
    @ResponseBody
    public ApiResult<CreateWeIdDataResult> delegateCreateDId(@Valid @RequestBody DelegeteCreateModel delegeteCreateModel) {
        return weidService.delegateCreateWeId(delegeteCreateModel.getPublicKey(), delegeteCreateModel.getDelegateId(),
                delegeteCreateModel.getDelegatePublicKey(), delegeteCreateModel.getDelegatePrivateKey());
    }

    @ApiOperation(value = "查询DID")
    @PostMapping("/queryDid")
    @ResponseBody
    public ApiResult<WeIdDocument> queryDoc(@Valid @RequestBody DidModel didModel) {
        return weidService.getDoc(didModel.getDid());
    }

    @ApiOperation(value = "为指定的DID添加公钥")
    @PostMapping("/addPublicKey")
    @ResponseBody
    public ApiResult<String> addPublicKey(@RequestBody AddPublicKeyModel addPublicKeyModel){
        return weidService.addPublicKey(addPublicKeyModel.getDid(), addPublicKeyModel.getAddPublicKey(),
                addPublicKeyModel.getPrivateKey());
    }

    @ApiOperation(value = "代理方式为指定DID添加公钥")
    @PostMapping("/delegateAddPublicKey")
    @ResponseBody
    public ApiResult<AuthenticationProperty> delegateAddPublicKey(@RequestBody DelegeteServiceAModel delegeteServiceAModel) {
        return weidService.delegateAddPublicKey(delegeteServiceAModel.getDid(),delegeteServiceAModel.getOwnerDid()
                ,delegeteServiceAModel.getOwnerPublicKey(),
                delegeteServiceAModel.getPrivateKey());
    }

    @ApiOperation(value = "添加服务端点")
    @PostMapping("/setService")
    @ResponseBody
    public ApiResult<Boolean> setService (@RequestBody AddServiceModel addServiceModel) {
        return weidService.setService(addServiceModel.getDid(),addServiceModel.getPrivateKey(),
                addServiceModel.getServiceEndpoint(),addServiceModel.getServiceType());
    }

    @ApiOperation(value = "代理方式添加服务端点")
    @PostMapping("/delegateSetService")
    @ResponseBody
    public ApiResult<Boolean> delegateSetService (@RequestBody DelegeteServiceAModel delegeteServiceAModel){
        return weidService.delegateSetService(delegeteServiceAModel.getDid(),delegeteServiceAModel.getPrivateKey(),
                delegeteServiceAModel.getServiceEndpoint(),delegeteServiceAModel.getServiceType());
    }

    @ApiOperation(value = "添加认证方")
    @PostMapping("/setAuthentication")
    @ResponseBody
    public ApiResult<Boolean> setAuthentication (@RequestBody DelegeteServiceAModel delegeteServiceAModel){
        return weidService.setAuthentication(delegeteServiceAModel.getDid(),delegeteServiceAModel.getPublicKey(),
                delegeteServiceAModel.getPrivateKey());
    }

    @ApiOperation(value = "代理方式添加认证方")
    @PostMapping("/delegatesetAuthentication")
    @ResponseBody
    public ApiResult<Boolean> delegatesetAuthentication (@RequestBody DelegeteServiceAModel delegeteServiceAModel){
        return weidService.delegateSetAuthentication(delegeteServiceAModel.getDid(),delegeteServiceAModel.getOwnerDid(),
                delegeteServiceAModel.getOwnerPublicKey(),delegeteServiceAModel.getPrivateKey());
    }

    @ApiOperation(value = "验证DID")
    @PostMapping("/isDIDExist")
    @ResponseBody
    public ApiResult<Boolean> isDIDExist (@RequestBody DidModel didModel){
        return weidService.isDIDExist(didModel.getDid());
    }
}
