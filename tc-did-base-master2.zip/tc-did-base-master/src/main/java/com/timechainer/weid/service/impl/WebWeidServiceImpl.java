/*
 *       Copyright© (2019) WeBank Co., Ltd.
 *
 *       This file is part of weidentity-sample.
 *
 *       weidentity-sample is free software: you can redistribute it and/or modify
 *       it under the terms of the GNU Lesser General Public License as published by
 *       the Free Software Foundation, either version 3 of the License, or
 *       (at your option) any later version.
 *
 *       weidentity-sample is distributed in the hope that it will be useful,
 *       but WITHOUT ANY WARRANTY; without even the implied warranty of
 *       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *       GNU Lesser General Public License for more details.
 *
 *       You should have received a copy of the GNU Lesser General Public License
 *       along with weidentity-sample.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.timechainer.weid.service.impl;
import com.webank.weid.protocol.base.WeIdAuthentication;
import com.webank.weid.constant.CptType;

import java.util.Date;

import com.alibaba.fastjson.JSON;
import com.timechainer.weid.common.util.FileUtil;
import com.timechainer.weid.common.util.PrivateKeyUtil;
import com.timechainer.weid.constant.ApiResult;
import com.timechainer.weid.entity.Weid;
import com.timechainer.weid.mapper.WeidMapper;
import com.timechainer.weid.service.WebWeidService;
import com.webank.weid.constant.CredentialType;
import com.webank.weid.constant.ErrorCode;
import com.webank.weid.protocol.base.*;
import com.webank.weid.protocol.request.*;
import com.webank.weid.protocol.response.CreateWeIdDataResult;
import com.webank.weid.protocol.response.ResponseData;
import com.webank.weid.rpc.AuthorityIssuerService;
import com.webank.weid.rpc.CptService;
import com.webank.weid.rpc.CredentialPojoService;
import com.webank.weid.rpc.WeIdService;
import com.webank.weid.service.impl.AuthorityIssuerServiceImpl;
import com.webank.weid.service.impl.CptServiceImpl;
import com.webank.weid.service.impl.CredentialPojoServiceImpl;
import com.webank.weid.service.impl.WeIdServiceImpl;
import com.webank.weid.util.DataToolUtils;
import lombok.extern.slf4j.Slf4j;
import org.fisco.bcos.web3j.crypto.ECKeyPair;
import org.fisco.bcos.web3j.crypto.gm.GenCredential;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/8/31 2:58 PM
 * @Description //TODO now$
 **/
@Slf4j
@Service
public class WebWeidServiceImpl implements WebWeidService {

    static {
        FileUtil.loadConfigFromEnv();
    }

    private AuthorityIssuerService authorityIssuerService = new AuthorityIssuerServiceImpl();

    private CptService cptService = new CptServiceImpl();

    private CredentialPojoService credentialService = new CredentialPojoServiceImpl();

    private WeIdService weIdService = new WeIdServiceImpl();

    private WeidMapper weidMapper;

    @Autowired
    public void setInjectedBean(WeidMapper toolService) {
        this.weidMapper = toolService;
    }

    /**
     * set validity period to 360 days by default.
     */
    private static final long EXPIRATION_DATE  = 1000L * 60 * 60 * 24 * 365 * 100;


    /**
     * create DID with public and private keys and set related properties.
     *
     * @param publicKey public key
     * @param privateKey private key
     * @return returns the creation of DID
     */
    @Override
    public ApiResult<CreateWeIdDataResult> createWeIdAndSetAttr(String publicKey, String privateKey) {

        log.info("begin create weId and set attribute without parameter");

        // 1, create weId using the incoming public and private keys
        CreateWeIdArgs createWeIdArgs = new CreateWeIdArgs();
        createWeIdArgs.setPublicKey(publicKey);
        createWeIdArgs.setWeIdPrivateKey(new WeIdPrivateKey());
        createWeIdArgs.getWeIdPrivateKey().setPrivateKey(privateKey);

        // TODO:Error of "the public key and private key are not matched"
        ResponseData<String> createResult = weIdService.createWeId(createWeIdArgs);
        log.info("createWeIdAndSetAttr response:{}", createResult);
        if (createResult.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            return ApiResult.failed(createResult.getErrorCode(), createResult.getErrorMessage());
        }

        PrivateKeyUtil.savePrivateKey(
                PrivateKeyUtil.KEY_DIR,
                createResult.getResult(),
                privateKey
        );

        CreateWeIdDataResult weIdData = new CreateWeIdDataResult();
        weIdData.setWeId(createResult.getResult());
        weIdData.setUserWeIdPrivateKey(new WeIdPrivateKey());
        weIdData.getUserWeIdPrivateKey().setPrivateKey(privateKey);

        weIdData.setUserWeIdPublicKey(new WeIdPublicKey());
        weIdData.getUserWeIdPublicKey().setPublicKey(publicKey);

//        // 2, call set public key
//        ResponseData<Boolean> setPublicKeyRes = this.setPublicKey(weIdData);
//        if (!setPublicKeyRes.getResult()) {
//            createResult.setErrorCode(
//                ErrorCode.getTypeByErrorCode(setPublicKeyRes.getErrorCode())
//            );
//            return createResult;
//        }
//

        // 3, call set authentication
        ResponseData<Boolean> setAuthenticateRes = this.setAuthentication(weIdData);
        if (!setAuthenticateRes.getResult()) {
            createResult.setErrorCode(
                    ErrorCode.getTypeByErrorCode(setAuthenticateRes.getErrorCode())
            );
            return ApiResult.failed(setAuthenticateRes.getErrorCode(), setAuthenticateRes.getErrorMessage());
        }
        Weid weid = new Weid();
        weid.setDid(createResult.getResult());
        weid.setBlockHeight(createResult.getTransactionInfo().getBlockNumber().longValue());
        weid.setCreateAt(new Date());
        weid.setTxHash(createResult.getTransactionInfo().getTransactionHash());
        weid.setPrivateKey(privateKey);
        weid.setPublicKey(publicKey);
        weidMapper.insert(weid);
        return ApiResult.success(weIdData);
    }

    /**
     * 创建DID.
     * @return returns the creation of DID
     */
    @Override
    public ApiResult<CreateWeIdDataResult> createWeId() {

        ResponseData<CreateWeIdDataResult> response = createWeIdWithSetAttr();
        // if weId is created successfully, save its private key.
        if (response.getErrorCode() == ErrorCode.SUCCESS.getCode()) {
            PrivateKeyUtil.savePrivateKey(
                    PrivateKeyUtil.KEY_DIR,
                    response.getResult().getWeId(),
                    response.getResult().getUserWeIdPrivateKey().getPrivateKey()
            );
        }

        PrivateKeyUtil.savePrivateKey(
                PrivateKeyUtil.KEY_DIR,
                response.getResult().getWeId(),
                response.getResult().getUserWeIdPrivateKey().getPrivateKey()
        );

        Weid weid = new Weid();
        weid.setDid(response.getResult().getWeId());
        weid.setPrivateKey(response.getResult().getUserWeIdPrivateKey().getPrivateKey());
        weid.setPublicKey(response.getResult().getUserWeIdPublicKey().getPublicKey());
        weid.setCreateAt(new Date());
        weid.setBlockHeight(response.getTransactionInfo().getBlockNumber().longValue());
        weid.setTxHash(response.getTransactionInfo().getTransactionHash());

        ResponseData<String> setResponse = weIdService.getWeIdDocumentJson(response.getResult().getWeId());
        log.info(
                "setWeIdDocumentJson is result,errorCode:{},errorMessage:{}",
                setResponse.getErrorCode(),
                setResponse.getErrorMessage()
        );

        weid.setDidDoc(setResponse.getResult());
        weidMapper.insert(weid);

        /*
         *  private keys are not allowed to be transmitted over http, so this place
         *  annotates the return of private keys to avoid misuse.
         */
        return ApiResult.success(response.getResult());
    }

    /**
     * create a DID by private key
     * @param privateKey private key
     * @return returns the creation of DID
     */
    @Override
    public ApiResult<CreateWeIdDataResult> createWeIdByPriKey(String privateKey) {
        ECKeyPair keyPair = GenCredential.createKeyPair(privateKey);
        if (Objects.isNull(keyPair)) {
            log.error(
                    "[createWeId] Create weId failed.");
            return ApiResult.failed(ErrorCode.valueOf("100103"));
        }
        String publicKey = String.valueOf(keyPair.getPublicKey());
        String priKey = String.valueOf(keyPair.getPrivateKey());

        log.info("start create weid by private key, created public key:{}", publicKey);
        log.debug("start create weid by private key, created public key:{}\nprivate key:{}", publicKey, priKey);
        WeIdPublicKey userWeIdPublicKey = new WeIdPublicKey();
        userWeIdPublicKey.setPublicKey(publicKey);

        WeIdPrivateKey userWeIdPrivateKey = new WeIdPrivateKey();
        userWeIdPrivateKey.setPrivateKey(priKey);

        CreateWeIdArgs createWeIdArgs = new CreateWeIdArgs();
        createWeIdArgs.setPublicKey(userWeIdPublicKey.getPublicKey());
        createWeIdArgs.setWeIdPrivateKey(userWeIdPrivateKey);
        ResponseData<String> createResult = weIdService.createWeId(createWeIdArgs);
        if (createResult.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            return ApiResult.failed(createResult.getErrorCode(), createResult.getErrorMessage());
        }
        CreateWeIdDataResult createWeIdDataResult = new CreateWeIdDataResult();

        // create object of result
        createWeIdDataResult.setWeId(createResult.getResult());
        createWeIdDataResult.setUserWeIdPrivateKey(createWeIdArgs.getWeIdPrivateKey());
        createWeIdDataResult.setUserWeIdPublicKey(userWeIdPublicKey);

        PrivateKeyUtil.savePrivateKey(
                PrivateKeyUtil.KEY_DIR,
                createResult.getResult(),
                priKey
        );

        // 写入数据库
        Weid weid = new Weid();
        weid.setDid(createResult.getResult());
        weid.setPublicKey(createWeIdArgs.getWeIdPrivateKey().getPrivateKey());
        weid.setPrivateKey(createWeIdArgs.getWeIdPrivateKey().getPrivateKey());
        weid.setCreateAt(new Date());
        weid.setTxHash(createResult.getTransactionInfo().getTransactionHash());
        weid.setBlockHeight(createResult.getTransactionInfo().getBlockNumber().longValue());

        ResponseData<String> setResponse = getWeIdDocumentJson(createResult.getResult());
        log.info(
                "setWeIdDocumentJson is result,errorCode:{},errorMessage:{}",
                setResponse.getErrorCode(),
                setResponse.getErrorMessage()
        );
        weid.setDidDoc(setResponse.getResult());
        weidMapper.insert(weid);
        return ApiResult.success(createWeIdDataResult);
    }

    /**
     * delegate create DID
     * @param publicKey public key
     * @param delegateDid delegate DID
     * @param delegatePrivateKey delegate Private Key
     * @param delegatePublicKey delegate Public Key
     * @return returns the creation of DID
     */
    @Override
    public ApiResult<CreateWeIdDataResult> delegateCreateWeId(String publicKey, String delegateDid, String delegatePublicKey, String delegatePrivateKey) {
        WeIdPublicKey weIdPublicKey = new WeIdPublicKey();
        weIdPublicKey.setPublicKey(publicKey);

        // set delegate authentication
        WeIdAuthentication weIdAuthentication = new WeIdAuthentication();
        weIdAuthentication.setWeIdPublicKeyId(delegatePublicKey);
        weIdAuthentication.setWeId(delegateDid);
        WeIdPrivateKey weIdPrivateKey = new WeIdPrivateKey();
        weIdPrivateKey.setPrivateKey(delegatePrivateKey);
        weIdAuthentication.setWeIdPrivateKey(weIdPrivateKey);

        ResponseData<String> createResult = weIdService.delegateCreateWeId(weIdPublicKey, weIdAuthentication);

        if (createResult.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            return  ApiResult.failed(createResult.getErrorCode(), createResult.getErrorMessage());
        }

        CreateWeIdDataResult createWeIdDataResult = new CreateWeIdDataResult();
        createWeIdDataResult.setWeId(createResult.getResult());
        createWeIdDataResult.setUserWeIdPrivateKey(createWeIdDataResult.getUserWeIdPrivateKey());
        createWeIdDataResult.setUserWeIdPublicKey(createWeIdDataResult.getUserWeIdPublicKey());
        Weid weid = new Weid();
        weid.setDid(createResult.getResult());
        weid.setPublicKey(weIdPublicKey.getPublicKey());
        weid.setPrivateKey("");
        weid.setCreateAt(new Date());
        weid.setTxHash(createResult.getTransactionInfo().getTransactionHash());
        weid.setBlockHeight(createResult.getTransactionInfo().getBlockNumber().longValue());

        ResponseData<String> setResult = getWeIdDocumentJson(createResult.getResult());
        if (createResult.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            return  ApiResult.failed(createResult.getErrorCode(), createResult.getErrorMessage());
        }
        weid.setDidDoc(setResult.getResult());
        weidMapper.insert(weid);
        return ApiResult.success(createWeIdDataResult);

    }

    /**
     * get information of DID
     * @param did DID
     * @return returns the information of DID
     */
    private ResponseData<String> getWeIdDocumentJson(String did) {
        ResponseData<String> setResponse = weIdService.getWeIdDocumentJson(did);
        log.info(
                "setWeIdDocumentJson is result,errorCode:{},errorMessage:{}",
                setResponse.getErrorCode(),
                setResponse.getErrorMessage()
        );
        return  setResponse;
    }

    /**
     * create DID and set related properties.
     *
     * @return returns the create weId and public private keys
     */
    private ResponseData<CreateWeIdDataResult> createWeIdWithSetAttr() {

        log.info("begin create weId and set attribute");

        // 1, create weId, this method automatically creates public and private keys
        ResponseData<CreateWeIdDataResult> createResult = weIdService.createWeId();
        log.info(
                "weIdService is result,errorCode:{},errorMessage:{}",
                createResult.getErrorCode(), createResult.getErrorMessage()
        );

        if (createResult.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            return createResult;
        }

        // 3, call set authentication
        ResponseData<Boolean> setAuthenticateRes = this.setAuthentication(createResult.getResult());
        if (!setAuthenticateRes.getResult()) {
            createResult.setErrorCode(
                    ErrorCode.getTypeByErrorCode(setAuthenticateRes.getErrorCode())
            );
            return createResult;
        }
        return createResult;
    }


    /**
     * get information of DID
     * @param did DID
     * @return returns the information of DID
     */
    @Override
    public ApiResult<WeIdDocument> getDoc(String did) {
        ResponseData<WeIdDocument> responseData = weIdService.getWeIdDocument(did);
        if (responseData.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            return ApiResult.failed(responseData.getErrorCode(), responseData.getErrorMessage());
        } else {
            return ApiResult.success(responseData.getResult());
        }
    }


    /**
     * add public key
     * @param did DID
     * @param addPublicKey add public key
     * @param privateKey private key
     * @return returns the information of add public key
     */
    @Override
    public ApiResult<String> addPublicKey(String did, String addPublicKey, String privateKey) {
        PublicKeyArgs publicKeyArgs = new PublicKeyArgs();
        publicKeyArgs.setPublicKey(addPublicKey);
        publicKeyArgs.setOwner(did);

        WeIdPrivateKey weIdPrivateKey = new WeIdPrivateKey();
        weIdPrivateKey.setPrivateKey(privateKey);

        ResponseData<Integer> responseData = weIdService.addPublicKey(did, publicKeyArgs, weIdPrivateKey);
        if (responseData.getErrorCode()!= ErrorCode.SUCCESS.getCode()){
         return ApiResult.failed(responseData.getErrorCode(),responseData.getErrorMessage());
        }
        ResponseData<WeIdDocument> responseData1 = weIdService.getWeIdDocument(did);

        weidMapper.updateDoc(did, JSON.toJSONString(responseData1.getResult()));

        List<PublicKeyProperty> publicKeyProperties = responseData1.getResult().getPublicKey();
        for (PublicKeyProperty pubKey: publicKeyProperties) {
            if (pubKey.getPublicKey().equals(addPublicKey)) {
                return ApiResult.success(pubKey.getId());
            }
        }
        return null;
    }

    /**
     * Add publickey for DID
     * @param did DID
     * @param ownerPublicKey owner public key
     * @param privateKey private key
     * @return returns the information of add public key
     */
    @Override
    public ApiResult<AuthenticationProperty> delegateAddPublicKey(String did, String ownerDID, String ownerPublicKey, String privateKey) {
        PublicKeyArgs publicKeyArgs = new PublicKeyArgs();
        publicKeyArgs.setPublicKey(ownerPublicKey);
        WeIdPrivateKey weIdPrivateKey = new WeIdPrivateKey();
        weIdPrivateKey.setPrivateKey(privateKey);
        ResponseData<Integer> responseData = weIdService.delegateAddPublicKey(did,publicKeyArgs,weIdPrivateKey);
        if (responseData.getErrorCode()!=ErrorCode.SUCCESS.getCode()){
            return ApiResult.failed(responseData.getErrorCode(),responseData.getErrorMessage());
        }
        ResponseData<WeIdDocument> responseData1 = weIdService.getWeIdDocument(ownerDID);
        if (responseData1.getErrorCode()!=ErrorCode.SUCCESS.getCode()){
            return ApiResult.failed(responseData1.getErrorCode(),responseData1.getErrorMessage());
        }
        List<AuthenticationProperty> authenticationProperties = responseData1.getResult().getAuthentication();
        return ApiResult.success(authenticationProperties.get(2));
    }


    /**
     * set service
     * @param did DID
     * @param privateKey private key
     * @param servicePoint service point
     * @param serviceType service type
     * @return returns the information of set service
     */
    @Override
    public ApiResult<Boolean> setService(String did, String privateKey, String servicePoint, String serviceType) {
        ServiceArgs serviceArgs = new ServiceArgs();
        serviceArgs.setServiceEndpoint(servicePoint);
        serviceArgs.setType(serviceType);
        WeIdPrivateKey weIdPrivateKey = new WeIdPrivateKey();
        weIdPrivateKey.setPrivateKey(privateKey);
        ResponseData<Boolean> responseData = weIdService.setService(did,serviceArgs,weIdPrivateKey);
        if (responseData.getErrorCode()!=ErrorCode.SUCCESS.getCode()){
            return ApiResult.failed(responseData.getErrorCode(),responseData.getErrorMessage());
        }
        ResponseData<String> doc = weIdService.getWeIdDocumentJson(did);
        if (ErrorCode.SUCCESS.getCode() != doc.getErrorCode()) {
            weidMapper.updateDoc(did, doc.getResult());
        }
        return ApiResult.success(responseData.getResult());
    }


    /**
     * set service
     * @param did DID
     * @param privateKey private key
     * @param servicePoint service point
     * @param serviceType service type
     * @return returns the information of set service
     */
    @Override
    public ApiResult<Boolean> delegateSetService(String did, String privateKey, String servicePoint, String serviceType){
            ServiceArgs serviceArgs = new ServiceArgs();
            serviceArgs.setType(serviceType);
            serviceArgs.setServiceEndpoint(servicePoint);
            String delegatePrivateKey = privateKey;
            ResponseData<Boolean> responseData = weIdService.delegateSetService(did,serviceArgs,new WeIdPrivateKey(delegatePrivateKey));
            if (responseData.getErrorCode() != ErrorCode.SUCCESS.getCode() ){
                return ApiResult.failed(responseData.getErrorCode(),responseData.getErrorMessage());
            }
            return ApiResult.success(responseData.getResult());

    }


    /**
     * set authentication
     * @param did DID
     * @param ownerPublicKey owner public key
     * @param ownerPrivateKey owner private key
     * @return returns the information of set authentication
     */
    @Override
    public ApiResult<Boolean> setAuthentication(String did, String ownerPublicKey, String ownerPrivateKey) {
        AuthenticationArgs authenticationArgs = new AuthenticationArgs();
        authenticationArgs.setPublicKey(ownerPublicKey);
        WeIdPrivateKey weIdPrivateKey = new WeIdPrivateKey();
        weIdPrivateKey.setPrivateKey(ownerPrivateKey);
        ResponseData<Boolean> responseData = weIdService.setAuthentication(did,authenticationArgs,weIdPrivateKey);
        if (responseData.getErrorCode() != ErrorCode.SUCCESS.getCode() ){
            return ApiResult.failed(responseData.getErrorCode(),responseData.getErrorMessage());
        }
        return ApiResult.success(responseData.getResult());
    }

    /**
     * set authentication
     * @param did did
     * @param ownerDid owner did
     * @param ownerPublicKey owner public key
     * @param privateKey private key
     * @return returns the information of set authentication
     */
    @Override
    public ApiResult<Boolean> delegateSetAuthentication(String did, String ownerDid, String ownerPublicKey, String privateKey){
            AuthenticationArgs authenticationArgs = new AuthenticationArgs();
            authenticationArgs.setOwner(ownerDid);
            authenticationArgs.setPublicKey(ownerPublicKey);
            String deleagtePrivateKey = privateKey;
            ResponseData<Boolean> responseData = weIdService.delegateSetAuthentication(did,authenticationArgs,new WeIdPrivateKey(deleagtePrivateKey));
            if (responseData.getErrorCode() != ErrorCode.SUCCESS.getCode() ){
            return ApiResult.failed(responseData.getErrorCode(),responseData.getErrorMessage());
            }
            return ApiResult.success(responseData.getResult());
    }

    /**
     * Check whether DID exist on the blockchain
     * @param weId
     * @return
     */
    @Override
    public ApiResult<Boolean> isDIDExist(String weId){
        ResponseData<Boolean> response = weIdService.isWeIdExist(weId);
        log.info(
                "isWeIdExist is result,errorCode:{},errorMessage:{}",
                response.getErrorCode(),
                response.getErrorMessage()
        );
        if (response.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            return ApiResult.success(false);
        }
        return ApiResult.success(response.getResult());
    }


    /**
     * Set Authentication For WeIdentity DID Document.
     *
     * @param createWeIdDataResult createWeIdDataResult the object of CreateWeIdDataResult
     * @return the response data
     */
    private ResponseData<Boolean> setAuthentication(CreateWeIdDataResult createWeIdDataResult) {

        AuthenticationArgs authenticationArgs = new AuthenticationArgs();
        authenticationArgs.setPublicKey(createWeIdDataResult.getUserWeIdPublicKey().getPublicKey());

        ResponseData<Boolean> setResponse = weIdService.setAuthentication(
                createWeIdDataResult.getWeId(),
                authenticationArgs,
                createWeIdDataResult.getUserWeIdPrivateKey());

        log.info(
                "setAuthentication is result,errorCode:{},errorMessage:{}",
                setResponse.getErrorCode(),
                setResponse.getErrorMessage()
        );
        return setResponse;
    }

    /**
     * register on the chain as an authoritative body.
     *
     * @param authorityName the name of the issue
     * @return true is success, false is failure
     */
    @Override
    public ResponseData<Boolean> registerAuthorityIssuer(String issuer, String authorityName) {

        // build registerAuthorityIssuer parameters.
        AuthorityIssuer authorityIssuerResult = new AuthorityIssuer();
        authorityIssuerResult.setWeId(issuer);
        authorityIssuerResult.setName(authorityName);
        authorityIssuerResult.setAccValue("0");

        RegisterAuthorityIssuerArgs registerAuthorityIssuerArgs = new RegisterAuthorityIssuerArgs();
        registerAuthorityIssuerArgs.setAuthorityIssuer(authorityIssuerResult);
        registerAuthorityIssuerArgs.setWeIdPrivateKey(new WeIdPrivateKey());

        // getting SDK private key from file.
        String privKey = FileUtil.getDataByPath(PrivateKeyUtil.SDK_PRIVKEY_PATH);

        registerAuthorityIssuerArgs.getWeIdPrivateKey().setPrivateKey(privKey);

        ResponseData<Boolean> registResponse =
                authorityIssuerService.registerAuthorityIssuer(registerAuthorityIssuerArgs);
        log.info(
                "registerAuthorityIssuer is result,errorCode:{},errorMessage:{}",
                registResponse.getErrorCode(),
                registResponse.getErrorMessage()
        );
        return registResponse;
    }

    /**
     * registered CPT.
     *
     * @param publisher the weId of the publisher
     * @param privateKey the private key of the publisher
     * @param claim claim is CPT
     * @return returns cptBaseInfo
     */
    @Override
    public ResponseData<CptBaseInfo> registCpt(
            String publisher,
            String privateKey,
            Map<String, Object> claim,
            Integer cptID) {

        // build registerCpt parameters.
        WeIdAuthentication weIdAuthentication = new WeIdAuthentication();
        weIdAuthentication.setWeId(publisher);
        weIdAuthentication.setWeIdPrivateKey(new WeIdPrivateKey());
        weIdAuthentication.getWeIdPrivateKey().setPrivateKey(privateKey);

        CptMapArgs cptMapArgs = new CptMapArgs();

        cptMapArgs.setWeIdAuthentication(weIdAuthentication);
        cptMapArgs.setCptJsonSchema(claim);
        cptMapArgs.setCptType(CptType.ORIGINAL);

        // create CPT by SDK
        ResponseData<CptBaseInfo> response;
        if (null != cptID) {
            response = cptService.registerCpt(cptMapArgs, cptID);
        } else {
            response = cptService.registerCpt(cptMapArgs);
        }
        log.info(
                "registerCpt is result,errorCode:{},errorMessage:{}",
                response.getErrorCode(),
                response.getErrorMessage()
        );
        return response;
    }

    @Override
    public ResponseData<Cpt> queryCpt(Integer cptId) {
        ResponseData<Cpt> cptResponseData = cptService.queryCpt(cptId);
        log.info(
                "queryCpt is result,errorCode:{},errorMessage:{}",
                cptResponseData.getErrorCode(),
                cptResponseData.getErrorMessage()
        );
        return cptResponseData;
    }

    /**
     * create credential.
     *
     * @param cptId the cptId of CPT
     * @param issuer the weId of issue
     * @param privateKey the private key of issuer
     * @param claimDate the data of claim
     * @return returns credential
     */
    @Override
    public ResponseData<CredentialPojo> createCredential(
            Integer cptId,
            String issuer,
            String privateKey,
            Map<String, Object> claimDate) {

        // build createCredential parameters.
        CreateCredentialPojoArgs<Map<String, Object>> args = new CreateCredentialPojoArgs<>();
        args.setCptId(cptId);
        args.setIssuer(issuer);
        args.setType(CredentialType.ORIGINAL);
        args.setClaim(claimDate);
        // the validity period is 360 days
        args.setExpirationDate(System.currentTimeMillis() + EXPIRATION_DATE);

        WeIdAuthentication weIdAuthentication = new WeIdAuthentication();
        weIdAuthentication.setWeIdPrivateKey(new WeIdPrivateKey());
        weIdAuthentication.getWeIdPrivateKey().setPrivateKey(privateKey);
        weIdAuthentication.setWeId(issuer);
        weIdAuthentication.setWeIdPublicKeyId(issuer);
        args.setWeIdAuthentication(weIdAuthentication);

        // create credentials by SDK.
        ResponseData<CredentialPojo> response =
                credentialService.createCredential(args);
        log.info(
                "createCredential is result,errorCode:{},errorMessage:{}",
                response.getErrorCode(),
                response.getErrorMessage()
        );
        return response;
    }

    /**
     * verifyEvidence credential.
     *
     * @param credentialJson credentials in JSON format
     * @return returns the result of verifyEvidence
     */
    @Override
    public ResponseData<Boolean> verifyCredential(String credentialJson) {

        ResponseData<Boolean> verifyResponse = null;

        CredentialPojo credential = DataToolUtils.deserialize(credentialJson, CredentialPojo.class);
        // verifyEvidence credential on chain.
        verifyResponse = credentialService.verify(credential.getIssuer(), credential);
        log.info(
                "verifyCredential is result,errorCode:{},errorMessage:{}",
                verifyResponse.getErrorCode(),
                verifyResponse.getErrorMessage()
        );
        return verifyResponse;
    }

    @Override
    public ResponseData<Boolean> recognizeAuthorityIssuer(String issuer) {
        // getting SDK private key from file.
        String privKey = FileUtil.getDataByPath(PrivateKeyUtil.SDK_PRIVKEY_PATH);
        WeIdPrivateKey weIdPrivateKey = new WeIdPrivateKey();
        weIdPrivateKey.setPrivateKey(privKey);
        ResponseData<Boolean> registResponse =
                authorityIssuerService.recognizeAuthorityIssuer(issuer, weIdPrivateKey);
        log.info(
                "recognizeAuthorityIssuer is result,errorCode:{},errorMessage:{}",
                registResponse.getErrorCode(),
                registResponse.getErrorMessage()
        );
        return registResponse;
    }

}
