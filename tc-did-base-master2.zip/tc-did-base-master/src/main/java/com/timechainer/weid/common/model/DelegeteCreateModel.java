package com.timechainer.weid.common.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;


@Data
@ToString
@ApiModel(description = "代理模板")
public class DelegeteCreateModel {

    @ApiModelProperty(name = "publicKey", value = "用户公钥", required = true,
            example = "10884791889573885961573595923034451846181288826676102791986473114109409913876511177868710733244026350522372286607643048335587344589818301443523106616678574")
    private String publicKey;

    @ApiModelProperty(name = "delegateId", value = "代理人DID", required = true,
            example = "did:weid:1:0x19607cf2bc4538b49847b43688acf3befc487a41")
    private String delegateId;

    @ApiModelProperty(name = "delegatePrivateKey", value = "代理人私钥", required = true,
            example = "53079349606873082534274061523339694826923290877435862289172419522326067705985")
    private String delegatePrivateKey;

    @ApiModelProperty(name = "delegatePublicKey", value = "代理人公钥", required = true,
            example = "10884791889573885961573595923034451846181288826676102791986473114109409913876511177868710733244026350522372286607643048335587344589818301443523106616678574")
    private String delegatePublicKey;
}