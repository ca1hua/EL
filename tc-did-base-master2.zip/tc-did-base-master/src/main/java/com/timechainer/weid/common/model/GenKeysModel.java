package com.timechainer.weid.common.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/5 3:55 PM
 * @Description //TODO $
 **/
@Data
public class GenKeysModel {
    @ApiModelProperty(name = "isGM", value = "是否为国密", required = true,
            example = "false")
    private Boolean isGM;
}
