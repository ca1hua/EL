/*
 *       Copyright© (2019) WeBank Co., Ltd.
 *
 *       This file is part of weidentity-sample.
 *
 *       weidentity-sample is free software: you can redistribute it and/or modify
 *       it under the terms of the GNU Lesser General Public License as published by
 *       the Free Software Foundation, either version 3 of the License, or
 *       (at your option) any later version.
 *
 *       weidentity-sample is distributed in the hope that it will be useful,
 *       but WITHOUT ANY WARRANTY; without even the implied warranty of
 *       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *       GNU Lesser General Public License for more details.
 *
 *       You should have received a copy of the GNU Lesser General Public License
 *       along with weidentity-sample.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.timechainer.weid.service;

import com.timechainer.weid.constant.ApiResult;
import com.webank.weid.protocol.base.*;
import com.webank.weid.protocol.response.CreateWeIdDataResult;
import com.webank.weid.protocol.response.ResponseData;

import java.util.Map;

/**
 * demo interface.
 *
 * @author v_wbgyang
 *
 */
public interface WebWeidService {

    /**
     * create DID with public and private keys and set related properties.
     *
     * @param publicKey public key
     * @param privateKey private key
     * @return returns the create DID
     */
    ApiResult<CreateWeIdDataResult> createWeIdAndSetAttr(String publicKey, String privateKey);

    /**
     * create DID and set related properties.
     *
     * @return returns the create DID and public private keys
     */
    ApiResult<CreateWeIdDataResult> createWeId();

    /**
     * create DID by privateKey.
     * @param privateKey
     * @return
     */
    ApiResult<CreateWeIdDataResult> createWeIdByPriKey(String privateKey);

    /**
     * @author: renhuikang
     * @date: 2021/9/7 6:39 PM
     * @description:
     * DELEGATE
     * @return
     **/
    ApiResult<CreateWeIdDataResult> delegateCreateWeId(String publicKey, String delegateId,String delegatePrivateKey,String delegatePublicKey);


    /**
     * addPublicKey
     * @param DID
     * @param addPublicKey
     * @param publicKey
     * @return
     */
    ApiResult<String> addPublicKey(String DID, String addPublicKey, String publicKey);

    /**
     * delegateAddPublickey
     * @param DID
     * @param ownerPublicKey
     * @param privateKey
     * @return
     */
    ApiResult<AuthenticationProperty> delegateAddPublicKey(String DID, String ownerDID, String ownerPublicKey, String privateKey );

    /**
     * setservice
     * @param DID
     * @param privateKey
     * @param servicePoint
     * @param serviceType
     * @return
     */
    ApiResult<Boolean> setService(String DID, String privateKey, String servicePoint, String serviceType);

    /**
     * delegateSetService
     * @param DID
     * @param privateKey
     * @param servicePoint
     * @param serviceType
     * @return
     */
    ApiResult<Boolean> delegateSetService(String DID, String privateKey, String servicePoint,String serviceType );

    /**
     * isWeIdExist?
     * @param var1
     * @return
     */
    ApiResult<Boolean> isDIDExist(String var1);

    /**
     * setAuthentication
     * @param  DID
     * @param ownerPublicKey
     * @param ownerPrivateKey
     * @return
     */
   ApiResult<Boolean> setAuthentication( String DID, String ownerPublicKey,String ownerPrivateKey);

    /**
     * delegateSetAuthentication
     * @param DID
     * @param ownerDID
     * @param ownerPublicKey
     * @param privateKey
     * @return
     */
    ApiResult<Boolean> delegateSetAuthentication(String DID,String ownerDID,String ownerPublicKey,String privateKey );
    /**
     * register on the chain as an authoritative body.
     *
     * @param authorityName the name of the issue
     * @return true is success, false is failure
     */

    ResponseData<Boolean> registerAuthorityIssuer(String issuer, String authorityName);

    /**
     * recognize the issuer on chain.
     *
     * @param issuer the issue
     * @return true is success, false is failure
     */
    ResponseData<Boolean> recognizeAuthorityIssuer(String issuer);

    /**
     * registered CPT.
     *
     * @param publisher the weId of the publisher
     * @param privateKey the private key of the publisher
     * @param claim claim is CPT
     * @return returns cptBaseInfo
     */
    ResponseData<CptBaseInfo> registCpt(
            String publisher,
            String privateKey,
            Map<String, Object> claim,
            Integer cptID
    );

    /**
     * query CPT.
     *
     * @param cptId cptId
     * @return returns cptBaseInfo
     */
    ResponseData<Cpt> queryCpt(
            Integer cptId
    );

    /**
     * create credential.
     *
     * @param cptId the cptId of CPT
     * @param issuer the weId of issue
     * @param privateKey the private key of issuer
     * @param claimDate the data of claim
     * @return returns credential
     */
    ResponseData<CredentialPojo> createCredential(
            Integer cptId,
            String issuer,
            String privateKey,
            Map<String, Object> claimDate
    );

    /**
     * verifyEvidence credential.
     *
     * @param credentialJson credentials in JSON format
     * @return returns the result of verifyEvidence
     */
    ResponseData<Boolean> verifyCredential(String credentialJson);

    ApiResult<WeIdDocument> getDoc(String weid);
}
