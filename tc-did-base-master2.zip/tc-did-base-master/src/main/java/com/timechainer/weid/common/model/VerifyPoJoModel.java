package com.timechainer.weid.common.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/6 5:19 PM
 * @Description //TODO $
 **/
@Data
public class VerifyPoJoModel {

    @ApiModelProperty(name = "credentialId", value = "凭证ID", required = true,
            example = "10412209-af72-44ba-8462-43b857890338")
    private String credentialId;

    @ApiModelProperty(name = "issuerDid", value = "凭证发行者DID", required = true,
            example = "did:weid:1:0x19607cf2bc4538b49847b43688acf3befc487a41")
    private String issuerDid;

    @ApiModelProperty(name = "publicKey", value = "公钥", required = true,
            example = "10884791889573885961573595923034451846181288826676102791986473114109409913876511177868710733244026350522372286607643048335587344589818301443523106616678574")
    private String publicKey;

    @ApiModelProperty(name = "publicKeyId", value = "公钥ID", required = true,
            example = "did:weid:1:0x19607cf2bc4538b49847b43688acf3befc487a41#keys-0")
    private String publicKeyId;
}
