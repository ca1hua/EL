package com.timechainer.weid.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.timechainer.weid.common.model.CreateCredentialPojoModel;
import com.timechainer.weid.common.model.CreateSelectiveCredentialModel;
import com.timechainer.weid.common.model.VerifyPoJoModel;
import com.timechainer.weid.common.util.CommonUtils;
import com.timechainer.weid.constant.ApiResult;
import com.timechainer.weid.constant.ErrorCodeEnum;
import com.timechainer.weid.entity.Cpt;
import com.timechainer.weid.entity.WebCredential;
import com.timechainer.weid.mapper.CptMapper;
import com.timechainer.weid.mapper.WebCredentialMapper;
import com.timechainer.weid.service.WebCredentialService;
import com.webank.weid.constant.CredentialType;
import com.webank.weid.constant.ErrorCode;
import com.webank.weid.protocol.base.*;
import com.webank.weid.protocol.request.CreateCredentialPojoArgs;
import com.webank.weid.protocol.response.ResponseData;
import com.webank.weid.protocol.response.TransactionInfo;
import com.webank.weid.rpc.CredentialPojoService;
import com.webank.weid.service.impl.CredentialPojoServiceImpl;
import com.webank.weid.util.DataToolUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * @email $1602205111@qq.com
 * @author: mayifan
 * @date: 2021/9/2
 * @time: 10:04
 */
@Slf4j
@Service
public class WebCredentialServiceImpl implements WebCredentialService {

    @Autowired
    private WebCredentialMapper credentialMapper;

    @Autowired
    private CptMapper cptMapper;

    private final CredentialPojoService credentialPojoService = new CredentialPojoServiceImpl();



    /**
     * 按照凭证ID查询相关的证书信息
     * @param credentialId credential id
     * @return the result of query credential
     */
    @Override
    public ApiResult<WebCredential> selectById(String credentialId) {
        WebCredential webCredential = credentialMapper.query(credentialId);
        if (null == webCredential) {
            return ApiResult.failed(ErrorCode.CREDENTIAL_CPT_NOT_EXISTS);
        }
        else {
            return ApiResult.success(webCredential);
        }
    }

    @Override
    public ApiResult<Boolean> verifyById(VerifyPoJoModel verifyPoJoModel) {
        WebCredential webCredentialResult = credentialMapper.selectById(verifyPoJoModel.getCredentialId());
        // 查询为空
        if (null == webCredentialResult) {
            return ApiResult.success(false);
        } else {
            CredentialPojo credentialPojo = JSON.parseObject(webCredentialResult.getCredential(), CredentialPojo.class);
            ResponseData<Boolean> verifyResult;
            if (verifyPoJoModel.getPublicKeyId() != null) {
                verifyResult = credentialPojoService.verify(verifyPoJoModel.getIssuerDid(),
                        verifyPoJoModel.getPublicKeyId(), credentialPojo);
            } else if (verifyPoJoModel.getPublicKey() != null) {
                WeIdPublicKey weIdPublicKey = new WeIdPublicKey();
                weIdPublicKey.setPublicKey(verifyPoJoModel.getPublicKey());
                verifyResult = credentialPojoService.verify(weIdPublicKey, credentialPojo);
            } else {
                verifyResult = credentialPojoService.verify(verifyPoJoModel.getIssuerDid(),credentialPojo);
            }

            if (verifyResult.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
                return ApiResult.success(false);
            } else {
                return ApiResult.success(verifyResult.getResult());
            }
        }
    }

    @Override
    public ApiResult<CredentialPojo> createCredentialPojo(
            CreateCredentialPojoModel createCredentialPojoModel) {
        String methodName = Thread.currentThread().getStackTrace()[1].getMethodName();
        log.info("{} createCredentialPojoModel: {}", methodName,
                DataToolUtils.objToJsonStrWithNoPretty(createCredentialPojoModel));

        if (null == createCredentialPojoModel
                || StringUtils.isBlank(createCredentialPojoModel.getIssuer())
                || null == createCredentialPojoModel.getCptId()
                || createCredentialPojoModel.getClaimData().isEmpty()
        ) {
            return ApiResult.failed(ErrorCode.ILLEGAL_INPUT);
        }
        // 设置创建参数
        CreateCredentialPojoArgs<Map<String, Object>> createCredentialPojoArgs
                = new CreateCredentialPojoArgs<>();

        createCredentialPojoArgs.setCptId(createCredentialPojoModel.getCptId());
        createCredentialPojoArgs.setIssuer(createCredentialPojoModel.getIssuer());
        createCredentialPojoArgs.setType(CredentialType.ORIGINAL);
        createCredentialPojoArgs.setExpirationDate(createCredentialPojoModel.getExpireDate().getTime());

        WeIdAuthentication weIdAuthentication = new WeIdAuthentication();
        weIdAuthentication.setWeId(createCredentialPojoModel.getIssuer());
        weIdAuthentication.setWeIdPrivateKey(new WeIdPrivateKey());
        weIdAuthentication.getWeIdPrivateKey().setPrivateKey(createCredentialPojoModel.getPrivateKey());
        weIdAuthentication.setWeIdPublicKeyId(createCredentialPojoModel.getPublicKeyId());
        createCredentialPojoArgs.setWeIdAuthentication(weIdAuthentication);
        createCredentialPojoArgs.setClaim(createCredentialPojoModel.getClaimData());

        ResponseData<CredentialPojo> responseData
                = credentialPojoService.createCredential(createCredentialPojoArgs);
        log.info("{} responseData:{}",
                methodName, DataToolUtils.objToJsonStrWithNoPretty(responseData));
        if (responseData.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            return ApiResult.failed(responseData.getErrorCode(), responseData.getErrorMessage());
        } else {
            savetoDB(responseData.getResult(), responseData.getTransactionInfo(), false);
            return ApiResult.success(responseData.getResult());
        }
    }

    @Override
    public ApiResult<ArrayList<HashMap<String, Object>>> queryClaim(String cptId) {
        Cpt cpt = cptMapper.selectById(cptId);
        if (null == cpt) {
            return ApiResult.failed(ErrorCodeEnum.CPT_IS_NOT_EXIST);
        }
        Map<String, Object> claim = JSONObject.parseObject(cpt.getClaim(), Map.class);
        ArrayList<HashMap<String, Object>> arrayList = new ArrayList<>();
        String rlt;
        for(String k: claim.keySet()) {
            HashMap<String, Object> map = new HashMap<>();
            map.put("type", k);
            map.put("value", claim.get(k));
            arrayList.add(map);
        }
        return ApiResult.success(arrayList);
    }

    @Override
    public ApiResult<CredentialPojo> createSelectiveCredential(
            CreateSelectiveCredentialModel createSelectiveCredentialModel) {
        String methodName = Thread.currentThread().getStackTrace()[1].getMethodName();
        try {
            log.info("{} createSelectiveCredentialModel: {}", methodName,
                    DataToolUtils.objToJsonStrWithNoPretty(createSelectiveCredentialModel));
            Boolean isInDb = false;
            if (!createSelectiveCredentialModel.getCredentialId().isEmpty()) {
                WebCredential credential = credentialMapper.selectById(createSelectiveCredentialModel.getCredentialId());
                createSelectiveCredentialModel.setCredential(JSON.parseObject(credential.getCredential()));
                isInDb = true;
            }
            CredentialPojo credentialPojo = DataToolUtils.mapToObj(
                    createSelectiveCredentialModel.getCredential(), CredentialPojo.class);
            // 选择性披露
            ClaimPolicy claimPolicy = new ClaimPolicy();
            claimPolicy.setFieldsToBeDisclosed(
                    DataToolUtils.objToJsonStrWithNoPretty(
                            createSelectiveCredentialModel.getFieldsToBeDisclosed()));
            ResponseData<CredentialPojo> selectiveResponse =
                    credentialPojoService.createSelectiveCredential(credentialPojo, claimPolicy);
            log.info("{} selectiveResponse: {}",
                    methodName, DataToolUtils.objToJsonStrWithNoPretty(selectiveResponse));

            if(selectiveResponse.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
                return ApiResult.failed(selectiveResponse.getErrorCode(), selectiveResponse.getErrorMessage());
            } else {
                savetoDB(selectiveResponse.getResult(), selectiveResponse.getTransactionInfo(), isInDb);
                return ApiResult.success(selectiveResponse.getResult());
            }
        } catch (Exception e) {
            log.error("{} error", methodName, e);
            return ApiResult.failed(ErrorCode.TRANSACTION_EXECUTE_ERROR);
        }
    }

    private void savetoDB(CredentialPojo credentialPojo, TransactionInfo transactionInfo, boolean isInDb) {
        WebCredential webCredential = new WebCredential();
        webCredential.setId(credentialPojo.getId());
        webCredential.setIssuer(credentialPojo.getIssuer());
        webCredential.setCptId(credentialPojo.getCptId());
        webCredential.setCredential(CommonUtils.formatObjectToString(credentialPojo));
        webCredential.setIsValid(true);
        if (isInDb) {
            credentialMapper.updateById(webCredential);
        } else {
            credentialMapper.insert(webCredential);
        }
    }
}
