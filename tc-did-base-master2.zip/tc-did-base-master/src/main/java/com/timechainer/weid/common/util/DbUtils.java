package com.timechainer.weid.common.util;

import com.timechainer.weid.constant.TypeEnum;
import com.timechainer.weid.entity.AuthorityAgent;
import com.timechainer.weid.entity.AuthorityAgentLog;
import com.timechainer.weid.mapper.AuthorityAgentLogMapper;
import com.timechainer.weid.mapper.AuthorityAgentMapper;
import com.webank.weid.protocol.base.AuthorityIssuer;
import com.webank.weid.protocol.response.TransactionInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/11 4:45 PM
 * @Description //TODO $
 **/
@Component
public class DbUtils {

    @Autowired
    private AuthorityAgentMapper authorityAgentMapper;

    @Autowired
    private AuthorityAgentLogMapper authorityAgentLogMapper;
//    private static AuthorityAgentMapper authorityAgentMapper;
//
//    private static AuthorityAgentLogMapper authorityAgentLogMapper;
//
//    @Autowired
//    public void setInjectedBean(AuthorityAgentLogMapper authorityAgentLogMapper, AuthorityAgentMapper authorityAgentMapper) {
//        DbUtils.authorityAgentMapper = authorityAgentMapper;
//        DbUtils.authorityAgentLogMapper = authorityAgentLogMapper;
//    }

    public void saveIssuerToDB(AuthorityIssuer agent, boolean isIssuer, Enum type,
                               TransactionInfo transactionInfo, String info) {
        saveLog(agent, type, transactionInfo, info);
        if (!info.equals("success")) {
        } else {
            AuthorityAgent authorityAgent = new AuthorityAgent();
            authorityAgent.setDid(agent.getWeId());
            authorityAgent.setName(agent.getName());
            authorityAgent.setAccValue(agent.getAccValue());
            authorityAgent.setCreatedAt(new Date(agent.getCreated()));
            authorityAgent.setType("");
            authorityAgent.setIsIssuer(isIssuer);
            authorityAgent.setTxHash(transactionInfo.getTransactionHash());
            authorityAgent.setBlockHeight(transactionInfo.getBlockNumber().longValue());
            authorityAgent.setInfo(info);
            authorityAgentMapper.insert(authorityAgent);
        }
    }

    public void updateIssuerToDB(AuthorityIssuer agent, boolean isIssuer, Enum type, TransactionInfo transactionInfo, String info) {
        saveLog(agent, type, transactionInfo, info);
        if (info.equals("success")) {
            if (type.equals(TypeEnum.DERECOGNIZE)) {
                authorityAgentMapper.updateValidByPrimaryKey(agent.getWeId(), false, info);
            } else {
                authorityAgentMapper.updateValidByPrimaryKey(agent.getWeId(), true, info);
            }
        }
    }

    private void saveLog(AuthorityIssuer agent, Enum type, TransactionInfo transactionInfo, String info) {
        AuthorityAgentLog authorityAgentLog = new AuthorityAgentLog();

        authorityAgentLog.setDid(agent.getWeId());
        if (null != agent.getName()) {
            authorityAgentLog.setName(agent.getName());
        }

        if (null != agent.getAccValue()) {
            authorityAgentLog.setAccValue(agent.getAccValue());
        }
        authorityAgentLog.setUpdatedAt(new Date());
        authorityAgentLog.setUpdateType(type);
        if (null == transactionInfo) {
            authorityAgentLog.setSucceed(false);
        } else {
            authorityAgentLog.setSucceed(true);
            authorityAgentLog.setTxHash(transactionInfo.getTransactionHash());
            authorityAgentLog.setBlockHeight(transactionInfo.getBlockNumber().longValue());
        }
        authorityAgentLog.setInfo(info);
        System.out.println(authorityAgentLog);
        authorityAgentLogMapper.insert(authorityAgentLog);
    }
}
