package com.timechainer.weid.common.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import java.util.Map;

/**
 * 注册CPT接口模板.
 * @author darwindu
 * @date 2020/1/2
 **/
@Data
@ToString
@ApiModel(description = "注册CPT接口模板")
public class QueryCptModel {

    @ApiModelProperty(name = "cptId", value = "cptId", required = true,
        example = "100")
    private Long cptId;
}
