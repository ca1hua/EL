package com.timechainer.weid.constant;

/**
 * 错误码表
 */
public enum ErrorCodeEnum {
    ISSUER_IS_REGISTERED(501, "This issue has been registered"),
    ISSUER_IS_NOT_REGISTERED(502, "This issue has not been registered"),
    ISSUER_IS_RECOGNIZE(511, "This issue has been recognized"),
    ISSUER_IS_NOT_RECOGNIZE(512, "This issue has not been recognized"),

    PRIVATE_KEY_NOT_MATCH(601, "Private key does not match"),

    CPT_IS_NOT_EXIST(701, "该CPT不存在"),
    CPT_IS_INVALID(702, "该CPT无效"),

    CREDENTIAL_IS_NOT_EXIST(801, "该凭证不存在"),
    CREDENTIAL_IS_EXPIRED(802, "该凭证已过期"),

    EVIDENCE_IS_NOT_EXIST(901, "该存证不存在")
    ;

    private Integer code;
    private String msg;

    public Integer getCode() {
        return this.code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return this.msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    private ErrorCodeEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }
}
