package com.timechainer.weid.common.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.fisco.bcos.web3j.abi.datatypes.Bool;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/5 3:55 PM
 * @Description //TODO $
 **/
@Data
public class GenKeyByPriModel {
    @ApiModelProperty(name = "privateKey", value = "私钥", required = true,
            example = "53079349606873082534274061523339694826923290877435862289172419522326067705985")
    private String privateKey;

    @ApiModelProperty(name = "isGM", value = "是否为国密", required = true,
            example = "false")
    private Boolean isGM;
}
