package com.timechainer.weid.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.timechainer.weid.common.model.*;
import com.timechainer.weid.constant.ApiResult;
import com.webank.weid.protocol.base.EvidenceInfo;

import java.io.IOException;

/**
 * 创建凭证存证接口.
 * @author VictorLyl
 * @date 2021/9/3
 **/
public interface WebEvidenceService {

    /**
     * 创建凭证存证
     * @param createEvidenceModel create evidence model
     * @return returns results of create
     */
    ApiResult<String> createEvidence(CreateEvidenceModel createEvidenceModel) throws IOException;

    /**
     * 查询凭证存证（存证哈希或关键字）
     * @param queryEvidenceModel query evidence model
     * @return returns signature
     */
    ApiResult<EvidenceInfo> queryEvidence(QueryEvidenceModel queryEvidenceModel) throws JsonProcessingException;

    /**
     * 验证凭证存证（存证哈希）
     * @param verifyEvidenceModel verify evidence model
     * @return returns signature
     */
    ApiResult<Boolean> verifyEvidence(VerifyEvidenceModel verifyEvidenceModel) throws JsonProcessingException;

    /**
     * 添加日志
     * @param addLogModel add log model
     * @return returns status of add log (success or error)
     */
    ApiResult<Boolean> addLog(AddLogModel addLogModel);
}
