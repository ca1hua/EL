package com.timechainer.weid.common.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author:zhangjiaheng
 * @Date: 2021/09/02/10:45 下午
 * @Description:
 */
@Data
public class CreateCptModel {

    private String publisher;

    private String privateKey;

    private Map<String, Object> claim;

    private String title;

    private String description;

    private Integer cptId;
}
