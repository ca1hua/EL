package com.timechainer.weid.common.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import javax.validation.constraints.NotNull;

/**
 * 验证凭证存证接口模板.
 * @author VictorLyl
 * @date 2021/9/4
 **/
@Data
@ToString
@ApiModel(description = "存证验签接口模板")
public class VerifyEvidenceByCustomKeyModel {
    @ApiModelProperty(name = "customKey", value = "已创建的关键字", required = true,
            example = "关键字")
    @NotNull(message = "关键字不能为空")
    private String customKey;

    @ApiModelProperty(name = "did", value = "已注册DID", required = true,
            example = "did:weid:1:0x693d4d2bec6c79229f01c020168fb093a5599738")
    @NotNull(message = "DID不能为空")
    private String did;

    @ApiModelProperty(name = "publicKey", value = "已注册DID的公钥", required = true,
            example = "3959917340005355671415331863332150507870768855339509707310033528904349941449029069391586099189346963451012412979611534650711284059550975698365844690187019")
    private String publicKey;
}
