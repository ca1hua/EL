package com.timechainer.weid.common.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * 权威机构认证接口模板.
 * @author v_wbgyang
 * @date 2020/11/23
 **/
@Data
@ToString
@ApiModel(description = "权威机构接口模板")
public class AuthorityIssuerModel {

    @ApiModelProperty(name = "did", value = "授权机构DID", required = true,
            example = "did:weid:1:0x19607cf2bc4538b49847b43688acf3befc487a41")
    private String did;

    @ApiModelProperty(name = "authorityName",
            value = "授权机构名称，机构名称必须小于32个字节，非空，且仅包含ASCII码可打印字符（ASCII值位于32~126）",
            required = true, example = "wb")
    private String authorityName;
}
