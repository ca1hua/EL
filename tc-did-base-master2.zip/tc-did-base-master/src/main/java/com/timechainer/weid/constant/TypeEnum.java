package com.timechainer.weid.constant;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/11 6:27 PM
 * @Description //TODO $
 **/
public enum TypeEnum {
    REGISTER, RECOGNIZE, DERECOGNIZE
}
