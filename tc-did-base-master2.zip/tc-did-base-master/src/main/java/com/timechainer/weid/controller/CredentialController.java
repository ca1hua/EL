package com.timechainer.weid.controller;

import com.timechainer.weid.common.model.*;
import com.timechainer.weid.constant.ApiResult;
import com.timechainer.weid.entity.WebCredential;
import com.timechainer.weid.service.WebCredentialService;
import com.webank.weid.protocol.base.CredentialPojo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * @email $1602205111@qq.com
 * @author: mayifan
 * @date: 2021/9/1
 * @time: 10:04
 */
@Slf4j
@RestController
@RequestMapping("/credential")
@Api(description = "credential",
        tags = {"credential"}, position = 0, hidden = false)
public class CredentialController {

    @Autowired
    private WebCredentialService webCredentialService;

//    @ApiOperation(value = "传入Credential信息生成Credential")
//    @PostMapping("/createCredential")
//    public ApiResult<CredentialWrapper> createCredential(
//            @ApiParam(name = "createCredentialModel", value = "电子凭证模板")
//            @RequestBody CreateCredentialModel createCredential) throws Exception {
//        return  webCredentialService.createCredential(createCredential);
//    }

    @ApiOperation(value = "发布凭证（CredentialPoJo）")
    @PostMapping("/createCredentialPojo")
    public ApiResult<CredentialPojo> createCredentialPoJo(
            @ApiParam(name = "createCredentialPoJoModel", value = "发布凭证（CredentialPoJo）模板")
            @RequestBody CreateCredentialPojoModel createCredentialPojoModel) throws IOException {
        return webCredentialService.createCredentialPojo(createCredentialPojoModel);
    }

    @ApiOperation(value = "查询CPT的claim键值对")
    @PostMapping("/queryClaim")
    public ApiResult<ArrayList<HashMap<String, Object>>> queryClaim(
            @ApiParam(name = "credentialId", value = "凭证ID")
            @RequestBody QueryClaimModel queryClaimModel) {
        return webCredentialService.queryClaim(queryClaimModel.getCptId());
    }

    @ApiOperation(value = "创建选择性披露")
    @PostMapping("/createSelectiveCredential")
    public ApiResult<CredentialPojo> createSelectiveCredential(
            @ApiParam(name = "createSelectiveCredentialModel", value = "创建选择性披露模板")
            @RequestBody CreateSelectiveCredentialModel createSelectiveCredentialModel) {
        return webCredentialService.createSelectiveCredential(createSelectiveCredentialModel);
    }

    @ApiOperation(value = "查询凭证")
    @PostMapping("/queryCredential")
    public ApiResult<WebCredential> queryByDid(
            @ApiParam(name = "DID", value = "DID")
            @RequestBody QueryCredentialModel queryCredentialModel) {
        return webCredentialService.selectById(queryCredentialModel.getCredentialId());
    }

    @ApiOperation(value = "验证凭证")
    @PostMapping("/verifyCredential")
    public ApiResult<Boolean> verifyById(
            @ApiParam(name = "verifyCredentialPoJoModel", value = "验证凭证模板")
            @RequestBody VerifyPoJoModel verifyPoJoModel) {
            return webCredentialService.verifyById(verifyPoJoModel);
    }
}