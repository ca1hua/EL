package com.timechainer.weid.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.timechainer.weid.entity.WebEvidence;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/13 5:25 PM
 * @Description //TODO $end$
 **/
@Mapper
@Repository
public interface WebEvidenceMapper extends BaseMapper<WebEvidence> {

    void updateLogByPrimaryKey(@Param("evidence_hash") String evidenceHash,
                               @Param("log")String log,
                               @Param("tx_hash")String tx_Hash,
                               @Param("block_height")Long block_height);
}