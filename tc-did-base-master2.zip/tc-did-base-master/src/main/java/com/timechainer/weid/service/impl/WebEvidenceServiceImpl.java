package com.timechainer.weid.service.impl;

import com.alibaba.fastjson.JSON;
import com.timechainer.weid.common.model.*;
import com.timechainer.weid.common.util.CommonUtils;
import com.timechainer.weid.constant.ApiResult;
import com.timechainer.weid.constant.ErrorCodeEnum;
import com.timechainer.weid.entity.WebCredential;
import com.timechainer.weid.entity.WebEvidence;
import com.timechainer.weid.mapper.WebCredentialMapper;
import com.timechainer.weid.mapper.WebEvidenceMapper;
import com.timechainer.weid.service.WebEvidenceService;
import com.webank.weid.constant.ErrorCode;
import com.webank.weid.protocol.base.*;
import com.webank.weid.protocol.response.ResponseData;
import com.webank.weid.rpc.EvidenceService;
import com.webank.weid.service.impl.EvidenceServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Objects;

/**
 * 创建凭证存证接口实现.
 * @author VictorLyl
 * @date 2021/9/3
 **/
@Slf4j
@Service
public class WebEvidenceServiceImpl implements WebEvidenceService {

    @Autowired
    private WebEvidenceMapper webEvidenceMapper;

    @Autowired
    private WebCredentialMapper webCredentialMapper;

    EvidenceService evidenceService = new EvidenceServiceImpl();


    /**
     * 创建凭证存证
     * @param createEvidenceModel create evidence model
     * @return returns results of create
     */
    @Override
    public ApiResult<String> createEvidence(CreateEvidenceModel createEvidenceModel) {

        WeIdPrivateKey weIdPrivateKey = new WeIdPrivateKey();
        weIdPrivateKey.setPrivateKey(createEvidenceModel.getPrivateKey());

        WeIdAuthentication weIdAuthentication = new WeIdAuthentication();
        weIdAuthentication.setWeIdPrivateKey(weIdPrivateKey);
        weIdAuthentication.setWeId(createEvidenceModel.getSigner());

        WebCredential credential = webCredentialMapper.selectById(createEvidenceModel.getCredentialId());
        if (null == credential) {
            return ApiResult.failed(ErrorCodeEnum.CREDENTIAL_IS_NOT_EXIST);
        } else {
            CredentialPojo credentialPojo = JSON.parseObject(credential.getCredential(), CredentialPojo.class);
            ResponseData<String> createResponse;
            if (!Objects.equals(createEvidenceModel.getCustomKey(), "")) {
                createResponse = evidenceService.createEvidenceWithLogAndCustomKey(credentialPojo, weIdPrivateKey, createEvidenceModel.getLog(), createEvidenceModel.getCustomKey());
            } else if (!Objects.equals(createEvidenceModel.getSigner(), "")) {
                createResponse = evidenceService.createEvidenceWithLog(credentialPojo, createEvidenceModel.getLog(), weIdAuthentication);
            } else {
                createResponse = evidenceService.createEvidence(credentialPojo, weIdPrivateKey);
            }

            if (createResponse.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
                return ApiResult.failed(createResponse.getErrorCode(), createResponse.getErrorMessage());
            }

            // 根据 evidenceHash 获取 evidenceInfo
            ResponseData<EvidenceInfo> evidenceInfo = evidenceService.getEvidence(createResponse.getResult());
            if (evidenceInfo.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
                return ApiResult.failed(evidenceInfo.getErrorCode(), evidenceInfo.getErrorMessage());
            }
            WebEvidence webEvidence = new WebEvidence();
            webEvidence.setEvidenceHash(evidenceInfo.getResult().getCredentialHash());
//            webEvidence.setCredentialId(CommonUtils.formatObjectToString(evidenceInfo.getResult().getCredentialHash()));
            webEvidence.setCredentialId(createEvidenceModel.getCredentialId());
            webEvidence.setCustomKey(createEvidenceModel.getCustomKey());
            webEvidence.setLog(CommonUtils.formatObjectToString(evidenceInfo.getResult().getSignInfo()));
            webEvidence.setTxHash(String.valueOf(createResponse.getTransactionInfo().getTransactionHash()));
            webEvidence.setBlockHeight(createResponse.getTransactionInfo().getBlockNumber().longValue());
            webEvidenceMapper.insert(webEvidence);
            return ApiResult.success(createResponse.getResult());
        }
    }

    /**
     * 查询凭证存证（存证哈希或关键字）
     * @param queryEvidenceModel query evidence model
     * @return returns signature
     */
    @Override
    public ApiResult<EvidenceInfo> queryEvidence(QueryEvidenceModel queryEvidenceModel) {
        ResponseData<EvidenceInfo> queryResponse;
        if (!Objects.equals(queryEvidenceModel.getCustomKey(), "")) {
            queryResponse = evidenceService.getEvidenceByCustomKey(queryEvidenceModel.getCustomKey());
        } else {
            queryResponse = evidenceService.getEvidence(queryEvidenceModel.getEvidenceHash());
        }
        if (queryResponse.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            return ApiResult.failed(queryResponse.getErrorCode(), queryResponse.getErrorMessage());
        }
        return ApiResult.success(queryResponse.getResult());
    }

    /**
     * 验证凭证存证（存证哈希）
     * @param verifyEvidenceModel verify evidence model
     * @return returns signature
     */
    @Override
    public ApiResult<Boolean> verifyEvidence(VerifyEvidenceModel verifyEvidenceModel) {
        WebEvidence webEvidence = webEvidenceMapper.selectById(verifyEvidenceModel.getEvidenceHash());

        if (null == webEvidence) {
            return ApiResult.success(false);
        } else {
            WebCredential webCredential = webCredentialMapper.selectById(webEvidence.getCredentialId());
            CredentialPojo credentialPojo = JSON.parseObject(webCredential.getCredential(), CredentialPojo.class);

            ResponseData<EvidenceInfo> evidenceInfo = evidenceService.getEvidence(verifyEvidenceModel.getEvidenceHash());
//            WebEvidence evidenceInfo = webEvidenceMapper.selectById(verifyEvidenceModel.getEvidenceHash());
            if (ErrorCode.SUCCESS.getCode() != evidenceInfo.getErrorCode()) {
                return ApiResult.success(false);
            }

            ResponseData<Boolean> verifyResult;
            // 验证某签名者的签名是否有效
            if (!Objects.equals(verifyEvidenceModel.getPublicKey(), "")) {
                verifyResult = evidenceService.verifySigner(credentialPojo, evidenceInfo.getResult(), verifyEvidenceModel.getDid(), verifyEvidenceModel.getPublicKey());
            } else {
                verifyResult = evidenceService.verifySigner(credentialPojo, evidenceInfo.getResult(), verifyEvidenceModel.getDid());
            }
            if (verifyResult.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
                return ApiResult.success(false);
            }
            return ApiResult.success(verifyResult.getResult());
        }
    }

    /**
     * 添加日志
     * @param addLogModel add log model
     * @return returns status of add log (success or error)
     */
    @Override
    public ApiResult<Boolean> addLog(AddLogModel addLogModel) {
        ResponseData<EvidenceInfo> queryResponse;
        if (!Objects.equals(addLogModel.getCustomKey(), "")) {
            queryResponse = evidenceService.getEvidenceByCustomKey(addLogModel.getCustomKey());
        } else {
            queryResponse = evidenceService.getEvidence(addLogModel.getEvidenceHash());
        }
        if (ErrorCode.SUCCESS.getCode() != queryResponse.getErrorCode()) {
            return ApiResult.failed(queryResponse.getErrorCode(), queryResponse.getErrorMessage());
        }

        WeIdPrivateKey weIdPrivateKey = new WeIdPrivateKey();
        weIdPrivateKey.setPrivateKey(addLogModel.getPrivateKey());
        ResponseData<Boolean> responseData;
        if (!Objects.equals(addLogModel.getCustomKey(), "")) {
            responseData = evidenceService.addSignatureAndLogByCustomKey(addLogModel.getEvidenceHash(),
                    addLogModel.getCustomKey(), addLogModel.getLog(), weIdPrivateKey);
        } else {
            responseData = evidenceService.addSignatureAndLogByHash(addLogModel.getEvidenceHash(),
                    addLogModel.getLog(), weIdPrivateKey);
        }
        if (responseData.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            return ApiResult.failed(responseData.getErrorCode(), responseData.getErrorMessage());
        }
        Map<String, EvidenceSignInfo> info = queryResponse.getResult().getSignInfo();
        webEvidenceMapper.updateLogByPrimaryKey(queryResponse.getResult().getCredentialHash(), CommonUtils.formatObjectToString(info),
                responseData.getTransactionInfo().getTransactionHash(), responseData.getTransactionInfo().getBlockNumber().longValue());
        return ApiResult.success(responseData.getResult());
    }
}