package com.timechainer.weid.common.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import javax.validation.constraints.NotNull;

/**
 * 验证凭证存证接口模板.
 * @author VictorLyl
 * @date 2021/9/4
 **/
@Data
@ToString
@ApiModel(description = "存证验签接口模板")
public class VerifyEvidenceModel {

//    @ApiModelProperty(name = "credentialId", value = "已创建的凭证ID号", required = true,
//            example = "a70d9127-8132-4041-a12d-32545755076a")
//    @NotNull(message = "凭证ID不能为空")
//    private String credentialId;

    @ApiModelProperty(name = "evidenceHash", value = "凭证哈希", required = true,
            example = "did0x8df99e52e9fa1ba57f2aa10b9bd31490a878c27f755006019702cb9bfb38e470")
    private String evidenceHash;

    @ApiModelProperty(name = "customKey", value = "关键字", required = true,
            example = "test")
    private String customKey;

    @ApiModelProperty(name = "did", value = "已注册DID", required = true,
            example = "did:weid:1:0x693d4d2bec6c79229f01c020168fb093a5599738")
    @NotNull(message = "DID不能为空")
    private String did;

    @ApiModelProperty(name = "publicKey", value = "did公钥", required = true,
            example = "did:weid:1:0x693d4d2bec6c79229f01c020168fb093a5599738")
    private String publicKey;

//    @ApiModelProperty(name = "privateKey", value = "已注册DID的私钥", required = true,
//            example = "3959917340005355671415331863332150507870768855339509707310033528904349941449029069391586099189346963451012412979611534650711284059550975698365844690187019")
//    private String privateKey;
}
