package com.timechainer.weid.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/13 5:25 PM
 * @Description //TODO $end$
 **/
@ApiModel(value = "com-timechainer-weid-entity-WebEvidence")
@Data
@TableName(value = "BCIM.web_evidence")
public class WebEvidence {
    public static final String COL_EVIDENCEHASH = "evidenceHash";
    public static final String COL_SIGNINFO = "signInfo";
    public static final String COL_TRANSACTIONHASH = "transactionHash";
    public static final String COL_BLOCKNUMBER = "blockNumber";
    public static final String COL_CUSTOMKEY = "customKey";
    public static final String COL_SIGN_HNFO = "sign_hnfo";
    public static final String COL_CUSTOM_KEY = "custom_key";
    public static final String COL_BLOCK_NUMBER = "block_number";
    public static final String COL_TRANSACTION_HASH = "transaction_hash";
    public static final String COL_SIGN_INFO = "sign_info";
    @TableId(value = "evidence_hash", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private String evidenceHash;

    @TableField(value = "credential_id")
    @ApiModelProperty(value = "")
    @Nullable
    private String credentialId;

    @TableField(value = "customKey")
    @ApiModelProperty(value = "")
    private String customKey;

    @TableField(value = "log")
    @ApiModelProperty(value = "")
    private String log;

    @TableField(value = "tx_hash")
    @ApiModelProperty(value = "")
    private String txHash;

    @TableField(value = "block_height")
    @ApiModelProperty(value = "")
    private Long blockHeight;

    public static final String COL_EVIDENCE_HASH = "evidence_hash";

    public static final String COL_CREDENTIAL_ID = "credential_id";

    public static final String COL_LOG = "log";

    public static final String COL_TX_HASH = "tx_hash";

    public static final String COL_BLOCK_HEIGHT = "block_height";
}