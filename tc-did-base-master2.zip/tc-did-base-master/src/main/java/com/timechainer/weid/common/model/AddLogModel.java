package com.timechainer.weid.common.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import javax.validation.constraints.NotNull;

/**
 * 添加日志模板.
 * @author VictorLyl
 * @date 2021/9/4
 **/
@Data
@ToString
@ApiModel(description = "添加日志模板")
public class AddLogModel {

    @ApiModelProperty(name = "weid", value = "已注册DID", required = true,
            example = "weid:1:34tgfdsertrhg")
    @NotNull(message = "log添加者不能为空")
    private String did;

    @ApiModelProperty(name = "privateKey", value = "已注册DID的私钥", required = true,
            example = "74041054744801473947392169786116757693945589485498694327198269872450350882718")
    @NotNull(message = "私钥不能为空")
    private String privateKey;

    @ApiModelProperty(name = "evidenceHash", value = "evidence哈希值", required = true,
            example = "0x8a133aee5725e148696f369393bdc3a143fead3df685a2f4f5ce14a351e20a73")
    private String evidenceHash;

    @ApiModelProperty(name = "customKey", value = "customKey", required = true,
            example = "3fda")
    private String customKey;

    @ApiModelProperty(name = "log", value = "用户自设日志", required = true,
            example = "abc abc")
    @NotNull(message = "log不能为空")
    private String log;
}
