package com.timechainer.weid.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.Date;
import lombok.Data;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/13 5:25 PM
 * @Description //TODO $end$
 **/
@ApiModel(value = "com-timechainer-weid-entity-AuthorityAgent")
@Data
@TableName(value = "BCIM.authority_agent")
public class AuthorityAgent {
    @TableId(value = "did", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private String did;

    @TableField(value = "`name`")
    @ApiModelProperty(value = "")
    private String name;

    @TableField(value = "acc_value")
    @ApiModelProperty(value = "")
    private String accValue;

    @TableField(value = "created_at")
    @ApiModelProperty(value = "")
    private Date createdAt;

    @TableField(value = "`type`")
    @ApiModelProperty(value = "")
    private String type;

    @TableField(value = "is_issuer")
    @ApiModelProperty(value = "")
    private Boolean isIssuer;

    @TableField(value = "is_valid")
    @ApiModelProperty(value = "")
    private Boolean isValid;

    @TableField(value = "tx_hash")
    @ApiModelProperty(value = "")
    private String txHash;

    @TableField(value = "block_height")
    @ApiModelProperty(value = "")
    private Long blockHeight;

    @TableField(value = "info")
    @ApiModelProperty(value = "")
    private String info;

    public static final String COL_DID = "did";

    public static final String COL_NAME = "name";

    public static final String COL_ACC_VALUE = "acc_value";

    public static final String COL_CREATED_AT = "created_at";

    public static final String COL_TYPE = "type";

    public static final String COL_IS_ISSUER = "is_issuer";

    public static final String COL_IS_VALID = "is_valid";

    public static final String COL_TX_HASH = "tx_hash";

    public static final String COL_BLOCK_HEIGHT = "block_height";

    public static final String COL_INFO = "info";
}