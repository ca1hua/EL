package com.timechainer.weid.common.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.timechainer.weid.entity.WebCredential;
import com.webank.weid.protocol.base.CredentialPojo;
import com.webank.weid.util.DataToolUtils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/8/26 12:14 PM
 * @Description //TODO Common Util$
 **/
public class CommonUtils {
    /**
     * format Object to String.
     *
     * @return return JSON string
     */
    public static String formatObjectToString(Object obj) {
        return DataToolUtils.serialize(obj);
    }

}
