package com.timechainer.weid.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/13 8:52 PM
 * @Description //TODO $end$
 **/
@ApiModel(value = "com-timechainer-weid-entity-WebCredential")
@Data
@TableName(value = "BCIM.web_credential")
public class WebCredential {
    public static final String COL_ISVALID = "isValid";
    public static final String COL_CREDENTIALHASH = "credentialHash";
    public static final String COL_EXPIRATIONDATE = "expirationDate";
    public static final String COL_ISSUANCEDATE = "issuanceDate";
    public static final String COL_CPTID = "cptid";
    public static final String COL_CONTEXT = "context";
    public static final String COL_ISSUANCE_DATE = "issuance_date";
    public static final String COL_EXPIRATION_DATE = "expiration_date";
    public static final String COL_CLAIM = "claim";
    public static final String COL_PROOF = "proof";
    public static final String COL_TYPE = "type";
    public static final String COL_CREDENTIAL_HASH = "credential_hash";
    public static final String COL_SALT = "salt";

    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private String id;

    @TableField(value = "issuer")
    @ApiModelProperty(value = "")
    private String issuer;

    @TableField(value = "cpt_id")
    @ApiModelProperty(value = "")
    private Integer cptId;

    @TableField(value = "credential")
    @ApiModelProperty(value = "")
    private String credential;

    @TableField(value = "is_valid")
    @ApiModelProperty(value = "")
    private Boolean isValid;

    public static final String COL_ID = "id";

    public static final String COL_ISSUER = "issuer";

    public static final String COL_CPT_ID = "cpt_id";

    public static final String COL_CREDENTIAL = "credential";

    public static final String COL_IS_VALID = "is_valid";
}