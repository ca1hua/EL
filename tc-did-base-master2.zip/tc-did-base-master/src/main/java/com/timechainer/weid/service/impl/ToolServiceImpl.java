package com.timechainer.weid.service.impl;

import com.timechainer.weid.common.model.KeysModel;
import com.timechainer.weid.constant.ApiResult;
import com.timechainer.weid.service.ToolService;
import lombok.extern.slf4j.Slf4j;
import org.fisco.bcos.web3j.crypto.ECKeyPair;
import org.fisco.bcos.web3j.crypto.EncryptType;
import org.fisco.bcos.web3j.crypto.gm.GenCredential;
import org.springframework.stereotype.Service;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/8/31 2:58 PM
 * @Description //TODO now$
 **/
@Slf4j
@Service
public class ToolServiceImpl implements ToolService {

    @Override
    public ApiResult<KeysModel> getPublicKey(Boolean isGM, String privateKey) {
        if (isGM) {
            EncryptType.encryptType = 1;
        } else {
            // ECDSA
            EncryptType.encryptType = 0;
        }
        ECKeyPair keyPair = GenCredential.createKeyPair(privateKey);
        log.info("create public key:{} by private key:{}", keyPair.getPublicKey(), keyPair.getPrivateKey());

        KeysModel keysModel = new KeysModel();
        keysModel.setPrivateKey(String.valueOf(keyPair.getPrivateKey()));
        keysModel.setPublicKey(String.valueOf(keyPair.getPublicKey()));
        return ApiResult.success(keysModel);
    }

    @Override
    public ApiResult<KeysModel> genKeys(Boolean isGM) {
       if (isGM) {
           EncryptType.encryptType = 1;
       } else {
           // ECDSA
           EncryptType.encryptType = 0;
       }
       ECKeyPair keyPair = GenCredential.createKeyPair();
       log.info("create public key:{} by private key:{}", keyPair.getPublicKey(), keyPair.getPrivateKey());

        KeysModel keysModel = new KeysModel();
       keysModel.setPrivateKey(String.valueOf(keyPair.getPrivateKey()));
       keysModel.setPublicKey(String.valueOf(keyPair.getPublicKey()));
       return ApiResult.success(keysModel);
    }
}

