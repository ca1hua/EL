package com.timechainer.weid.controller;

import com.timechainer.weid.common.model.GenKeyByPriModel;
import com.timechainer.weid.common.model.GenKeysModel;
import com.timechainer.weid.common.model.KeysModel;
import com.timechainer.weid.constant.ApiResult;
import com.timechainer.weid.mapper.WeidMapper;
import com.timechainer.weid.service.ToolService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * 小工具.
 * @author darwindu
 * @date 2020/1/8
 **/
@RestController
@RequestMapping("/tools")
@Api(description = "小工具",
        tags = {"小工具"})
public class ToolController {

    private ToolService toolService;

    @Autowired
    public void setInjectedBean(ToolService toolService) {
        this.toolService = toolService;
    }

    @ApiOperation(value = "通过私钥生成公钥")
    @PostMapping("/getPublicKey")
    public ApiResult<KeysModel> getPublicKey (
            @Valid @RequestBody GenKeyByPriModel genKeyByPriModel) {
        return toolService.getPublicKey(genKeyByPriModel.getIsGM(), genKeyByPriModel.getPrivateKey());
    }

    @ApiModelProperty(value = "自动生成公私钥")
    @PostMapping("/genKeys")
    @ResponseBody
    public ApiResult<KeysModel> create(
            @Valid @RequestBody GenKeysModel genKeysModel){
        return toolService.genKeys(genKeysModel.getIsGM());
    }
}