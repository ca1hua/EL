package com.timechainer.weid.constant;

import com.webank.weid.constant.ErrorCode;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;

@Data
@Slf4j
public class ApiResult<T> implements Serializable {
    private Integer code;
    private String msg;
    private T data;

    public ApiResult(Integer code, String msg, T data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }

    public static <T> ApiResult<T> success(T data){
        ApiResult apiResult = new ApiResult<>(200, "Success", data);
        log.info("==========>> Api exec result:" + apiResult.toString() );
        return apiResult;
    }

    public static ApiResult success(){
        return new ApiResult(200, "Success", null);
    }

    public static <T> ApiResult<T> failed(Integer errorCode, String msg){
        ApiResult apiResult = new ApiResult<>(errorCode, msg, null);
        log.info("==========>> Api exec result:" + apiResult.toString() );
        return apiResult;
    }

    public static <T> ApiResult<T> failed(ErrorCodeEnum errorCode){
        return failed(errorCode.getCode(), errorCode.getMsg());
    }

    public static <T> ApiResult<T> failed(ErrorCode errorCode){
        return failed(errorCode.getCode(), errorCode.getCodeDesc());
    }

    public static <T> ApiResult<T> failed(Integer errorCode, ErrorCodeEnum errorCodeEnum){
        return failed(errorCode, errorCodeEnum.getMsg());
    }
}
