package com.timechainer.weid.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.timechainer.weid.entity.Cpt;
import com.timechainer.weid.common.model.CreateCptModel;
import com.timechainer.weid.common.util.CommonUtils;
import com.timechainer.weid.constant.ApiResult;
import com.timechainer.weid.mapper.CptMapper;
import com.timechainer.weid.service.WebCptService;
import com.timechainer.weid.service.WebWeidService;
import com.webank.weid.constant.ErrorCode;
import com.webank.weid.protocol.base.CptBaseInfo;
import com.webank.weid.protocol.response.ResponseData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;


/**
 * Created with IntelliJ IDEA.
 *
 * @Author:zhangjiaheng
 * @Date: 2021/09/03/7:13 上午
 * @Description:
 */
@Slf4j
@Service
public class WebCptServiceImpl implements WebCptService {


    @Autowired
    private CptMapper cptMapper;

    @Autowired
    private WebWeidService weidService;

    /**
     * 存储生成的证书信息
     *
     * @param
     * @return
     */
    @Override
    public ApiResult<com.timechainer.weid.entity.Cpt> create(CreateCptModel createCptModel) throws JsonProcessingException {

        ResponseData<CptBaseInfo> response = weidService.registCpt(createCptModel.getPublisher(),
                createCptModel.getPrivateKey(),
                createCptModel.getClaim(),
                createCptModel.getCptId());
        if (response.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
            log.info(
                    "registerAuthorityIssuer is result,errorCode:{},errorMessage:{}",
                    response.getErrorCode(),
                    response.getErrorMessage()
            );
            return ApiResult.failed(response.getErrorCode(), response.getErrorMessage());
        }
        response.getResult().getCptId();
        response.getResult().getCptVersion();
        Cpt cpt = new Cpt();

        cpt.setCptId(response.getResult().getCptId());
        cpt.setCptVersion(response.getResult().getCptVersion());
        cpt.setPublisher(createCptModel.getPublisher());
        cpt.setCreatedAt(new Date());
        cpt.setClaim(CommonUtils.formatObjectToString(createCptModel.getClaim()));
        cpt.setTitle(createCptModel.getTitle());
        cpt.setDes(createCptModel.getDescription());
        cpt.setTxHash(response.getTransactionInfo().getTransactionHash());
        cpt.setBlockHeight(response.getTransactionInfo().getBlockNumber().longValue());

        cptMapper.insert(cpt);
        return ApiResult.success(cpt);
    }


    @Override
    public ApiResult<Cpt> selectById(long cptId) {
        Cpt cpt = cptMapper.selectById(cptId);
        if (null == cpt) {
            ResponseData<com.webank.weid.protocol.base.Cpt> cptResponseData = weidService.queryCpt((int) cptId);
            if (cptResponseData.getErrorCode() != ErrorCode.SUCCESS.getCode()) {
                log.info(
                        "queryCpt is result,errorCode:{},errorMessage:{}",
                        cptResponseData.getErrorCode(),
                        cptResponseData.getErrorMessage()
                );
                return ApiResult.failed(cptResponseData.getErrorCode(),
                        cptResponseData.getErrorMessage());
            } else {
                cpt.setCptId(cptResponseData.getResult().getCptId());
                cpt.setCptVersion(cptResponseData.getResult().getCptVersion());
                cpt.setPublisher(cptResponseData.getResult().getCptPublisher());
                cpt.setCreatedAt(new Date(cptResponseData.getResult().getCreated()));
                cpt.setClaim(CommonUtils.formatObjectToString(cptResponseData.getResult().getCptJsonSchema()));

                // 新查询出来的没有交易信息
                //                cpt.setTxId("");
                //                cpt.setBlockHeight(0L);
                cptMapper.insert(cpt);
                log.info("can't find this cptId in database, but find it in chain:{}",cpt);
                return ApiResult.success(cpt);
            }
        } else {
            return ApiResult.success(cpt);
        }
    }

}