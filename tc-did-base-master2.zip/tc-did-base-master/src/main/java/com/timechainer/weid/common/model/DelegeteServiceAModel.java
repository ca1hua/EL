package com.timechainer.weid.common.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;


@Data
@ToString
@ApiModel(description = "代理模板")
public class DelegeteServiceAModel {

    @ApiModelProperty(name = "did", value = "代理人DID", required = true,
            example = "did:weid:1:0x19607cf2bc4538b49847b43688acf3befc487a41")
    private String did;

    @ApiModelProperty(name = "privateKey", value = "代理人私钥", required = true,
            example = "53079349606873082534274061523339694826923290877435862289172419522326067705985")
    private String privateKey;

    @ApiModelProperty(name = "publicKeyId", value = "代理人公钥ID", required = true,
            example = "did:weid:1:0x19607cf2bc4538b49847b43688acf3befc487a41#key0")
    private String publicKeyId;

    @ApiModelProperty(name = "publicKey", value = "代理人公钥", required = true,
            example = "10884791889573885961573595923034451846181288826676102791986473114109409913876511177868710733244026350522372286607643048335587344589818301443523106616678574")
    private String publicKey;

    @ApiModelProperty(name = " ownerDid", value = "用户DID", required = true,
            example = "did:weid:1:0x19607cf2bc4538b49847b43688acf3befc487a41")
    private String ownerDid;

    @ApiModelProperty(name = "ownerPublicKey", value = "用户公钥", required = true,
            example = "10884791889573885961573595923034451846181288826676102791986473114109409913876511177868710733244026350522372286607643048335587344589818301443523106616678574")
    private String ownerPublicKey;

    @ApiModelProperty(name = "ownerPrivateKey", value = "用户私钥", required = true,
            example = "10884791889573885961573595923034451846181288826676102791986473114109409913876511177868710733244026350522372286607643048335587344589818301443523106616678574")
    private String ownerPrivateKey;

    @ApiModelProperty(name = "serviceEndpoint", value = "服务端点", required = true,
            example = "https://timechainer.com/endpoint/8377464")
    private String serviceEndpoint;

    @ApiModelProperty(name = "serviceType", value = "服务类型", required = true,
            example = "drivingCardService")
    private String serviceType;
}