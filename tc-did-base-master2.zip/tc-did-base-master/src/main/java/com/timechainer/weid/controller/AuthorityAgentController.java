package com.timechainer.weid.controller;

import com.timechainer.weid.common.model.AuthorityIssuerModel;
import com.timechainer.weid.common.util.DbUtils;
import com.timechainer.weid.constant.ApiResult;
import com.timechainer.weid.constant.TypeEnum;
import com.timechainer.weid.entity.AuthorityAgent;
import com.timechainer.weid.mapper.AuthorityAgentMapper;
import com.timechainer.weid.service.AuthorityAgentService;
import com.webank.weid.constant.ErrorCode;
import com.webank.weid.protocol.base.AuthorityIssuer;
import com.webank.weid.protocol.response.ResponseData;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/2 10:56 AM
 * @Description //TODO $
 **/
@RestController
@RequestMapping("/authorityIssuer")
@Api(description = "授权机构",
        tags = {"授权机构"})
public class AuthorityAgentController {

    @Autowired
    private AuthorityAgentMapper authorityAgentMapper;

    @Autowired
    private DbUtils dbUtils;

    @Autowired
    private AuthorityAgentService authorityAgentService;

    @Autowired
    public void setInjectedBean(AuthorityAgentService authorityAgentService) {
        this.authorityAgentService = authorityAgentService;
    }


    @ApiOperation(value = "注册权威机构")
    @PostMapping("/register")
    public ApiResult<Boolean> register (
            @Valid @RequestBody AuthorityIssuerModel registerAuthorityIssuerModel) {
        ResponseData<Boolean> result = authorityAgentService.registerAuthorityIssuer(registerAuthorityIssuerModel);
        ApiResult<AuthorityIssuer> agent = authorityAgentService.queryAuthorityIssuer(registerAuthorityIssuerModel.getDid());
        AuthorityIssuer authorityIssuer = new AuthorityIssuer();
        authorityIssuer.setWeId(registerAuthorityIssuerModel.getDid());
        if (null == agent.getData()) {
            agent.setData(authorityIssuer);
        }
        dbUtils.saveIssuerToDB(agent.getData(), true, TypeEnum.REGISTER, result.getTransactionInfo(), result.getErrorMessage());
        if (ErrorCode.SUCCESS.getCode() != result.getErrorCode()) {
            return ApiResult.failed(result.getErrorCode(), result.getErrorMessage());
        } else {
            return ApiResult.success(result.getResult());
        }
    }

    @ApiOperation(value = "提名权威机构")
    @PostMapping("/recognize")
    public ApiResult<Boolean> recognize(
            @Valid @RequestBody AuthorityIssuerModel recognizeAuthorityIssuerModel) {
        AuthorityIssuer authorityIssuer = new AuthorityIssuer();

        authorityIssuer.setWeId(recognizeAuthorityIssuerModel.getDid());
        ResponseData<Boolean> result = authorityAgentService.recognizeAuthorityIssuer(recognizeAuthorityIssuerModel.getDid());
        AuthorityAgent issuer = authorityAgentMapper.selectById(recognizeAuthorityIssuerModel.getDid());
        if (null != issuer) {
            dbUtils.updateIssuerToDB(authorityIssuer, true, TypeEnum.RECOGNIZE, result.getTransactionInfo(), "");
        } else {
            dbUtils.saveIssuerToDB(authorityIssuer, true, TypeEnum.REGISTER, result.getTransactionInfo(), result.getErrorMessage());
        }
        if (ErrorCode.SUCCESS.getCode() != result.getErrorCode()) {
            return ApiResult.failed(result.getErrorCode(), result.getErrorMessage());
        } else {
            return ApiResult.success(result.getResult());
        }
    }

    @ApiOperation(value = "撤销权威机构")
    @PostMapping("/derecognize")
    public ApiResult<Boolean> derecognize(
            @Valid @RequestBody AuthorityIssuerModel deRecognizeAuthorityIssuerModel) {
        AuthorityIssuer authorityIssuer = new AuthorityIssuer();
        authorityIssuer.setWeId(deRecognizeAuthorityIssuerModel.getDid());
        ResponseData<Boolean> derecognizeResult = authorityAgentService.deRecognizeAuthorityIssuer(deRecognizeAuthorityIssuerModel.getDid());
        dbUtils.updateIssuerToDB(authorityIssuer, true, TypeEnum.DERECOGNIZE, null, derecognizeResult.getErrorMessage());
        if (ErrorCode.SUCCESS.getCode() != derecognizeResult.getErrorCode()) {
            return ApiResult.failed(derecognizeResult.getErrorCode(), derecognizeResult.getErrorMessage());
        } else {
            return ApiResult.success(derecognizeResult.getResult());
        }
    }

    @ApiOperation(value = "查询权威机构")
    @PostMapping("/query")
    public ApiResult<AuthorityIssuer> query(
            @Valid @RequestBody AuthorityIssuerModel recognizeAuthorityIssuerModel) {
        return authorityAgentService.queryAuthorityIssuer(recognizeAuthorityIssuerModel.getDid());
    }

    @ApiOperation(value = "判断是否为权威机构")
    @PostMapping("/is")
    public ApiResult<Boolean> is(
            @Valid @RequestBody AuthorityIssuerModel isAuthorityIssuerModel) {
        return authorityAgentService.isAuthorityIssuer(isAuthorityIssuerModel.getDid());
    }
}