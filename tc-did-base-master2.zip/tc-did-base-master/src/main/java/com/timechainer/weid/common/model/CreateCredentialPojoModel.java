package com.timechainer.weid.common.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import java.util.Date;
import java.util.Map;

/**
 * 创建电子凭证接口模板.
 * @author darwindu
 * @date 2020/1/6
 **/
@Data
@ToString
@ApiModel(description = "创建电子凭证接口模板")
public class CreateCredentialPojoModel {

    @ApiModelProperty(name = "cptId", value = "CPT编号", required = true,
        example = "1001")
    private Integer cptId;

    @ApiModelProperty(name = "issuer", value = "发行方WeIdentity DID", required = true,
        example = "did:weid:1:0x19607cf2bc4538b49847b43688acf3befc487a41")
    private String issuer;

    @ApiModelProperty(name = "privateKey", value = "私钥", required = true,
            example = "19607cf2bc4538b49847b43688acf3befc487a41")
    private String privateKey;

    @ApiModelProperty(name = "publicKeyId", value = "publicKeyId", required = true,
        example = "did:weid:1:0x22df4ddb67712b9ed25875409181e3faf8121e89#keys-0")
    private String publicKeyId;

    @ApiModelProperty(name = "claimData", value = "claim数据", required = true,
        example = "{\n"
            + "    \n"
            + "    \"age\": 32,\n"
            + "    \"name\": \"zhang san\",\n"
            + "    \"gender\": \"F\"\n"
            + "}")
    private Map<String, Object> claimData;

    @ApiModelProperty(name = "expireDate", value = "过期时间", required = true,
            example = "23456789")
    private Date expireDate;
}
