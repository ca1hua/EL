package com.timechainer.weid.service;

import com.timechainer.weid.common.model.CreateCredentialPojoModel;
import com.timechainer.weid.common.model.CreateSelectiveCredentialModel;
import com.timechainer.weid.common.model.VerifyPoJoModel;
import com.timechainer.weid.constant.ApiResult;
import com.timechainer.weid.entity.WebCredential;
import com.webank.weid.protocol.base.CredentialPojo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * @email $1602205111@qq.com
 * @author: mayifan
 * @date: 2021/9/2
 * @time: 10:04
 */

public interface WebCredentialService {

     ApiResult<WebCredential> selectById(String id);

     ApiResult<Boolean> verifyById(VerifyPoJoModel verifyPoJoModel);

     ApiResult<CredentialPojo> createSelectiveCredential(CreateSelectiveCredentialModel createSelectiveCredentialModel);

     ApiResult<CredentialPojo> createCredentialPojo(CreateCredentialPojoModel createCredentialPojoModel) throws IOException;

    ApiResult<ArrayList<HashMap<String, Object>>> queryClaim(String credentialId);
}
