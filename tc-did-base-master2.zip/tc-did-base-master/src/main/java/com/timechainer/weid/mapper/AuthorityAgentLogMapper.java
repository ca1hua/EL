package com.timechainer.weid.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.timechainer.weid.entity.AuthorityAgentLog;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/13 5:25 PM
 * @Description //TODO $end$
 **/
@Mapper
@Repository
public interface AuthorityAgentLogMapper extends BaseMapper<AuthorityAgentLog> {
    //    int deleteByPrimaryKey(Integer id);
//
//    int insert(AuthorityAgentLog record);
//
//    int updateByPrimaryKey(AuthorityAgentLog record);
//
//    AuthorityAgentLog selectByPrimaryKey(Integer id);
//
//    int insertSelective(AuthorityAgentLog record);
//
    int insertNew(AuthorityAgentLog record);
}