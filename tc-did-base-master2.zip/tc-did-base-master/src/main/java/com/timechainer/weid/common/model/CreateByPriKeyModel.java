package com.timechainer.weid.common.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

/**
 * 增加签名接口模板.
 * @author darwindu
 * @date 2020/1/6
 **/
@Data
@ToString
@ApiModel(description = "私钥创建DID接口")
public class CreateByPriKeyModel {

    @ApiModelProperty(name = "privateKey", value = "私钥", required = true,
        example = "53079349606873082534274061523339694826923290877435862289172419522326067705985")
    private String privateKey;
}
