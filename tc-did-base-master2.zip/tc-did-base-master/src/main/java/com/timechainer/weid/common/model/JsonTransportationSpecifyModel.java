package com.timechainer.weid.common.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import java.util.List;

/**
 * 指定transportation的认证者接口模板.
 * @author darwindu
 * @date 2020/1/6
 **/
@Data
@ToString
@ApiModel(description = "指定transportation的认证者接口模板。")
public class JsonTransportationSpecifyModel {

    @ApiModelProperty(name = "verifierWeIdList", value = "verifierWeId列表", required = true,
        example = "[\"did:weid:1:0x19607cf2bc4538b49847b43688acf3befc487a41\"]")
    List<String> verifierWeIdList;
}
