package com.timechainer.weid.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.Date;
import lombok.Data;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/13 5:25 PM
 * @Description //TODO $end$
 **/
@ApiModel(value = "com-timechainer-weid-entity-Weid")
@Data
@TableName(value = "BCIM.weid")
public class Weid {
    @TableId(value = "did", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private String did;

    @TableField(value = "public_key")
    @ApiModelProperty(value = "")
    private String publicKey;

    @TableField(value = "private_key")
    @ApiModelProperty(value = "")
    private String privateKey;

    @TableField(value = "create_at")
    @ApiModelProperty(value = "")
    private Date createAt;

    @TableField(value = "tx_hash")
    @ApiModelProperty(value = "")
    private String txHash;

    @TableField(value = "block_height")
    @ApiModelProperty(value = "")
    private Long blockHeight;

    @TableField(value = "did_doc")
    @ApiModelProperty(value = "")
    private String didDoc;

    public static final String COL_DID = "did";

    public static final String COL_PUBLIC_KEY = "public_key";

    public static final String COL_PRIVATE_KEY = "private_key";

    public static final String COL_CREATE_AT = "create_at";

    public static final String COL_TX_HASH = "tx_hash";

    public static final String COL_BLOCK_HEIGHT = "block_height";

    public static final String COL_DID_DOC = "did_doc";
}