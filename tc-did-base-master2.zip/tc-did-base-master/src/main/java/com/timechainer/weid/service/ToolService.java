package com.timechainer.weid.service;

import com.timechainer.weid.common.model.KeysModel;
import com.timechainer.weid.constant.ApiResult;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/8/31 2:58 PM
 * @Description //TODO now$
 **/
public interface ToolService {

    ApiResult<KeysModel> getPublicKey(Boolean isGM, String privateKey);

    ApiResult<KeysModel> genKeys(Boolean isGM);
}
