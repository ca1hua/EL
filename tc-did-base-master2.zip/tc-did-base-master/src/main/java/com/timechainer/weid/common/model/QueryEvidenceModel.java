package com.timechainer.weid.common.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import javax.validation.constraints.NotNull;

/**
 * 查询凭证存证接口（凭证ID）模板.
 * @author VictorLyl
 * @date 2021/9/4
 **/
@Data
@ToString
@ApiModel(description = "查询凭证存证接口（凭证ID）模板")
public class QueryEvidenceModel {

    @ApiModelProperty(name = "evidenceHash", value = "evidenceHash", required = true,
            example = "0x8df99e52e9fa1ba57f2aa10b9bd31490a878c27f755006019702cb9bfb38e470")
    private String evidenceHash;

    @ApiModelProperty(name = "customKey", value = "已创建的凭证关键字", required = true,
            example = "abc")
    private String customKey;
}
