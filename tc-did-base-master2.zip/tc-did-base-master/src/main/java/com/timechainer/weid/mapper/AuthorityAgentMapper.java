package com.timechainer.weid.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.timechainer.weid.entity.AuthorityAgent;
import org.apache.ibatis.annotations.Mapper;import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * @Author renhuikang
 * @Email hkren@timechainer.com
 * @Date 2021/9/13 5:25 PM
 * @Description //TODO $end$
 **/
@Mapper
@Repository
public interface AuthorityAgentMapper extends BaseMapper<AuthorityAgent> {
    int unsetValidByPrimaryKey(AuthorityAgent record);

    int updateValidByPrimaryKey(@Param("did") String weid, @Param("is_valid") Boolean isValid,
                                @Param("info") String info);
}