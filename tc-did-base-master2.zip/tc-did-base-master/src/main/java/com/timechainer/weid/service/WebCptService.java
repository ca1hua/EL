package com.timechainer.weid.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.timechainer.weid.common.model.CreateCptModel;
import com.timechainer.weid.constant.ApiResult;
import com.timechainer.weid.entity.Cpt;

import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author:zhangjiaheng
 * @Date: 2021/09/03/7:15 上午
 * @Description:
 */
public interface WebCptService {

    ApiResult<com.timechainer.weid.entity.Cpt> create(CreateCptModel createCptModel) throws IOException;

    ApiResult<Cpt> selectById(long cptId) throws JsonProcessingException;
}
