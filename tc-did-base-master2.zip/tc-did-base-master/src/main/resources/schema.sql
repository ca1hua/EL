create table IF NOT EXISTS weid(
    `did` varchar(60) NOT NULL,
    `public_key` varchar(255) DEFAULT NULL,
    `private_key` varchar(255) DEFAULT NULL,
    `create_at` date NOT NULL,
    `tx_hash` char(66) NOT NULL,
    `block_height` bigint DEFAULT NULL,
    `did_doc` text NULL,
    PRIMARY KEY (`did`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

create table IF NOT EXISTS authority_agent_log
(
    id int not null AUTO_INCREMENT,
    did VARCHAR(60) null,
    name varchar(100) null,
    acc_value VARCHAR(10) null,
    update_type enum('REGISTER','RECOGNIZE','DERECOGNIZE') null,
    updated_at date null,
    tx_hash char(66) null,
    block_height BIGINT null,
    succeed BOOL not null,
    info varchar(255) null,
    primary key (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

create table IF NOT EXISTS authority_agent
(
    did VARCHAR(60) not null,
    name varchar(100) not null,
    acc_value VARCHAR(10) null,
    created_at date  null,
    type VARCHAR(30)  not null,
    is_issuer BOOL default false not null,
    is_valid BOOL default false not null,
    tx_hash char(66) not null,
    block_height BIGINT null,
    info varchar(255) null,
    primary key (did)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `cpt` (
    `cpt_id` int(20) NOT NULL,
    `cpt_version` int(6) DEFAULT NULL,
    `publisher` varchar(60) DEFAULT NULL,
    `created_at` date DEFAULT NULL,
    `claim` varchar(300) DEFAULT NULL,
    `title` varchar(100) DEFAULT NULL COMMENT '该CPT标题',
    `des` varchar(400) DEFAULT NULL COMMENT '该CPT描述',
    `tx_hash` char(66) DEFAULT NULL,
    `block_height` bigint(20) DEFAULT NULL,
    PRIMARY KEY (`cpt_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE table IF NOT EXISTS `web_credential` (
                              `id` varchar(40) NOT NULL,
                              `issuer` varchar(60) DEFAULT NULL,
                              `cpt_id` int(11) DEFAULT NULL,
                              `credential` json DEFAULT NULL,
                              `is_valid` tinyint(1) DEFAULT '1',
                              PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `web_evidence` (
                            `evidence_hash` varchar(80) NOT NULL,
                            `credential_id` varchar(40) NOT NULL,
                            `customKey` varchar(40) DEFAULT NULL,
                            `log` json DEFAULT NULL,
                            `tx_hash` char(66) DEFAULT NULL,
                            `block_height` bigint(20) DEFAULT NULL,
                            PRIMARY KEY (`evidence_hash`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
